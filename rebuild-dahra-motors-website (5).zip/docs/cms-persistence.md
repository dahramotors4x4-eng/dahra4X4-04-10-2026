# CMS Persistence

- `src/App.tsx` mounts one `CmsProvider` above the router, storefront and admin.
- The only active CMS document is `localStorage['dahra_cms_v2']`.
- `loadState()` reads that key first. Existing records, zero values, empty arrays,
  deleted products and stored credentials are not replaced by seed data.
- `dahra_cms_v1` is adopted first, then `dahra_cms_v3`, only if v2 is absent or
  empty. Existing v2 always wins. Earlier documents remain read-only backups;
  no key is deleted and seed versions never trigger resets.
- `commit()` reads the current saved document, computes the change, and calls
  `saveState()` synchronously. Only a successful write publishes React state,
  returns `true`, and allows a form to close or show a saved notification.
- `saveState()` writes the full plain CMS document and emits
  `dahra_cms_updated`. The provider listens for that event in the same window
  and native `storage` events from other same-origin tabs. A
  `dahra_cms_sync_v2` BroadcastChannel carries an invalidation notice as an
  additional cross-tab signal. Receivers always re-read v2; broadcasts never
  replace state with a potentially stale document.
- Synchronization handlers read only. They neither save nor rebroadcast.
  Missing or invalid saved data keeps the last good in-memory document and
  displays an error. It never triggers fallback seeding or empty-state resets.
- `CmsRouteSync` performs a read-only refresh on route changes. The provider
  stays mounted above the router, so page transitions cannot reset its state.
  No Save action forces a page reload.
- Form inputs are local drafts; Enregistrer commits them. Inline price, stock,
  visibility and content controls call the same writer immediately.
- Automatic Supabase pulls/pushes are disconnected from this local-authoritative
  flow. The optional adapter remains in `src/lib/backend.ts` but does not run.
- There is no default-content reset API exposed by the provider. Defaults are
  used only for the first saved document, not by navigation or synchronization.
- Theme, language, audit and analytics preferences have separate auxiliary keys;
  they are not alternate copies of the CMS document.

## Regression Tests

With Node.js 22.18 or newer, run:

`node --test tests/cms-persistence.test.mjs`

These dependency-free tests use an isolated Storage/EventTarget implementation,
never a real browser's data. They cover first-run seeding, legacy formats, key
precedence, unchanged saved prices/credentials, deleted/empty collections,
corrupt data preservation, event order and write failure behavior.

## Branding / Logo

- The built-in mark is `src/components/LogoMark.tsx`, an inline transparent SVG in
  the Ironman 4x4 palette (green/yellow strength chevrons, black banner, yellow →
  orange → red rails). It needs no image file and has no background box.
- `/admin` → Logo & Branding uploads the official mascot logo (PNG or SVG) into
  `settings.headerLogo` / `settings.footerLogo`; it replaces the built-in mark in
  the header and footer.
- `src/components/useLogoAppearance.ts` inspects the uploaded image's corners and
  chooses the treatment: multiply on light; transparent logos stay untouched on
  dark; only a white-boxed image gets `invert + hue-rotate + screen`. Coloured
  logos are never blind-inverted.

## Browser Checks

1. Open `/admin` and `/boutique` in two tabs of the same origin/browser profile.
2. Change a product price or stock using an inline control. Verify the store and
   an open product detail view change without reloading.
3. Save a product, logo or contact form with Enregistrer. Navigate to `/`, then
   `/shop`, then reload. Verify the edit and the saved JSON remain unchanged.
4. Update the shipping trust badge in Contenu. Verify the header and product
   delivery text use the same value.
5. Delete a product or empty a collection, then reload and change routes. The
   defaults must not reappear.
6. Dispatch `dahra_cms_updated` after an external write to the v2 key. Verify the
   current page updates; writes from another tab use the native storage event.
7. Simulate a full or blocked localStorage. A save must display an error, leave
   the form open and retain the last saved data instead of reporting success.

localStorage is persistent only within the same browser profile and origin.
Clearing site data, private sessions, or changing domains/devices does not share
the saved document. BrowserRouter deployments also need an index.html fallback
for direct `/admin` and `/boutique` requests.

## Admin Session

- `/admin` uses the case-sensitive owner credentials configured in
  `src/lib/data.ts`. Known previous factory credentials migrate to the current
  values when an older CMS document is loaded.
- A successful login writes a versioned token to
  `localStorage['dahra_admin_session_v2']`; sessionStorage is used only as a
  fallback when persistent storage is blocked.
- The token is read when the provider mounts, so navigation and reloads do not
  log the administrator out. Login/logout also synchronize across tabs through
  the native storage event.
- Logout removes both persistent and fallback tokens. Successful login opens the
  Products management tab directly.
- This is client-side access control for a static app. Protecting privileged
  server/database operations requires server-validated authentication.

## Price Normalization

- `src/lib/pricing.ts` is the single rule for product pricing:
  `Math.round(value / 100) * 100` (nearest 100 DA).
- `price`, optional `priceMax`, and `oldPrice` are normalized before every CMS
  write and by the versioned v2 migration on load.
- Storefront formatters render zero decimal places and retain locale thousands
  grouping, e.g. `20 400 DA` or `77 300 – 154 700 DA`.
- The Amortisseurs price revision updates only the supplied Amortisseurs SKUs;
  copy, stock, visibility and admin product images remain untouched.