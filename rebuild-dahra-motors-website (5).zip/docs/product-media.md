# Product Media Catalog

Product media is curated centrally in `src/lib/productImages.ts`.

## Source Priority

1. Exact official SKU gallery from the Ironman 4x4 Australia/USA catalog.
2. Official Ironman product-series gallery when a retired/regional SKU has only
   one publicly indexed exact asset.
3. For the two tire-only catalog rows, verified Ironman Tires product imagery
   from an automotive product database.
4. No unrelated global fallback. If every relevant source fails, the image is
   hidden instead of showing a broken icon or another category's product.

The official product sites use Shopify CDN paths; URLs therefore appear as
`ironman4x4.com/cdn/shop/files/...` or
`ironman4x4.com.au/cdn/shop/files/...` and are requested at 1600px.

## Exact Catalog Matches Included

- `UBP019`, `UBP048`: official underbody protection.
- `BBCD048 + IRP005`: official Navara NP300 Deluxe Bull Bar.
- `RTB048 + RTBPLATE001`: official Navara NP300 rear protection tow bar.
- `SS048`: official Navara NP300 side steps.
- `IWT001`, `IWT003`, `IWT004`, `IWT005`, `IWT006`: official water tanks.
- `IRECBD*`, `IRECBDPINS115`, `IRECBRDBASE`: official Reco-Traks system.
- `IMW12000_MSR`, `IMW9500_MSR`, `WWB015`, `WWB031`: official Frontier /
  Monster winch products and parts.
- `ISNORKEL006`, `ISNORKEL056`, `ISNORKEL064`: official Airforce snorkels.
- Ford Ranger canopy: official Pinnacle 2 canopy.
- Foam Cell Pro, roof racks, rooftop tents, awnings, fridges and LED bars use
  official high-resolution product catalog photography.

## Persistence and Owner Images

- `productImageVersion` applies the catalog once to older seeded `/images/...`
  or Pexels media.
- Admin-uploaded data URLs and arbitrary owner-hosted image URLs are not
  overwritten by this migration.
- `SafeImage.tsx` handles failures in product cards, product galleries, order
  summaries and admin product rows without showing browser broken-image icons.
- Product source chains are limited to the product's own primary image, its
  cleaned gallery, and its SKU/category-specific official source. The historical
  12,000lb winch global fallback has been removed completely.
- `productImageVersion = 3` authoritatively replaces all catalog product media
  once in `dahra_cms_v2`. Each primary plus secondary gallery totals 2–4 unique
  relevant images. Later admin edits are respected after the migration marker.
- Revision 3 scrubs all known winch URLs from non-winch products; winch products
  keep their proper Frontier/Monster winch and accessory galleries.
- Cards keep `aspect-[4/3]`; product detail media keeps its existing `4/3` frame.

Official catalog sources used during curation:

- <https://www.ironman4x4.com/>
- <https://www.ironman4x4.com.au/>