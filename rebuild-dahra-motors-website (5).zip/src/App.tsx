import { useEffect } from "react";
import { BrowserRouter, Routes, Route, useLocation, useNavigate } from "react-router-dom";
import { CmsProvider, useCms } from "./lib/store";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Shop from "./pages/Shop";
import ProductDetail from "./pages/ProductDetail";
import Calculator from "./pages/Calculator";
import Gallery from "./pages/Gallery";
import About from "./pages/About";
import Contact from "./pages/Contact";
import ThankYou from "./pages/ThankYou";
import NotFound from "./pages/NotFound";
import AdminDashboard from "./pages/AdminDashboard";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, [pathname]);
  return null;
}

/** Route transitions read saved data but never seed, save, or reset the CMS. */
function CmsRouteSync() {
  const { pathname, search } = useLocation();
  const { refreshCms } = useCms();
  useEffect(() => refreshCms(), [pathname, search, refreshCms]);
  return null;
}

/** Bridges any legacy #/path URLs cleanly into BrowserRouter routes. */
function HashBridge() {
  const navigate = useNavigate();
  useEffect(() => {
    const syncHash = () => {
      if (window.location.hash.startsWith("#/")) {
        const target = window.location.hash.slice(1);
        navigate(target, { replace: true });
      }
    };
    syncHash();
    window.addEventListener("hashchange", syncHash);
    return () => window.removeEventListener("hashchange", syncHash);
  }, [navigate]);
  return null;
}

function Shell() {
  const location = useLocation();
  const hideChrome = location.pathname.startsWith("/admin");
  return (
    <div className="flex min-h-screen flex-col bg-bg">
      {!hideChrome && <Header />}
      <main className="flex-1">
        <CmsStorageNotice />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/index.html" element={<Home />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/boutique" element={<Shop />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/produit/:id" element={<ProductDetail />} />
          <Route path="/calculator" element={<Calculator />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/thank-you" element={<ThankYou />} />
          <Route path="/admin/*" element={<AdminDashboard />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      {!hideChrome && <Footer />}
    </div>
  );
}

function CmsStorageNotice() {
  const { storageError } = useCms();
  if (!storageError) return null;
  return (
    <div role="alert" className="border-b border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-600 dark:text-red-300">
      <div className="mx-auto max-w-7xl">{storageError}</div>
    </div>
  );
}

export default function App() {
  return (
    // Keep the provider outside the route tree so navigation cannot remount it.
    <CmsProvider>
      <BrowserRouter>
        <HashBridge />
        <CmsRouteSync />
        <ScrollToTop />
        <Shell />
      </BrowserRouter>
    </CmsProvider>
  );
}

export { useCms };
