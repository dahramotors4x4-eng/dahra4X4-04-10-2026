import { useState, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { X, Check, MessageCircle, PackageCheck } from "lucide-react";
import type { Order, Product } from "../lib/types";
import { useCms, buildWhatsAppLink, orderWhatsAppMessage } from "../lib/store";
import { formatPrice, formatProductPrice } from "../lib/i18n";
import { WILAYAS } from "../lib/data";
import { productImageSources } from "../lib/productImages";
import SafeImage from "./SafeImage";

/* ================================================================== */
/*  COD modal state — usable from any page that renders product grids  */
/* ================================================================== */

export function useCodModal() {
  const { state } = useCms();
  const [codProduct, setCodProduct] = useState<Product | null>(null);
  const selected = state.products.find((p) => p.id === codProduct?.id && p.active);
  const modal: ReactNode = selected ? (
    <CodOrderModal product={selected} onClose={() => setCodProduct(null)} />
  ) : null;
  return { openCod: setCodProduct, codModal: modal };
}

/* ================================================================== */

const inputClass =
  "w-full rounded border border-line bg-surface px-3.5 py-2.5 text-sm text-ink placeholder:text-muted/60 focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30 transition-colors";

export default function CodOrderModal({
  product,
  onClose,
}: {
  product: Product;
  onClose: () => void;
}) {
  const { state, lang, t, addOrder, trackOrder, storageError } = useCms();
  const navigate = useNavigate();

  const [quantity, setQuantity] = useState(1);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [wilaya, setWilaya] = useState("");
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");
  const [install, setInstall] = useState(false);
  const [installDate, setInstallDate] = useState("");
  const [installSlot, setInstallSlot] = useState("09:00 – 12:00");
  const [error, setError] = useState(false);

  const [done, setDone] = useState<Order | null>(null);

  const productName = lang === "ar" && product.nameAr ? product.nameAr : product.name;

  const submit = () => {
    if (!name.trim() || !phone.trim() || !wilaya || !address.trim()) {
      setError(true);
      return;
    }
    const order: Order = {
      id: crypto.randomUUID(),
      reference: `DM-${Date.now().toString(36).toUpperCase().slice(-6)}`,
      productId: product.id,
      productName: product.name,
      sku: product.sku,
      unitPrice: product.price,
      quantity,
      customerName: name.trim(),
      phone: phone.trim(),
      wilaya,
      address: address.trim(),
      note: note.trim(),
      channel: "COD",
      status: "pending",
      createdAt: Date.now(),
      installation: install && installDate ? { date: installDate, slot: installSlot } : null,
    };
    if (!addOrder(order)) return;
    trackOrder();
    setDone(order);
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-4">
      <div className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-2xl border border-line bg-bg shadow-2xl sm:rounded-xl">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-line bg-bg px-5 py-4">
          <div>
            <h3 className="font-display text-lg font-extrabold uppercase tracking-wide text-ink">
              {done ? t("cod.successTitle") : t("cod.title")}
            </h3>
            {!done && (
              <p className="text-xs text-muted">
                {productName} — {t("product.sku")} {product.sku}
              </p>
            )}
          </div>
          <button
            onClick={onClose}
            className="rounded border border-line p-2 text-muted transition-colors hover:border-brand hover:text-brand"
            aria-label={t("cod.close")}
          >
            <X size={16} />
          </button>
        </div>

        {!done ? (
          <div className="space-y-4 p-5">
            <p className="text-sm text-muted">{t("cod.subtitle")}</p>
            {storageError && <p role="alert" className="text-sm text-red-500">{storageError}</p>}

            {/* Product summary */}
            <div className="flex items-center gap-3 rounded-lg border border-line bg-surface p-3">
              <SafeImage
                sources={productImageSources(product)}
                alt={productName}
                className="h-16 w-20 rounded object-cover"
              />
              <div className="min-w-0 flex-1">
                <p className="truncate font-display text-sm font-bold uppercase text-ink">
                  {productName}
                </p>
                <p className="text-xs text-muted">
                  {t("product.sku")} {product.sku}
                </p>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="h-8 w-8 rounded border border-line text-ink hover:border-brand hover:text-brand"
                >
                  −
                </button>
                <span className="w-8 text-center font-display text-sm font-bold text-ink">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity((q) => Math.min(Math.max(product.stock, 1), q + 1))}
                  className="h-8 w-8 rounded border border-line text-ink hover:border-brand hover:text-brand"
                >
                  +
                </button>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <input
                className={inputClass}
                placeholder={t("cod.name")}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <input
                className={inputClass}
                placeholder={t("cod.phone")}
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                dir="ltr"
              />
            </div>
            <select
              className={inputClass}
              value={wilaya}
              onChange={(e) => setWilaya(e.target.value)}
            >
              <option value="">{t("cod.wilaya")} —</option>
              {WILAYAS.map((w) => (
                <option key={w} value={w}>
                  {w}
                </option>
              ))}
            </select>
            <input
              className={inputClass}
              placeholder={t("cod.address")}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
            />
            <textarea
              className={inputClass}
              rows={2}
              placeholder={t("cod.note")}
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />

            {/* Installation slot */}
            <label className="flex items-start gap-2.5 rounded-lg border border-line bg-surface p-3">
              <input
                type="checkbox"
                checked={install}
                onChange={(e) => setInstall(e.target.checked)}
                className="mt-0.5 h-4 w-4 accent-orange-500"
              />
              <span className="text-sm text-ink">{t("cod.installCheck")}</span>
            </label>
            {install && (
              <div className="grid gap-3 sm:grid-cols-2">
                <input
                  type="date"
                  className={inputClass}
                  value={installDate}
                  onChange={(e) => setInstallDate(e.target.value)}
                  aria-label={t("cod.installDate")}
                />
                <select
                  className={inputClass}
                  value={installSlot}
                  onChange={(e) => setInstallSlot(e.target.value)}
                  aria-label={t("cod.installSlot")}
                >
                  <option>09:00 – 12:00</option>
                  <option>14:00 – 18:00</option>
                </select>
              </div>
            )}

            {error && (
              <div className="rounded border border-red-400/40 bg-red-500/10 px-3 py-2 text-sm text-red-500">
                {t("cod.required")}
              </div>
            )}

            <div className="flex items-center justify-between rounded-lg bg-onyx px-4 py-3 text-white">
              <span className="text-sm uppercase tracking-wider text-slate-300">
                {t("cod.total")}
              </span>
              <span className="font-display text-xl font-extrabold text-brand">
                {formatProductPrice(product, lang, quantity)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={onClose}
                className="rounded border border-line px-4 py-3 font-display text-sm font-bold uppercase tracking-wider text-ink transition-colors hover:border-brand hover:text-brand"
              >
                {t("cod.cancel")}
              </button>
              <button
                onClick={submit}
                className="flex items-center justify-center gap-2 rounded bg-brand px-4 py-3 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong hover:shadow-lg hover:shadow-brand/30"
              >
                <PackageCheck size={16} /> {t("cod.submit")}
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4 p-5 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-green-500/15 text-green-500">
              <Check size={28} />
            </div>
            <p className="text-sm text-muted">
              {t("cod.successText")}
              <span className="font-display font-bold text-ink"> {done.reference}</span>
            </p>
            <div className="rounded-lg border border-line bg-surface p-4 text-start text-sm">
              <div className="flex justify-between">
                <span className="text-muted">{t("ty.customer")}</span>
                <span className="font-semibold text-ink">{done.customerName}</span>
              </div>
              <div className="mt-1.5 flex justify-between">
                <span className="text-muted">{t("ty.delivery")}</span>
                <span className="font-semibold text-ink">{done.wilaya}</span>
              </div>
              <div className="mt-1.5 flex justify-between">
                <span className="text-muted">{t("product.sku")}</span>
                <span className="font-semibold text-ink">
                  {done.sku} × {done.quantity}
                </span>
              </div>
              <div className="mt-1.5 flex justify-between border-t border-line pt-2">
                <span className="text-muted">{t("cod.total")}</span>
                <span className="font-display font-extrabold text-brand">
                  {formatPrice(done.unitPrice * done.quantity, lang)}
                </span>
              </div>
              {done.installation && (
                <div className="mt-1.5 flex justify-between">
                  <span className="text-muted">{t("cod.installBooked")}</span>
                  <span className="font-semibold text-ink">
                    {done.installation.date} · {done.installation.slot}
                  </span>
                </div>
              )}
            </div>

            <p className="text-xs text-muted">{t("cod.alsoWhatsapp")}</p>
            <a
              href={buildWhatsAppLink(
                state.settings.whatsapp,
                orderWhatsAppMessage(done, done.unitPrice * done.quantity)
              )}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-2 rounded bg-brand px-4 py-3 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong hover:shadow-lg hover:shadow-brand/30"
            >
              <MessageCircle size={16} /> WhatsApp
            </a>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={onClose}
                className="rounded border border-line px-4 py-3 font-display text-sm font-bold uppercase tracking-wider text-ink transition-colors hover:border-brand hover:text-brand"
              >
                {t("cod.close")}
              </button>
              <button
                onClick={() => {
                  onClose();
                  navigate("/thank-you");
                }}
                className="rounded bg-onyx px-4 py-3 font-display text-sm font-bold uppercase tracking-wider text-white transition-colors hover:bg-black"
              >
                {t("ty.summary")} →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
