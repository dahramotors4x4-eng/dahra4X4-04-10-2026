import { useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu,
  X,
  Sun,
  Moon,
  Phone,
  Mail,
  MapPin,
  MessageCircle,
  Calculator,
  Camera,
} from "lucide-react";
import { useCms, greetingWhatsAppLink } from "../lib/store";
import { ANNOUNCEMENT } from "../lib/data";
import { loc } from "../lib/i18n";
import LogoMark from "./LogoMark";
import PhoneMenu from "./PhoneMenu";
import { useLogoAppearance } from "./useLogoAppearance";
import { FacebookIcon, InstagramIcon, YoutubeIcon } from "./SocialIcons";

const NAV_LINKS = [
  { to: "/", key: "nav.home" as const },
  { to: "/shop", key: "nav.shop" as const },
  { to: "/calculator", key: "nav.calculator" as const, icon: Calculator },
  { to: "/gallery", key: "nav.gallery" as const, icon: Camera },
  { to: "/about", key: "nav.about" as const },
  { to: "/contact", key: "nav.contact" as const },
];

export default function Header() {
  const { state, siteConfig, lang, theme, toggleTheme, setLang, t } = useCms();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [logoError, setLogoError] = useState(false);
  const logoAppearance = useLogoAppearance(siteConfig.logo.header, theme === "dark");

  // A newly saved logo gets a fresh chance to load (an earlier failure must not stick).
  useEffect(() => {
    setLogoError(false);
  }, [siteConfig.logo.header]);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  const { settings } = state;

  return (
    <header className="sticky top-0 z-50">
      {/* Top utility bar */}
      {/* Top announcement bar — deep charcoal with brand-green highlights */}
      <div className="hidden border-b border-white/10 bg-onyx text-slate-400 lg:block">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-2 text-[11px]">
          <div className="flex items-center gap-5">
            <span className="flex items-center gap-1.5">
              <Phone size={13} className="text-brand" />
              <a
                href={state.settings.contactLines[0]?.href ?? `tel:${siteConfig.contact.phone.replace(/\s/g, "")}`}
                className="flex items-center gap-1.5 font-semibold transition-colors hover:text-brand"
                dir="ltr"
              >
                {state.settings.contactLines[0]?.value ?? siteConfig.contact.phone}
              </a>
            </span>
            <a
              href={`mailto:${settings.email}`}
              className="flex items-center gap-1.5 transition-colors hover:text-brand"
            >
              <Mail size={13} className="text-brand" /> {settings.email}
            </a>
            <a
              href={settings.mapLink}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 transition-colors hover:text-brand"
            >
              <MapPin size={13} className="text-brand" /> {loc(settings.address, lang)}
            </a>
          </div>
          <div className="flex min-w-0 items-center gap-4">
            {/* Delivery wording is read from the same CMS badge as the storefront. */}
            <span className="font-display min-w-0 truncate text-[11px] font-bold uppercase tracking-[0.14em] text-slate-300">
              <span className="text-brand">{ANNOUNCEMENT.split("—")[0].trim()}</span>
              <span className="mx-1.5 text-slate-600">—</span>
              <span className="text-slate-400">
                {siteConfig.delivery && <>{loc(siteConfig.delivery.title, lang)} / </>}
                {lang === "ar" ? "الدفع عند الاستلام" : "PAIEMENT À LA LIVRAISON"}
              </span>
            </span>
            <div className="flex items-center gap-2">
              {settings.social.facebook && (
                <a
                  href={settings.social.facebook}
                  target="_blank"
                  rel="noreferrer"
                  className="transition-colors hover:text-brand"
                >
                  <FacebookIcon size={14} />
                </a>
              )}
              {settings.social.instagram && (
                <a
                  href={settings.social.instagram}
                  target="_blank"
                  rel="noreferrer"
                  className="transition-colors hover:text-brand"
                >
                  <InstagramIcon size={14} />
                </a>
              )}
              {settings.social.youtube && (
                <a
                  href={settings.social.youtube}
                  target="_blank"
                  rel="noreferrer"
                  className="transition-colors hover:text-brand"
                >
                  <YoutubeIcon size={14} />
                </a>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main nav */}
      <div
        className={`border-b transition-all duration-300 ${
          scrolled
            ? "border-line bg-bg/95 shadow-lg shadow-black/10 backdrop-blur-md"
            : "border-line bg-bg"
        }`}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3">
          {/* Graphic logo — transparent, no container, no duplicate text.
              Falls back to the inline SVG mark; an uploaded PNG/SVG is blended
              (multiply / invert+screen) so no white box ever shows. */}
          <Link
            to="/"
            className="group flex flex-col items-start justify-center gap-1 py-1 pe-2"
            aria-label="Dahra Motors 4x4 — Accueil"
          >
            {siteConfig.logo.header && !logoError ? (
              <img
                src={siteConfig.logo.header}
                alt="Dahra Motors 4x4"
                onError={() => setLogoError(true)}
                style={logoAppearance.style}
                title={logoAppearance.description}
                className="h-11 max-h-[56px] w-auto object-contain transition-transform duration-300 group-hover:scale-105 sm:h-14 sm:max-h-[60px]"
              />
            ) : (
              <LogoMark className="h-10 text-ink transition-transform duration-300 group-hover:scale-105 sm:h-[52px]" />
            )}
            <span className="hidden font-display text-[9px] font-semibold uppercase tracking-[0.28em] text-muted sm:block">
              Official Ironman 4x4 — Algeria
            </span>
          </Link>

          <nav className="mx-auto hidden items-center gap-1 xl:flex">
            {NAV_LINKS.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === "/"}
                className={({ isActive }) =>
                  `font-display relative px-3 py-2 text-[15px] font-bold uppercase tracking-wide transition-colors ${
                    isActive
                      ? "text-brand after:absolute after:inset-x-3 after:bottom-0.5 after:h-[2px] after:rounded-full after:bg-brand after:content-['']"
                      : "text-ink hover:text-brand"
                  }`
                }
              >
                {t(link.key)}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            {/* Contact dropdown — mobiles, ligne fixe, WhatsApp support */}
            <PhoneMenu />
            {/* Language toggle */}
            <button
              onClick={() => setLang(lang === "fr" ? "ar" : "fr")}
              className="font-display rounded border border-line px-2.5 py-1.5 text-sm font-bold uppercase tracking-wider text-ink transition-colors hover:border-brand hover:text-brand"
              aria-label="Switch language"
            >
              {lang === "fr" ? "عربي" : "FR"}
            </button>
            {/* Theme toggle */}
            <button
              onClick={toggleTheme}
              className="rounded border border-line p-2 text-ink transition-colors hover:border-brand hover:text-brand"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
            </button>
            {/* WhatsApp CTA — pre-filled greeting */}
            <a
              href={greetingWhatsAppLink(settings.whatsapp)}
              target="_blank"
              rel="noreferrer"
              className="hidden items-center gap-2 rounded bg-brand px-4 py-2 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong hover:shadow-lg hover:shadow-brand/30 md:flex"
            >
              <MessageCircle size={16} /> WhatsApp
            </a>
            {/* Mobile menu */}
            <button
              onClick={() => setMobileOpen((o) => !o)}
              className="rounded border border-line p-2 text-ink xl:hidden"
              aria-label="Menu"
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden border-b border-line bg-surface xl:hidden"
          >
            <nav className="flex flex-col px-4 py-3">
              {NAV_LINKS.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.to === "/"}
                  className={({ isActive }) =>
                    `font-display rounded px-3 py-3 text-sm font-bold uppercase tracking-wide transition-colors ${
                      isActive ? "bg-brand/10 text-brand" : "text-ink hover:text-brand"
                    }`
                  }
                >
                  {t(link.key)}
                </NavLink>
              ))}
              <a
                href={greetingWhatsAppLink(settings.whatsapp)}
                target="_blank"
                rel="noreferrer"
                className="mt-2 flex items-center justify-center gap-2 rounded bg-brand px-4 py-3 font-display text-sm font-bold uppercase tracking-wider text-black"
              >
                <MessageCircle size={16} /> WhatsApp — {settings.phone}
              </a>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
