/**
 * Ironman 4x4 / Dahra Motors — built-in brand mark (inline SVG).
 *
 * Original vector artwork in the brand's palette: the black banner plaque with
 * yellow → orange → red accent rails, heavy "IRONMAN" / "4 X 4" lettering and a
 * lime-to-yellow strength chevron. Fully transparent — no background box — so it
 * renders seamlessly over light or dark headers and footers.
 *
 * The official mascot logo is uploaded from /admin → Logo & Branding, which
 * replaces this fallback at runtime.
 */
export default function LogoMark({ className = "h-11" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 260 104"
      className={className}
      role="img"
      aria-label="Ironman 4x4"
      fill="none"
    >
      <defs>
        <linearGradient id="dm-strength" x1="0" y1="1" x2="1" y2="0">
          <stop offset="0%" stopColor="#16a34a" />
          <stop offset="55%" stopColor="#22c55e" />
          <stop offset="100%" stopColor="#f7ef21" />
        </linearGradient>
        <linearGradient id="dm-rail" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#f7ef21" />
          <stop offset="52%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#dc2626" />
        </linearGradient>
        <linearGradient id="dm-steel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="55%" stopColor="#e5e7eb" />
          <stop offset="100%" stopColor="#9ca3af" />
        </linearGradient>
      </defs>

      {/* Strength chevrons — bold, geometric power motif */}
      <g stroke="#0b0b0c" strokeWidth="3.4" strokeLinejoin="round">
        <path d="M22 6 L54 6 L38 40 L6 40 Z" fill="url(#dm-strength)" />
        <path d="M60 6 L92 6 L76 40 L44 40 Z" fill="url(#dm-strength)" />
        <path d="M98 6 L130 6 L114 40 L82 40 Z" fill="url(#dm-strength)" />
      </g>
      {/* Ridge highlight */}
      <path d="M30 12 L46 12 L34 34 L22 34 Z" fill="#ffffff" opacity="0.32" />
      <path d="M68 12 L84 12 L72 34 L60 34 Z" fill="#ffffff" opacity="0.22" />

      {/* Upper accent rail */}
      <rect x="14" y="46" width="232" height="6" rx="3" fill="url(#dm-rail)" />

      {/* Banner plaque */}
      <rect x="14" y="52" width="232" height="44" rx="3" fill="#0b0b0c" />
      <rect
        x="14.9"
        y="52.9"
        width="230.2"
        height="42.2"
        rx="2.4"
        fill="none"
        stroke="#ffffff"
        strokeOpacity="0.12"
      />

      {/* Wordmark — steel gradient, heavy condensed */}
      <text
        x="130"
        y="82"
        textAnchor="middle"
        fill="url(#dm-steel)"
        style={{
          fontFamily: "'Oswald','Tajawal',sans-serif",
          fontWeight: 700,
          fontSize: 29,
          letterSpacing: "0.085em",
        }}
      >
        IRONMAN
      </text>

      {/* 4 X 4 */}
      <g>
        <text
          x="134"
          y="93.5"
          textAnchor="middle"
          fill="#ffffff"
          style={{
            fontFamily: "'Oswald','Tajawal',sans-serif",
            fontWeight: 600,
            fontSize: 11.5,
            letterSpacing: "0.62em",
          }}
        >
          4 X 4
        </text>
      </g>

      {/* Lower accent rail */}
      <rect x="14" y="97" width="232" height="5" rx="2.5" fill="url(#dm-rail)" />
    </svg>
  );
}
