import { useEffect, useRef, useState } from "react";
import { ChevronDown, MessageCircle, Phone } from "lucide-react";
import { useCms } from "../lib/store";

/**
 * Header contact dropdown.
 *
 * Lists the structured Dahra Motors phone lines (3 mobiles, ligne fixe and
 * WhatsApp support). Each row dials with `tel:`, the WhatsApp row opens
 * `https://wa.me/213560030896`. The button shows the primary mobile number.
 */
export default function PhoneMenu() {
  const { state } = useCms();
  const lines = state.settings.contactLines ?? [];
  const primary = lines[0];
  const [open, setOpen] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: MouseEvent) => {
      if (wrap.current && !wrap.current.contains(event.target as Node)) setOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  if (!primary) return null;

  return (
    <div ref={wrap} className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={`Téléphone : ${primary.value}`}
        className="flex items-center gap-1.5 rounded border border-line px-2.5 py-2 text-ink transition-colors duration-200 hover:border-brand hover:text-brand"
      >
        <Phone size={15} className="shrink-0 text-brand" />
        <span
          dir="ltr"
          className="hidden whitespace-nowrap text-xs font-bold tabular-nums min-[480px]:inline"
        >
          {primary.value}
        </span>
        <ChevronDown
          size={13}
          className={`shrink-0 transition-transform duration-200 ${open ? "rotate-180" : ""}`}
        />
      </button>

      <div
        role="menu"
        aria-hidden={!open}
        className={`absolute end-0 top-full z-50 mt-2 w-64 origin-top-right rounded-xl border border-slate-200 bg-white p-3 shadow-xl transition-all duration-200 dark:border-slate-800 dark:bg-slate-900 ${
          open
            ? "visible translate-y-0 opacity-100"
            : "invisible -translate-y-1 opacity-0"
        }`}
      >
        <p className="px-1.5 pb-1.5 pt-1 text-[10px] font-bold uppercase tracking-[0.18em] text-slate-500">
          Appelez-nous
        </p>

        <ul className="space-y-1">
          {lines.map((line) => {
            const isWhatsApp = line.kind === "whatsapp";
            return (
              <li key={`${line.label}-${line.value}`}>
                <a
                  href={line.href}
                  role="menuitem"
                  dir="ltr"
                  target={isWhatsApp ? "_blank" : undefined}
                  rel={isWhatsApp ? "noreferrer" : undefined}
                  onClick={() => setOpen(false)}
                  className="group flex items-center gap-3 rounded-lg px-1.5 py-2 transition-colors duration-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <span
                    className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-colors duration-200 ${
                      isWhatsApp
                        ? "bg-[#25D366]/10 text-[#25D366] group-hover:bg-[#25D366]/20"
                        : "bg-brand/10 text-brand group-hover:bg-brand/20"
                    }`}
                  >
                    {isWhatsApp ? <MessageCircle size={15} /> : <Phone size={15} />}
                  </span>

                  <span className="min-w-0 flex-1">
                    <span
                      dir="ltr"
                      className="block text-[10px] font-bold uppercase tracking-wider text-slate-500"
                    >
                      {line.label}
                    </span>
                    <span className="block text-sm font-bold tabular-nums text-slate-900 dark:text-white">
                      {line.value}
                    </span>
                  </span>

                  {line.kind !== "mobile" && (
                    <span
                      className={`shrink-0 rounded px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider ${
                        isWhatsApp
                          ? "bg-[#25D366]/10 text-[#25D366]"
                          : "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400"
                      }`}
                    >
                      {isWhatsApp ? "WhatsApp" : "Fixe"}
                    </span>
                  )}
                </a>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
