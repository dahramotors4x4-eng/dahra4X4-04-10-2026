import { useEffect, useMemo, useState } from "react";

interface SafeImageProps extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, "src"> {
  sources: Array<string | null | undefined>;
}

/** Cycles through curated sources so a failed CDN request never shows a broken icon. */
export default function SafeImage({ sources, onError, ...props }: SafeImageProps) {
  const candidates = useMemo(
    () => Array.from(new Set(sources.filter(Boolean))) as string[],
    [sources]
  );
  const signature = candidates.join("\u0000");
  const [index, setIndex] = useState(0);
  const [exhausted, setExhausted] = useState(false);

  useEffect(() => {
    setIndex(0);
    setExhausted(false);
  }, [signature]);

  // Never emit a browser broken-image glyph. Product records are expected to
  // supply a relevant source; if every relevant source fails, hide the image.
  if (candidates.length === 0 || exhausted) return null;

  return (
    <img
      {...props}
      src={candidates[Math.min(index, candidates.length - 1)]}
      onError={(event) => {
        onError?.(event);
        setIndex((current) => {
          if (current < candidates.length - 1) return current + 1;
          setExhausted(true);
          return current;
        });
      }}
    />
  );
}