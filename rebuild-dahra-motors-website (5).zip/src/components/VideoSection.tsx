import { useRef, useState } from "react";
import { ExternalLink, Volume2, VolumeX } from "lucide-react";
import { useCms } from "../lib/store";
import { IRONMAN_VIDEO_ID, IRONMAN_VIDEO_WATCH_URL } from "../lib/data";
import { loc } from "../lib/i18n";
import { parseVideoSource } from "../lib/video";
import { YoutubeIcon } from "./SocialIcons";

/**
 * Responsive 16:9 Ironman 4x4 media showcase.
 * The video occupies its own strict-ratio frame; all copy and actions sit below
 * it so overlays never obscure the suspension footage at any viewport size.
 */
export default function VideoSection() {
  const { state, lang, t } = useCms();
  const section = state.videoSection;
  const [muted, setMuted] = useState(true);
  const videoRef = useRef<HTMLVideoElement>(null);

  if (!section.enabled || !section.videoUrl) return null;

  const source = parseVideoSource(section.videoUrl, {
    autoplay: true,
    muted: true,
    loop: true,
  });
  const isIronmanShowcase =
    source?.kind === "youtube" && section.videoUrl.includes(IRONMAN_VIDEO_ID);
  const youtubeLink = isIronmanShowcase
    ? IRONMAN_VIDEO_WATCH_URL
    : section.ctaLink || state.settings.social.youtube;

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setMuted(videoRef.current.muted);
  };

  return (
    <section className="bg-bg">
      <div className="mx-auto w-full max-w-6xl px-4 py-8">
        {/* Isolated media frame: strict 16:9, no copy or controls over the video. */}
        <div className="relative aspect-video w-full overflow-hidden rounded-2xl border border-slate-800 bg-black shadow-2xl">
          {source?.kind === "file" ? (
            <video
              ref={videoRef}
              className="h-full w-full rounded-2xl object-cover"
              src={source.src}
              poster={section.poster}
              autoPlay
              muted
              loop
              playsInline
              preload="metadata"
            />
          ) : source ? (
            <iframe
              src={source.src}
              title={loc(section.title, lang)}
              className="h-full w-full rounded-2xl border-0 object-cover"
              allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
              referrerPolicy="strict-origin-when-cross-origin"
              allowFullScreen
            />
          ) : null}
        </div>

        {/* Copy and actions live below the player and wrap without overflow. */}
        <div className="mt-5 flex min-w-0 flex-col gap-4 sm:mt-6 lg:flex-row lg:items-end lg:justify-between lg:gap-8">
          <div className="min-w-0 max-w-4xl">
            <span className="mb-2 inline-flex max-w-full rounded-full border border-lime-500/40 bg-lime-500/20 px-3 py-1 text-xs font-bold uppercase tracking-widest text-lime-500">
              <span className="truncate">{loc(section.badge, lang)}</span>
            </span>
            <h2 className="font-display break-words text-2xl font-extrabold uppercase leading-tight tracking-wide text-ink sm:text-3xl lg:text-4xl">
              {loc(section.title, lang)}
            </h2>
            <p className="mt-2 max-w-3xl text-sm leading-relaxed text-muted sm:text-base">
              {loc(section.subtitle, lang)}
            </p>
          </div>

          <div className="flex shrink-0 flex-wrap items-center gap-2 sm:gap-3">
            {source?.kind === "file" && (
              <button
                type="button"
                onClick={toggleMute}
                className="inline-flex items-center gap-2 rounded-xl border border-line bg-surface px-3.5 py-2.5 font-display text-xs font-bold uppercase tracking-wider text-ink shadow-sm transition-all duration-200 hover:border-lime-500/60 hover:bg-lime-500/10 hover:text-lime-600 sm:px-4 sm:text-sm"
                aria-label={muted ? t("video.unmute") : t("video.mute")}
              >
                {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                {muted ? t("video.unmute") : t("video.mute")}
              </button>
            )}

            <a
              href={youtubeLink}
              target="_blank"
              rel="noreferrer"
              className="group inline-flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 font-display text-xs font-bold uppercase tracking-wider text-white shadow-lg transition-all duration-200 hover:border-lime-500/60 hover:bg-lime-500/20 hover:text-lime-300 sm:px-4 sm:text-sm"
            >
              <YoutubeIcon size={17} />
              <span className="whitespace-nowrap">
                {loc(section.ctaLabel, lang) || "VOIR SUR YOUTUBE"}
              </span>
              <ExternalLink
                size={14}
                className="opacity-60 transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:opacity-100"
              />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}