/** Backward-compatible export for existing imports. */
export { default } from "./VideoSection";
