import { useEffect, useState } from "react";
import type { CSSProperties } from "react";

type LogoKind = "transparent" | "whiteBox" | "unknown";

export interface LogoAppearance {
  style: CSSProperties;
  description: string;
}

/**
 * Decides how a logo should blend into its surface.
 *
 * - Light surface: multiply removes any white box while leaving a transparent
 *   logo and its colours untouched.
 * - Dark surface: a transparent logo is drawn as-is (plus a soft shadow so a
 *   black banner still separates from a dark header). A white-boxed logo gets
 *   `invert + hue-rotate` — swaps luminance while preserving hue — then `screen`
 *   so the white box disappears. Unknown/cross-origin images are never filtered,
 *   because blindly inverting a coloured logo like Ironman's destroys it.
 */
export function useLogoAppearance(src: string, dark: boolean): LogoAppearance {
  const [kind, setKind] = useState<LogoKind>("unknown");

  useEffect(() => {
    if (!src) {
      setKind("unknown");
      return;
    }
    let cancelled = false;

    const classify = (image: HTMLImageElement): LogoKind => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = 32;
        canvas.height = 32;
        const ctx = canvas.getContext("2d", { willReadFrequently: true });
        if (!ctx) throw new Error("2d context unavailable");
        ctx.drawImage(image, 0, 0, 32, 32);
        const data = ctx.getImageData(0, 0, 32, 32).data;

        const points = [
          [1, 1], [30, 1], [1, 30], [30, 30],
          [15, 1], [15, 30], [1, 15], [30, 15],
        ];
        let transparent = 0;
        let white = 0;
        for (const [x, y] of points) {
          const index = (y * 32 + x) * 4;
          const r = data[index];
          const g = data[index + 1];
          const b = data[index + 2];
          const a = data[index + 3];
          if (a < 12) transparent++;
          else if (r > 232 && g > 232 && b > 232) white++;
        }
        if (transparent >= 5) return "transparent";
        if (white >= 5) return "whiteBox";
        return "unknown";
      } catch {
        return "unknown";
      }
    };

    const probe = new Image();
    if (/^https?:/i.test(src)) probe.crossOrigin = "anonymous";
    probe.onload = () => {
      if (!cancelled) setKind(classify(probe));
    };
    probe.onerror = () => {
      if (!cancelled) setKind("unknown");
    };
    probe.src = src;

    return () => {
      cancelled = true;
    };
  }, [src]);

  if (!dark) {
    return {
      style: { mixBlendMode: "multiply" },
      description: "multiply (light surface, white box removed)",
    };
  }

  if (kind === "whiteBox") {
    return {
      style: {
        mixBlendMode: "screen",
        filter: "invert(1) hue-rotate(180deg) saturate(1.18) brightness(1.04)",
      },
      description: "invert + hue-rotate + screen (white box removed on dark)",
    };
  }

  return {
    style: {
      mixBlendMode: "normal",
      filter: "drop-shadow(0 2px 10px rgba(0,0,0,0.55))",
    },
    description: "transparent logo, no filter (dark surface)",
  };
}
