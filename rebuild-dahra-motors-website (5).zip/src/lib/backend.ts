import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { CmsState } from "./types";

/**
 * Central persistence layer for the Dahra Motors CMS.
 *
 * Mode selection (checked at runtime, no build failure if unset):
 *   1. "supabase"    — central Postgres row, realtime across all users/devices.
 *   2. "localStorage" — offline-first fallback (always written as a cache).
 *
 * Configure via environment variables in `.env.local`:
 *   VITE_SUPABASE_URL=https://xxxx.supabase.co
 *   VITE_SUPABASE_ANON_KEY=eyJhbGciOi...
 *
 * Table (see /supabase/schema.sql):
 *   dahra_cms(id text primary key, data jsonb, updated_at timestamptz)
 */

const TABLE = "dahra_cms";
const ROW_ID = "dahra-motors";

type Env = Record<string, string | undefined>;
const env: Env = ((import.meta as unknown as { env?: Env }).env ?? {}) as Env;

export const SUPABASE_URL = env.VITE_SUPABASE_URL ?? "";
export const SUPABASE_ANON_KEY = env.VITE_SUPABASE_ANON_KEY ?? "";

export const REMOTE_ENABLED = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);
export type BackendMode = "supabase" | "localStorage";
export const getMode = (): BackendMode => (REMOTE_ENABLED ? "supabase" : "localStorage");

let client: SupabaseClient | null = null;
function db(): SupabaseClient | null {
  if (!REMOTE_ENABLED) return null;
  if (!client) {
    client = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: { persistSession: false, autoRefreshToken: false },
      realtime: { params: { eventsPerSecond: 10 } },
    });
  }
  return client;
}

/** Read the central document. Returns null when unavailable. */
export async function pullState(): Promise<CmsState | null> {
  const sb = db();
  if (!sb) return null;
  try {
    const { data, error } = await sb.from(TABLE).select("data").eq("id", ROW_ID).maybeSingle();
    if (error) {
      console.warn("[dahra-backend] pull failed:", error.message);
      return null;
    }
    const state = (data as { data?: CmsState } | null)?.data;
    return state && state.settings ? state : null;
  } catch (e) {
    console.warn("[dahra-backend] pull error:", e);
    return null;
  }
}

/** Write the whole CMS document (last-write-wins). Returns success. */
export async function pushState(state: CmsState): Promise<boolean> {
  const sb = db();
  if (!sb) return false;
  try {
    const { error } = await sb.from(TABLE).upsert({
      id: ROW_ID,
      data: state as unknown as Record<string, unknown>,
      updated_at: new Date().toISOString(),
    });
    if (error) {
      console.warn("[dahra-backend] push failed:", error.message);
      return false;
    }
    return true;
  } catch (e) {
    console.warn("[dahra-backend] push error:", e);
    return false;
  }
}

/**
 * Subscribe to central changes. Every open tab / connected client receives the
 * new document instantly through Supabase Realtime.
 */
export function subscribe(onRemote: (state: CmsState) => void): () => void {
  const sb = db();
  if (!sb) return () => {};
  try {
    const channel = sb
      .channel(`dahra-cms-${ROW_ID}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: TABLE, filter: `id=eq.${ROW_ID}` },
        (payload) => {
          const next = (payload.new as { data?: CmsState } | null)?.data;
          if (next && next.settings) onRemote(next);
        }
      )
      .subscribe();
    return () => {
      try {
        sb.removeChannel(channel);
      } catch {
        /* channel already closed */
      }
    };
  } catch (e) {
    console.warn("[dahra-backend] subscribe error:", e);
    return () => {};
  }
}
