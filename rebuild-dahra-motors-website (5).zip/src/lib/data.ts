import type {
  CmsState,
  Product,
  Category,
  ContactLine,
  HeroSlide,
  GalleryItem,
  VideoSection,
  Settings,
  Credentials,
  SiteContent,
} from "./types";
import {
  PRODUCT_IMAGE_VERSION,
  curateProductImage,
  normalizeCmsProductImages,
} from "./productImages";
import {
  AMORTISSEUR_PRODUCTS,
  SUSPENSION_CATALOG_VERSION,
  mergeSuspensionCatalog,
} from "./suspensionCatalog";
import {
  PRICE_ROUNDING_VERSION,
  normalizeCmsPrices,
  roundDzdPrice,
  roundProductPrices,
} from "./pricing";

/* ================================================================== */
/*  HARD DEFAULTS — phone & coverage (per brand spec)                  */
/* ================================================================== */

export const DEFAULT_PHONE = "0550 03 08 96";
export const DEFAULT_WHATSAPP = "213560030896";
export const WILAYAS_LABEL = "69 Wilayas";

/** Top announcement bar — hardcoded brand constant (never translated away). */
export const ANNOUNCEMENT =
  "DISTRIBUTEUR OFFICIEL IRONMAN 4X4 — LIVRAISON 69 WILAYAS — PAIEMENT À LA LIVRAISON";

/** Pre-filled greeting attached to every WhatsApp CTA on the site. */
export const WHATSAPP_GREETING =
  "Bonjour Dahra Motors, je vous contacte depuis votre site web pour une demande d'information.";

/** Header contact dropdown — exact structure, labels and dial targets. */
export const CONTACT_LINES: ContactLine[] = [
  {
    label: "Mobile 1",
    value: "0550 03 08 96",
    kind: "mobile",
    href: "tel:0550030896",
  },
  {
    label: "Mobile 2",
    value: "0560 03 08 95",
    kind: "mobile",
    href: "tel:0560030895",
  },
  {
    label: "Mobile 3",
    value: "0560 03 08 97",
    kind: "mobile",
    href: "tel:0560030897",
  },
  {
    label: "Ligne Fixe",
    value: "028 30 63 26",
    kind: "fixe",
    href: "tel:028306326",
  },
  {
    label: "WhatsApp Support",
    value: "0560030896",
    kind: "whatsapp",
    href: "https://wa.me/213560030896",
  },
];

/* ================================================================== */
/*  58 Wilayas (COD delivery select)                                   */
/* ================================================================== */

export const WILAYAS = [
  "01 - Adrar", "02 - Chlef", "03 - Laghouat", "04 - Oum El Bouaghi", "05 - Batna",
  "06 - Béjaïa", "07 - Biskra", "08 - Béchar", "09 - Blida", "10 - Bouira",
  "11 - Tamanrasset", "12 - Tébessa", "13 - Tlemcen", "14 - Tiaret", "15 - Tizi Ouzou",
  "16 - Alger", "17 - Djelfa", "18 - Jijel", "19 - Sétif", "20 - Saïda",
  "21 - Skikda", "22 - Sidi Bel Abbès", "23 - Annaba", "24 - Guelma", "25 - Constantine",
  "26 - Médéa", "27 - Mostaganem", "28 - M'Sila", "29 - Mascara", "30 - Ouargla",
  "31 - Oran", "32 - El Bayadh", "33 - Illizi", "34 - Bordj Bou Arréridj", "35 - Boumerdès",
  "36 - El Tarf", "37 - Tindouf", "38 - Tissemsilt", "39 - El Oued", "40 - Khenchela",
  "41 - Souk Ahras", "42 - Tipaza", "43 - Mila", "44 - Aïn Defla", "45 - Naâma",
  "46 - Aïn Témouchent", "47 - Ghardaïa", "48 - Relizane", "49 - Timimoun",
  "50 - Bordj Badji Mokhtar", "51 - Ouled Djellal", "52 - Béni Abbès", "53 - In Salah",
  "54 - In Guezzam", "55 - Touggourt", "56 - Djanet", "57 - El M'Ghair", "58 - El Meniaa",
];

/* Vehicle roster and fitment matching live in src/lib/vehicles.ts. */
export { VEHICLE_DATABASE } from "./vehicles";

/* ================================================================== */
/*  Image helpers                                                      */
/*  - Local product photos live in public/images/                      */
/*  - Pexels hotlinks for lifestyle / category photography             */
/* ================================================================== */

const px = (id: number, w = 1200): string =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=${Math.round(w * 0.5208)}&w=${w}`;

const IMG = {
  heroMud: px(10196543),
  heroTimimoun: px(10604483),
  heroDunes: px(5812065),
  mudRacing: px(38263042),
  mud4x4: px(28144831),
  fordCustom: px(16033915),
  redBullHilux: px(16668789),
  forestTruck: px(39019969),
  rooftopTent: px(35588405),
  camperFog: px(18736323),
  winchClose: px(16805262),
  towRope: px(16805264),
  recovery: px(29548896),
  suspension: px(33024451),
  red4x4Mud: px(21875995),
  offroadLake: px(38257043),
  ledNight: px(16884778),
  headlights: px(12823334),
  dustyToyota: px(30657921),
  tireSand: px(4996769),
  tireMud: px(11794391),
  f150Desert: px(16004296),
  convoy: px(10658203),
  camping: px(32973162),
  forestCamping: px(32973534),
  gmc: px(15777751),
  coastTruck: px(8146244),
  undercarriage: px(8986137),
} as const;

/** Official Ironman 4x4 IM2.5 Monotube suspension showcase. */
export const IRONMAN_VIDEO_ID = "X_MdJuPfg_0";
export const IRONMAN_VIDEO_EMBED_URL =
  "https://www.youtube.com/embed/X_MdJuPfg_0?autoplay=1&mute=1&loop=1&playlist=X_MdJuPfg_0";
export const IRONMAN_VIDEO_WATCH_URL = "https://youtu.be/X_MdJuPfg_0";
export const IRONMAN_VIDEO_POSTER =
  "https://i.ytimg.com/vi/X_MdJuPfg_0/maxresdefault.jpg";

/** Previous factory source; used only to upgrade unchanged legacy content. */
const LEGACY_FACTORY_VIDEO_URL =
  "https://videos.pexels.com/video-files/17798063/17798063-uhd_3840_2160_30fps.mp4";

/* ================================================================== */
/*  Categories (original 8 + CANOPY + TREUIL/WINCH; recovery renamed)  */
/* ================================================================== */

export const DEFAULT_CATEGORIES: Category[] = [
  {
    id: "cat-suspension",
    slug: "suspension",
    name: { fr: "Suspension & Lift Kits", ar: "نظام التعليق ورفعات الهيكل" },
    image: IMG.suspension,
    description: {
      fr: "Kits complets, Nitro Gas, Foam Cell, Foam Cell Pro, IM2.5 Monotube, ressorts et composants Ironman 4x4.",
      ar: "أطقم كاملة، نيترو غاز، فوم سيل، IM2.5، نوابض ومكونات آيرون مان 4x4.",
    },
    active: true,
  },
  {
    id: "cat-protection",
    slug: "protection",
    name: { fr: "BLINDAGE / PROTECTION", ar: "حماية وتعزيز الهيكل" },
    image: IMG.fordCustom,
    description: {
      fr: "Pare-buffles acier, protections soubassement et side steps.",
      ar: "مصاعد فولاذية أمامية، حماية الهيكل السفلي ودرجات جانبية.",
    },
    active: true,
  },
  {
    id: "cat-roof",
    slug: "roof-racks",
    name: { fr: "Roof Racks & Tentes", ar: "حاملات السقف والخيام" },
    image: IMG.rooftopTent,
    description: {
      fr: "Galeries aluminium, tentes de toit et auvents Ironman 4x4.",
      ar: "حاملات ألمنيوم للسقف، خيام سقف ومظلات آيرون مان 4x4.",
    },
    active: true,
  },
  {
    id: "cat-snorkel",
    slug: "snorkels",
    name: { fr: "Snorkels & Admission", ar: "أنابيب الغطس والسحب" },
    image: IMG.red4x4Mud,
    description: {
      fr: "Snorkels haute performance pour traversées et pistes sablonneuses.",
      ar: "أنابيب غطس عالية الأداء لعبور الأنهار والمسالك الرملية.",
    },
    active: true,
  },
  {
    id: "cat-recovery",
    slug: "recovery",
    name: { fr: "RECOVERY / RECUPERATION", ar: "الإنقاذ والاستخلاص" },
    image: IMG.recovery,
    description: {
      fr: "Recovery & Sand Tracks — plaques de désensablage, pins et supports pour sortir de n'importe quel sable.",
      ar: "الإنقاذ — ألواح الخروج من الرمل، مسامير ودعامات.",
    },
    active: true,
  },
  {
    id: "cat-winch",
    slug: "treuil-winch",
    name: { fr: "TREUIL / WINCH", ar: "الونش" },
    image: IMG.towRope,
    description: {
      fr: "Winches & Accessories — treuils synthétique et câble acier, télécommandes, guides de câble et sangles.",
      ar: "الونش وملحقاته — ونشات حبل صناعي وكابيل فولاذي، وحدات تحكم ودلائل.",
    },
    active: true,
  },
  {
    id: "cat-camping",
    slug: "camping",
    name: { fr: "CAMPING", ar: "التخييم" },
    image: IMG.camping,
    description: {
      fr: "Water Tanks & Hose — réservoirs d'eau IWT, tuyaux, réfrigérateurs et équipement de bivouac.",
      ar: "خزانات الماء والخرطوم — خزانات IWT، ثلاجات محمولة ومعدات التخييم.",
    },
    active: true,
  },
  {
    id: "cat-canopy",
    slug: "canopy",
    name: { fr: "CANOPY", ar: "قواطع الحوض" },
    image: IMG.camperFog,
    description: {
      fr: "Canopies rigides aluminium pour pickup — Navara, Ranger et plus.",
      ar: "قواطع حوض صلبة من الألومنيوم — نافارا، رانجر وغيرها.",
    },
    active: true,
  },
  {
    id: "cat-lighting",
    slug: "lighting",
    name: { fr: "Éclairage & Électrique", ar: "الإضاءة والكهرباء" },
    image: IMG.ledNight,
    description: {
      fr: "Barres LED, batteries AGM double système et compresseurs.",
      ar: "أشرطة إضاءة LED، بطاريات AGM مزدوجة ومضخات هواء.",
    },
    active: true,
  },
  {
    id: "cat-tires",
    slug: "wheels-tires",
    name: { fr: "Roues & Pneumatiques", ar: "العجلات والإطارات" },
    image: IMG.tireSand,
    description: {
      fr: "Jantes alliage tout-terrain et pneus All-Terrain / Mud-Terrain.",
      ar: "جنوط ألمنيوم للطرق الوعرة وإطارات All-Terrain / Mud-Terrain.",
    },
    active: true,
  },
  {
    id: "cat-bumper-front",
    slug: "pare-choc-avant",
    name: { fr: "PARE CHOC AVANT", ar: "مصاصات أمامية" },
    image: IMG.redBullHilux,
    description: {
      fr: "Front Bumpers / Protection — pare-chocs et renforts avant Ironman 4x4 en acier.",
      ar: "مصاصات أمامية وحماية — مصاصات فولاذية من آيرون مان 4x4.",
    },
    active: true,
  },
  {
    id: "cat-bumper-rear",
    slug: "pare-choc-arriere",
    name: { fr: "PARE CHOC ARRIÈRE", ar: "مصاصات خلفية" },
    image: IMG.coastTruck,
    description: {
      fr: "Rear Bumpers — pare-chocs arrière acier avec protection de plaque.",
      ar: "مصاصات خلفية — مصاصات فولاذية مع حماية اللوحة.",
    },
    active: true,
  },
  {
    id: "cat-side-steps",
    slug: "marche-pied",
    name: { fr: "MARCHE PIED", ar: "درجات جانبية" },
    image: IMG.gmc,
    description: {
      fr: "Side Steps / Running Boards — marche-pieds acier et aluminium, montage d'origine.",
      ar: "درجات جانبية — درجات فولاذية وألومنيوم بتركيب أصلي.",
    },
    active: true,
  },
];

/* ================================================================== */
/*  Products — seeded catalog                                          */
/*  Defaults per spec: stock 1 · price 100 · featured true             */
/*  · showLowStockBadge (stock_limite) false · active true             */
/* ================================================================== */

function P(
  id: string,
  sku: string,
  name: string,
  nameAr: string,
  categorySlug: string,
  image: string,
  shortDescription: string,
  fitment: string[],
  opts: Partial<Product> = {}
): Product {
  return {
    id,
    sku,
    name,
    nameAr,
    categorySlug,
    price: 100,
    oldPrice: null,
    stock: 1,
    badge: "",
    image,
    images: [],
    shortDescription,
    problem:
      "Pièces non adaptées aux pistes algériennes : usure rapide, pannes en pleine excursion et surcoûts de réparation.",
    solution:
      "Une pièce testée en conditions extrêmes, installée par nos techniciens et couverte par la garantie officielle Dahra Motors / Ironman 4x4.",
    features: [
      "Qualité d'origine garantie",
      "Testée en conditions extrêmes",
      "Installation experte disponible",
    ],
    specs: [],
    fitment,
    warranty: "Garantie officielle — pièces Ironman 4x4",
    active: true,
    featured: true,
    showLowStockBadge: false,
    showDiscountBadge: false,
    ...opts,
  };
}

const BASE_PRODUCTS: Product[] = [
  /* ----------------------------- CANOPY ----------------------------- */
  P(
    "p-canopy-003",
    "CANOPY003-P",
    "Canopy Hardtop Ironman 4x4 (Nissan Navara D40)",
    "قاطع حوض نيسان نافارا D40",
    "canopy",
    "/images/canopy-navara.jpg",
    "Canopy rigide aluminium, verrous intégrés, compatible benne Navara D40 (2005-2015).",
    ["Nissan Navara D40 (2005–2015)"],
    {
      badge: "Nouveau",
      features: [
        "Structure aluminium anodisé",
        "Double verrouillage de sécurité",
        "Joints étanches IP54",
      ],
      specs: [
        { label: "Matériau", value: "Aluminium 6061" },
        { label: "Poids", value: "58 kg" },
        { label: "Fixation", value: "Rails de caisse d'origine" },
      ],
    }
  ),
  P(
    "p-canopy-010",
    "CANOPY010-P",
    "Canopy Hardtop Ironman 4x4 (Ford Ranger)",
    "قاطع حوض فورد رانجر",
    "canopy",
    "/images/canopy-ford.jpg",
    "Canopy rigide aluminium avec porte arrière, pensée pour la Ranger 2012+.",
    ["Ford Ranger (2012–2026)"],
    {
      badge: "Nouveau",
      features: [
        "Structure aluminium anodisé",
        "Porte arrière + porte latérale",
        "Prise d'extension électrique incluse",
      ],
      specs: [
        { label: "Matériau", value: "Aluminium 6061" },
        { label: "Poids", value: "62 kg" },
      ],
    }
  ),
  P(
    "p-canopy-013pw",
    "CANOPY013-PW",
    "Canopy Hardtop Ironman 4x4 (Nissan Navara D23)",
    "قاطع حوض نيسان نافارا D23",
    "canopy",
    "/images/canopy-navara.jpg",
    "Canopy rigide pour génération Navara D23 — finition pro, montage direct.",
    ["Nissan Navara D23 (2001–2005)"],
    {
      features: ["Structure aluminium anodisé", "Double verrouillage", "Joints étanches"],
      specs: [{ label: "Matériau", value: "Aluminium 6061" }, { label: "Poids", value: "55 kg" }],
    }
  ),

  /* ---------------------- CAMPING — Water tanks --------------------- */
  P(
    "p-iwt001",
    "IWT001",
    "Réservoir d'eau 20L",
    "خزان ماء 20 لتر",
    "camping",
    "/images/tank-20.jpg",
    "Réservoir d'eau portable 20L en HDPE, bouchon blanc + vanne de vidange.",
    ["Universel — montage sur galerie ou caisse"],
    {
      features: ["HDPE alimentaire", "Vanne de vidange", "Bouchon étanche"],
      specs: [
        { label: "Capacité", value: "20 L" },
        { label: "Matériau", value: "HDPE alimentaire" },
      ],
    }
  ),
  P(
    "p-iwt002",
    "IWT002",
    "Réservoir d'eau 40L",
    "خزان ماء 40 لتر",
    "camping",
    "/images/tank-40.jpg",
    "Réservoir d'eau 40L, format carré compact, idéal sur galerie de toit.",
    ["Universel — montage sur galerie ou caisse"],
    {
      features: ["HDPE alimentaire", "Vanne de vidange", "Format compact"],
      specs: [
        { label: "Capacité", value: "40 L" },
        { label: "Matériau", value: "HDPE alimentaire" },
      ],
    }
  ),
  P(
    "p-iwt003",
    "IWT003",
    "Réservoir d'eau 40L",
    "خزان ماء 40 لتر",
    "camping",
    "/images/tank-40.jpg",
    "Réservoir d'eau 40L — version avec renforts latéraux pour transport hors-piste.",
    ["Universel — montage sur galerie ou caisse"],
    {
      features: ["Renforts latéraux", "Vanne de vidange", "Compatible pomper"],
      specs: [
        { label: "Capacité", value: "40 L" },
        { label: "Matériau", value: "HDPE renforcé" },
      ],
    }
  ),
  P(
    "p-iwt004",
    "IWT004",
    "Réservoir d'eau 50L",
    "خزان ماء 50 لتر",
    "camping",
    "/images/tank-50.jpg",
    "Grand réservoir 50L bleu, robinet métal — autonomie longue pour l'overlanding.",
    ["Universel — montage sur galerie, caisse ou remorque"],
    {
      badge: "Best Seller",
      features: ["Grand volume 50L", "Robinet métal", "HDPE haute densité"],
      specs: [
        { label: "Capacité", value: "50 L" },
        { label: "Matériau", value: "HDPE alimentaire" },
      ],
    }
  ),
  P(
    "p-iwt005",
    "IWT005",
    "Réservoir d'eau 50L",
    "خزان ماء 50 لتر",
    "camping",
    "/images/tank-50.jpg",
    "Réservoir 50L — version double bouchon de remplissage, remplissage rapide.",
    ["Universel — montage sur galerie, caisse ou remorque"],
    {
      features: ["Double bouchon", "Robinet métal", "Transport sécurisé"],
      specs: [
        { label: "Capacité", value: "50 L" },
        { label: "Matériau", value: "HDPE alimentaire" },
      ],
    }
  ),
  P(
    "p-iwt006",
    "IWT006",
    "Réservoir d'eau 50L",
    "خزان ماء 50 لتر",
    "camping",
    "/images/tank-50.jpg",
    "Réservoir 50L — version renforcée sable/désert, base antidérapante.",
    ["Universel — montage sur galerie, caisse ou remorque"],
    {
      features: ["Base antidérapante", "Renfort sable", "Robinet métal"],
      specs: [
        { label: "Capacité", value: "50 L" },
        { label: "Matériau", value: "HDPE renforcé" },
      ],
    }
  ),
  P(
    "p-iwthose",
    "IWTHOSE",
    "Tuyau et kit de connexion pour réservoir d'eau",
    "خرطوم",
    "camping",
    "/images/hose.jpg",
    "Tuyau de transfert d'eau flexible, embouts à visser compatibles réservoirs IWT.",
    ["Compatible réservoirs IWT 20/40/50L"],
    {
      features: ["Flexible haute pression", "Embout à visser", "Transparence contrôlée"],
      specs: [{ label: "Longueur", value: "1,5 m" }, { label: "Diamètre", value: "12 mm" }],
    }
  ),
  P(
    "p-fridge-45",
    "IFR45",
    "Réfrigérateur portatif 45L",
    "ثلاجة محمولة 45 لتر",
    "camping",
    IMG.camping,
    "Frigorificateur/compresseur 12V-24V, 45L, contrôle précis pour bivouac long.",
    ["12V / 24V — véhicule ou secteur"],
    {
      features: ["Compresseur inverter", "-20°C à +10°C", "Mode camping/voiture"],
      specs: [{ label: "Capacité", value: "45 L" }, { label: "Tension", value: "12/24V" }],
    }
  ),
  P(
    "p-awning-2500",
    "IAW2500",
    "Auvent de toit 2,50 m",
    "مظلة سقف 2.5 م",
    "camping",
    IMG.forestCamping,
    "Auvent latéral 2,50 m avec bras de soutien — zone de vie ombragée instantanée.",
    ["Galerie de toit ou rail dédié"],
    {
      features: ["Toile 600D traitée", "Bras réglable", "Sac de transport"],
      specs: [{ label: "Largeur", value: "2,50 m" }, { label: "Toile", value: "600D" }],
    }
  ),

  /* ----------------- RECOVERY / RECUPERATION ------------------------ */
  P(
    "p-irecbd-green",
    "IRECBDGREEN",
    "Plaque de désensablage Green",
    "لوحة الخروج من الرمل — خضراء",
    "recovery",
    "/images/sandboard-green.jpg",
    "Plaque de traction composite verte, grip renforcé, D-rings de treuil intégrés.",
    ["Universel 4x4"],
    {
      badge: "Best Seller",
      features: ["Composite haute résistance", "Motif grip anti-glisse", "2 D-rings treuil"],
      specs: [{ label: "Charge max", value: "2 500 kg" }, { label: "Poids", value: "9,5 kg" }],
    }
  ),
  P(
    "p-irecbd-grey",
    "IRECBDGREY",
    "Plaque de désensablage (Grey)",
    "لوحة الخروج من الرمل — رمادية",
    "recovery",
    "/images/sandboard-grey.jpg",
    "Plaque de traction composite grise — même structure que la version Green.",
    ["Universel 4x4"],
    {
      features: ["Composite haute résistance", "Motif grip anti-glisse", "2 D-rings treuil"],
      specs: [{ label: "Charge max", value: "2 500 kg" }, { label: "Poids", value: "9,5 kg" }],
    }
  ),
  P(
    "p-irecbd-sand",
    "IRECBDSAND",
    "Plaque de désensablage (Sand)",
    "لوحة الخروج من الرمل — رملية",
    "recovery",
    "/images/sandboard-sand.jpg",
    "Plaque de traction couleur sable — discrète en dune, grip maximal.",
    ["Universel 4x4"],
    {
      features: ["Coloris désert", "Motif grip anti-glisse", "2 D-rings treuil"],
      specs: [{ label: "Charge max", value: "2 500 kg" }, { label: "Poids", value: "9,5 kg" }],
    }
  ),
  P(
    "p-irecbd-pins",
    "IRECBDPINS115",
    "Pins de fixation pour plaques",
    "مسامير التثبيت",
    "recovery",
    "/images/sandboard-green.jpg",
    "Kit de pins 115 mm pour fixer les plaques de désensablage au véhicule.",
    ["Compatible plaques IRECBD"],
    {
      features: ["Acier zinc", "Kit complet de fixation", "Inoxydable"],
      specs: [{ label: "Longueur", value: "115 mm" }, { label: "Matériau", value: "Acier zinc" }],
    }
  ),
  P(
    "p-irecbd-rdbase",
    "IRECBRDBASE",
    "Support et base pour plaques de désensablage",
    "حامل اللوحة",
    "recovery",
    "/images/sandboard-sand.jpg",
    "Support de rangement pour plaque de désensablage — stockage propre et rapide.",
    ["Caisse ou soubassement"],
    {
      features: ["Acier galvanisé", "Montage vissé", "Accès rapide"],
      specs: [{ label: "Matériau", value: "Acier galvanisé" }],
    }
  ),

  /* ------------------------- TREUIL / WINCH ------------------------- */
  P(
    "p-imw-12000msr",
    "IMW12000_MSR",
    "Treuil synthétique 5.4T",
    "ونش حبل صناعي 5.4 طن",
    "treuil-winch",
    "/images/winch-kit.jpg",
    "Treuil 12 000 lbs (5,4 T) sur corde synthétique — plus léger, plus sûr.",
    ["Pickup & SUV 4x4 (1 800–3 500 kg)"],
    {
      badge: "Best Seller",
      features: [
        "12 000 lbs / 5,4 T",
        "Corde synthétique incluse",
        "Témoin de fin de bobine",
      ],
      specs: [
        { label: "Traction", value: "5,4 T" },
        { label: "Corde", value: "Synthétique 10 mm × 22 m" },
        { label: "Moteur", value: "12V 6,2 kW" },
      ],
    }
  ),
  P(
    "p-imw-12000mwr",
    "IMW12000MWR",
    "Treuil câble acier 5.4T",
    "ونش كابيل فولاذي 5.4 طن",
    "treuil-winch",
    IMG.winchClose,
    "Treuil 12 000 lbs (5,4 T) sur câble acier 8 mm — puissance maximale.",
    ["Pickup & SUV 4x4 (1 800–3 500 kg)"],
    {
      features: ["12 000 lbs / 5,4 T", "Câble acier 8 mm × 24 m", "Roues de frein double"],
      specs: [
        { label: "Traction", value: "5,4 T" },
        { label: "Câble", value: "Acier 8 mm × 24 m" },
      ],
    }
  ),
  P(
    "p-imw-9500msr",
    "IMW9500_MSR",
    "Treuil synthétique 4.3T",
    "ونش حبل صناعي 4.3 طن",
    "treuil-winch",
    "/images/winch-kit.jpg",
    "Treuil 9 500 lbs (4,3 T) sur corde synthétique — le format idéal pickup.",
    ["Pickup & SUV 4x4 (1 300–2 500 kg)"],
    {
      features: ["9 500 lbs / 4,3 T", "Corde synthétique incluse", "Compact et léger"],
      specs: [
        { label: "Traction", value: "4,3 T" },
        { label: "Corde", value: "Synthétique 10 mm × 19 m" },
      ],
    }
  ),
  P(
    "p-wwb-9500",
    "WWB9500",
    "Treuil câble acier 4.3T",
    "ونش كابيل فولاذي 4.3 طن",
    "treuil-winch",
    IMG.winchClose,
    "Treuil 9 500 lbs (4,3 T) câble acier — robustesse de référence.",
    ["Pickup & SUV 4x4 (1 300–2 500 kg)"],
    {
      features: ["9 500 lbs / 4,3 T", "Câble acier 8 mm × 20 m", "Plaque de montage incluse"],
      specs: [
        { label: "Traction", value: "4,3 T" },
        { label: "Câble", value: "Acier 8 mm × 20 m" },
      ],
    }
  ),
  P(
    "p-wwb-001",
    "WWB001",
    "Télécommande sans fil pour treuil",
    "وحدة تحكم لاسلكية",
    "treuil-winch",
    "/images/winch-kit.jpg",
    "Télécommande sans fil du treuil — commande in et out sans quitter le véhicule.",
    ["Universel treuils"],
    {
      features: ["Portée 30 m", "IP67", "Boutons anti-sollicitation"],
      specs: [{ label: "Portée", value: "30 m" }, { label: "IP", value: "IP67" }],
    }
  ),
  P(
    "p-wwb-015",
    "WWB015",
    "Prise sans fil",
    "مستقبل لاسلكي",
    "treuil-winch",
    "/images/winch-kit.jpg",
    "Module récepteur sans fil du treuil — à fixer près de la batterie.",
    ["Universel treuils"],
    {
      features: ["Reçu haute sensibilité", "Câblage inclus", "Montage rapide"],
      specs: [{ label: "Fréquence", value: "433 MHz" }],
    }
  ),
  P(
    "p-wwb-031",
    "WWB031",
    "Rallonge pour treuil",
    "وصلة تمديد",
    "treuil-winch",
    "/images/winch-kit.jpg",
    "Rallonge treuil pour opérations longues et doubles points d'ancrage.",
    ["Universel treuils"],
    {
      features: ["Mâchoire + œillet", "Acier trempé", "Sécurité double"],
      specs: [{ label: "Longueur", value: "9,1 m" }],
    }
  ),
  P(
    "p-winch-blanket",
    "WINCHBLANKET",
    "Sangle / Accessoire de sécurité treuil",
    "واقي أمان الونش",
    "treuil-winch",
    "/images/winch-kit.jpg",
    "Bâche de sécurité : absorbe l'énergie d'une corde en rupture.",
    ["Universel treuils"],
    {
      features: ["Élastomère haute énergie", "Couvre 6 m", "Pochette incluse"],
      specs: [{ label: "Couverture", value: "6 m" }],
    }
  ),
  P(
    "p-www-fairelead",
    "WWWFAIRELEAD",
    "Guide de câble acier",
    "دليل كابيل فولاذي",
    "treuil-winch",
    "/images/winch-kit.jpg",
    "Fairelead acier — protège le câble aux points de flexion.",
    ["Universel treuil câble acier"],
    {
      features: ["Acier usiné CNC", "Roulement intégré", "Usure réduite"],
      specs: [{ label: "Matériau", value: "Acier" }],
    }
  ),
  P(
    "p-www-hawse",
    "WWWHAWSE",
    "Guide de câble synthétique",
    "دليل حبل صناعي",
    "treuil-winch",
    "/images/winch-kit.jpg",
    "Hawse fairlead — guide doux pour corde synthétique, zéro abrasion.",
    ["Universel treuil synthétique"],
    {
      features: ["Surface usinée douce", "Acier 304", "Prolonge la vie de la corde"],
      specs: [{ label: "Matériau", value: "Acier 304" }],
    }
  ),
  P(
    "p-www-rope001",
    "WWWROPE001",
    "Corde synthétique de rechange",
    "حبل صناعي",
    "treuil-winch",
    "/images/winch-kit.jpg",
    "Corde synthétique 10 mm — faible stockage d'énergie, sécurité accrue.",
    ["Universel treuil synthétique"],
    {
      features: ["Polyester 10 mm", "22 m", "Enduction anti-UV"],
      specs: [{ label: "Diamètre", value: "10 mm" }, { label: "Longueur", value: "22 m" }],
    }
  ),

  /* --------------------------- SUSPENSION --------------------------- */
  P(
    "p-fcp-kit-hilux",
    "IFCPKIT-HILUX",
    "Kit suspension Foam Cell Pro Hilux",
    "طقم تعليق فوم سيل برو هيلوكس",
    "suspension",
    IMG.mud4x4,
    "Amortisseurs Foam Cell Pro + ressorts — le kit complet pour la Hilux 2005+.",
    ["Toyota Hilux (2005–2026)"],
    {
      badge: "Best Seller",
      features: [
        "Chambre à mousse exclusive",
        "Ressorts renforcés inclus",
        "Kit complet AV/AR",
      ],
      specs: [
        { label: "Type", value: "Gaz + mousse" },
        { label: "Régulation", value: "Rebond/Compression" },
      ],
    }
  ),
  P(
    "p-fcp-shock",
    "IFCP-SHOCK",
    "Amortisseur Foam Cell Pro (unité)",
    "ممتص صدمات فوم سيل برو (وحدة)",
    "suspension",
    IMG.suspension,
    "Amortisseur gaz + mousse, vendu à l'unité — régulation externe.",
    ["Vérifier compatibilité par modèle"],
    {
      features: ["Chambre à mousse", "Régulation externe", "Carénage peinture"],
      specs: [{ label: "Type", value: "Gaz + mousse" }],
    }
  ),
  P(
    "p-fcp-kit-prado",
    "IFCPKIT-PRADO",
    "Kit suspension Prado Heavy Duty",
    "طقم تعليق برادو للمهام الشاقة",
    "suspension",
    IMG.offroadLake,
    "Kit heavy duty pour Prado — charge élevée sans compromis de confort.",
    ["Toyota Land Cruiser Prado (2003–2026)"],
    {
      features: ["Ressorts HD", "Amortisseurs réglables", "Support charge +300 kg"],
      specs: [{ label: "Charge supplémentaire", value: "300 kg" }],
    }
  ),

  /* --------------------------- PROTECTION --------------------------- */
  P(
    "p-bullbar-hilux",
    "IBULL-HILUX",
    "Pare-buffle acier Hilux",
    "مصعد أمامي فولاذي هيلوكس",
    "protection",
    IMG.fordCustom,
    "Bull bar acier haute résistance, points treuil intégrés, LED ready.",
    ["Toyota Hilux (2015–2026)"],
    {
      features: ["Acier 3 mm", "Points treuil", "Emplacement LED 30-52\""],
      specs: [{ label: "Matériau", value: "Acier 3 mm" }, { label: "Poids", value: "38 kg" }],
    }
  ),
  P(
    "p-side-steps",
    "ISIDE-ALU",
    "Side steps aluminium",
    "درجات جانبية ألمنيوم",
    "protection",
    IMG.redBullHilux,
    "Barres latérales alu 76 mm — accès facilité et protection des portes.",
    ["Pickup — vérifier longueur par modèle"],
    {
      features: ["Aluminium 76 mm", "Passes-pieds caoutchouc", "Inoxydable"],
      specs: [{ label: "Diamètre", value: "76 mm" }],
    }
  ),

  /* --------------------------- ROOF / TENTS -------------------------- */
  P(
    "p-rooftop-tent",
    "ITENT-DBL",
    "Tente de toit double",
    "خيمة سقف مزدوجة",
    "roof-racks",
    IMG.rooftopTent,
    "Tente de toit auto-portante pour 2 — montée en 90 secondes.",
    ["Galerie de toit 4 barres"],
    {
      badge: "Best Seller",
      features: ["Montage 90 s", "Toile ignifugée", "Matelas intégré"],
      specs: [{ label: "Capacité", value: "2 personnes" }, { label: "Poids", value: "89 kg" }],
    }
  ),
  P(
    "p-roofrack-alu",
    "IGAL-4B",
    "Galerie aluminium 4 barres",
    "حامل سقف ألمنيوم 4 قوائم",
    "roof-racks",
    IMG.camperFog,
    "Galerie alu aéro 4 barres + 8 points de fixation — base overlanding.",
    ["Pickup — vérif dimensions de caisse"],
    {
      features: ["Aluminium aéro", "8 points T-slot", "Charge 100 kg"],
      specs: [{ label: "Charge", value: "100 kg" }],
    }
  ),

  /* ---------------------------- SNORKELS ---------------------------- */
  P(
    "p-snorkel-hilux",
    "ISNR-HILUX",
    "Snorkel Toyota Hilux",
    "سنوركيل تويوتا هيلوكس",
    "snorkels",
    IMG.red4x4Mud,
    "Admission haute côté A — traversées en toute sérénité.",
    ["Toyota Hilux (2015–2026)"],
    {
      features: ["Polypropylène UV-stable", "Filtre d'eau intégré", "Montage 2 h"],
      specs: [{ label: "Matériau", value: "Polypropylène" }],
    }
  ),
  P(
    "p-snorkel-navara",
    "ISNR-NAVARA",
    "Snorkel Nissan Navara",
    "سنوركيل نيسان نافارا",
    "snorkels",
    IMG.mudRacing,
    "Snorkel complet pour Navara — design tubulaire premium.",
    ["Nissan Navara (2015–2026)"],
    {
      features: ["Tubulaire premium", "Filtre d'eau", "Fixation carrosserie"],
      specs: [{ label: "Matériau", value: "PP + ABS" }],
    }
  ),

  /* --------------------- LIGHTING & ÉLECTRIQUE ---------------------- */
  P(
    "p-led-bar",
    "ILED-52",
    "Barre LED 52 pouces",
    "شريط إضاءة LED 52 بوصة",
    "lighting",
    IMG.ledNight,
    "Barre LED 52\" spot/flood — 5 000 lumens, étanche IP68.",
    ["Universel — support bull bar / galerie"],
    {
      features: ["5 000 lumens", "IP68", "Mode spot/flood commutable"],
      specs: [
        { label: "Puissance", value: "150 W" },
        { label: "Lumens", value: "5 000 lm" },
      ],
    }
  ),
  P(
    "p-agm-100",
    "IAGM-100",
    "Batterie AGM 100Ah",
    "بطارية AGM 100 أمبير",
    "lighting",
    IMG.dustyToyota,
    "Seconde batterie AGM 100Ah pour système double — énergie sans limite.",
    ["Système électrique double 12V"],
    {
      features: ["Entretien zéro", "Décharge profonde", "Vibrations OK"],
      specs: [{ label: "Capacité", value: "100 Ah" }, { label: "Type", value: "AGM 12V" }],
    }
  ),

  /* -------------------------- WHEELS & TIRES ------------------------ */
  P(
    "p-at-315",
    "IAT-315-17",
    "Jantes 17\" + Pneus A/T 315/70R17",
    "جنوط 17 + إطارات AT 315/70R17",
    "wheels-tires",
    IMG.tireSand,
    "Quatre jantes alu 17\" + pneus All-Terrain 315/70R17 — le combo piste.",
    ["Toyota / Nissan / Mitsubishi — vérif PCX"],
    {
      badge: "Best Seller",
      features: ["Set de 4 jantes", "Pneus A/T 128R", "Équilibrage inclus"],
      specs: [{ label: "Taille", value: "315/70 R17" }, { label: "Index", value: "128R" }],
    }
  ),
  P(
    "p-mt-37",
    "IMT-37",
    "Pneus M/T 37\" (set de 4)",
    "إطارات MT 37 بوصة (طقم 4)",
    "wheels-tires",
    IMG.tireMud,
    "Quatre pneus Mud-Terrain 37\" — adhérence extrême sur toutes surfaces.",
    ["Amortisseurs renforcés requis"],
    {
      features: ["Grip extrême", "Flanc renforcé", "Jusqu'à 160 km/h"],
      specs: [{ label: "Diamètre", value: "37\"" }],
    }
  ),
];

/* ================================================================== */
/*  2026 catalog import — Blindage, Snorkels, Pare-chocs, Marche-pied  */
/*  Column mapping: price = promo price · oldPrice = ancien prix       */
/*  · stock = quantity · fitment = vehicle column · no warranty.       */
/* ================================================================== */

type CatalogKind = "blindage" | "snorkel" | "bumperFront" | "bumperRear" | "step";

interface CatalogRow {
  sku: string;
  vehicle: string;
  price: number;
  oldPrice: number;
  stock: number;
  cat: string;
  kind: CatalogKind;
}

const CATALOG_ROWS: CatalogRow[] = [
  /* ---- Blindage / Protection (sous-caisse & garde-cardan) ---- */
  { sku: "UBP019", vehicle: "LC 76/78/79", price: 43000, oldPrice: 65980, stock: 2, cat: "protection", kind: "blindage" },
  { sku: "UBP048", vehicle: "NISSAN NAVARA D23 2015+ / ALASKAN", price: 99000, oldPrice: 169600, stock: 2, cat: "protection", kind: "blindage" },
  { sku: "UBP054", vehicle: "FORD RANGER 2011/2018 - MAZDA BT 50 2011/2020", price: 89000, oldPrice: 147800, stock: 2, cat: "protection", kind: "blindage" },
  { sku: "UBP070", vehicle: "SUZUKI JIMNY 2018+ 2 PORTE", price: 99000, oldPrice: 158080, stock: 2, cat: "protection", kind: "blindage" },
  { sku: "IUP006K", vehicle: "NISSAN NAVARA D22", price: 49000, oldPrice: 88500, stock: 2, cat: "protection", kind: "blindage" },
  { sku: "IUP007K", vehicle: "NISSAN NAVARA D40 / PATHFINDER - FORD RANGER 2011/2018 - MAZDA BT 2011/2020", price: 89000, oldPrice: 148400, stock: 2, cat: "protection", kind: "blindage" },
  { sku: "IUP014K", vehicle: "MAZDA / MITS L200", price: 99000, oldPrice: 167500, stock: 1, cat: "protection", kind: "blindage" },

  /* ---- Snorkels ---- */
  { sku: "ISNORKEL001", vehicle: "TOYOTA HILUX VIGO", price: 45000, oldPrice: 62445, stock: 1, cat: "snorkels", kind: "snorkel" },
  { sku: "ISNORKEL006", vehicle: "TOYOTA PRADO 120", price: 45000, oldPrice: 73450, stock: 1, cat: "snorkels", kind: "snorkel" },
  { sku: "ISNORKEL009", vehicle: "LC 75/78/79 1984/2007", price: 45000, oldPrice: 62445, stock: 1, cat: "snorkels", kind: "snorkel" },
  { sku: "ISNORKEL010", vehicle: "TOYOTA LC 200 2007/2015", price: 45000, oldPrice: 62445, stock: 1, cat: "snorkels", kind: "snorkel" },
  { sku: "ISNORKEL011", vehicle: "NISSAN PATROL Y60", price: 45000, oldPrice: 62445, stock: 2, cat: "snorkels", kind: "snorkel" },
  { sku: "ISNORKEL023", vehicle: "TOYOTA LC 76/78/79 2007+", price: 45000, oldPrice: 62445, stock: 4, cat: "snorkels", kind: "snorkel" },
  { sku: "ISNORKEL050", vehicle: "MITS L200 2015/2018 / FIAT FULLBACK", price: 45000, oldPrice: 74000, stock: 3, cat: "snorkels", kind: "snorkel" },
  { sku: "ISNORKEL056", vehicle: "TOYOTA LC 200 2015+", price: 45000, oldPrice: 74000, stock: 3, cat: "snorkels", kind: "snorkel" },
  { sku: "ISNORKEL064", vehicle: "TOYOTA PRADO 150", price: 45000, oldPrice: 73115, stock: 2, cat: "snorkels", kind: "snorkel" },

  /* ---- Pare choc avant ---- */
  { sku: "BBCD030", vehicle: "FORTUNER 2004/2015", price: 199000, oldPrice: 379380.6, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBCD037", vehicle: "FJ CRUISER", price: 199000, oldPrice: 379956.69, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBCD048 + IRP005", vehicle: "NAVARA D23 2015+", price: 199000, oldPrice: 377969.12, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBCD050 + IRP050", vehicle: "MITS L200 2015/2019 / FIAT FULL BACK", price: 225000, oldPrice: 398084.48, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBCD053", vehicle: "FORTUNER 2015+", price: 199000, oldPrice: 379380.6, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBCD055 + IRP054", vehicle: "FORD RANGER T7 2018+", price: 225000, oldPrice: 407820.18, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBC048 + IRP005", vehicle: "NAVARA D23 2015+", price: 189000, oldPrice: 337489.25, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBC050 + IRP050", vehicle: "MITS L200 2015/2019 / FIAT FULL BACK", price: 205000, oldPrice: 349895, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBT048 + IRP005", vehicle: "NAVARA D23 2015+", price: 199000, oldPrice: 429670.05, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBT054-NL + IRP054", vehicle: "FORD RANGER T7 2015/2020", price: 224900, oldPrice: 389007.85, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBR077", vehicle: "JEEP WRANGLER JL + GLADIATOR", price: 300000, oldPrice: 351743.73, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBR077ST", vehicle: "JEEP WRANGLER JL + GLADIATOR", price: 300000, oldPrice: 351743.73, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },
  { sku: "BBCD070", vehicle: "SUZUKI JIMNY 2018+", price: 327000, oldPrice: 327093.15, stock: 1, cat: "pare-choc-avant", kind: "bumperFront" },

  /* ---- Pare choc arrière ---- */
  { sku: "RTB038 + RTBPLATE001", vehicle: "FORD RANGER", price: 192000, oldPrice: 380085.29, stock: 1, cat: "pare-choc-arriere", kind: "bumperRear" },
  { sku: "RTB048 + RTBPLATE001", vehicle: "NISSAN NAVARA D23", price: 192000, oldPrice: 375868.57, stock: 1, cat: "pare-choc-arriere", kind: "bumperRear" },
  { sku: "RTB050 + RTBPLATE001", vehicle: "MITS L200 2015+", price: 192000, oldPrice: 375868.57, stock: 1, cat: "pare-choc-arriere", kind: "bumperRear" },

  /* ---- Marche pied ---- */
  { sku: "SS033", vehicle: "HILUX VIGO 2005/2015", price: 85000, oldPrice: 149966.37, stock: 1, cat: "marche-pied", kind: "step" },
  { sku: "SS047", vehicle: "TOYOTA PRADO 150", price: 89000, oldPrice: 130837.26, stock: 1, cat: "marche-pied", kind: "step" },
  { sku: "SS048", vehicle: "NISSAN NAVARA D23", price: 85000, oldPrice: 142573.66, stock: 1, cat: "marche-pied", kind: "step" },
  { sku: "SS050", vehicle: "MITS L200 2015/2025", price: 85000, oldPrice: 130837.26, stock: 1, cat: "marche-pied", kind: "step" },
  { sku: "SS053", vehicle: "FORTUNER 2015+", price: 89000, oldPrice: 129259.48, stock: 1, cat: "marche-pied", kind: "step" },
  { sku: "SS054", vehicle: "FORD RANGER", price: 85000, oldPrice: 130837.26, stock: 1, cat: "marche-pied", kind: "step" },
];

interface CatalogCopy {
  label: string;
  labelAr: string;
  short: string;
  features: string[];
  specs: { label: string; value: string }[];
  problem: string;
  solution: string;
}

const CATALOG_COPY: Record<CatalogKind, CatalogCopy> = {
  blindage: {
    label: "Protection sous-caisse",
    labelAr: "حماية الهيكل السفلي",
    short: "Plaque de protection sous-caisse / garde-cardan en acier, conçue et fabriquée en Australie par Ironman 4x4.",
    features: [
      "Acier haute résistance, découpe laser",
      "Conception spécifique au véhicule",
      "Visserie et platines de fixation incluses",
      "Montage direct, sans perçage",
    ],
    specs: [
      { label: "Matière", value: "Acier zincé" },
      { label: "Origine", value: "Ironman 4x4 — Australie" },
      { label: "Pose", value: "Atelier Baraki (Alger)" },
    ],
    problem:
      "Pierres, racines et traversées de wadi abîment le carter, la boîte et les organes sensibles du 4x4 — réparation coûteuse en pleine piste.",
    solution:
      "Une plaque Ironman 4x4 usinée pour votre châssis exact, posée par nos techniciens : le carter, la boîte et les triebars sont protégés.",
  },
  snorkel: {
    label: "Snorkel",
    labelAr: "أنبوب غطس",
    short: "Snorkel à admission surélevée Ironman 4x4 — conçu pour le véhicule cité, matériau stabilisé UV, tête Ram-Air.",
    features: [
      "Conception spécifique au véhicule",
      "Matériau polyéthylène stabilisé UV",
      "Tête d'admission Ram-Air",
      "Réduit l'entrée d'eau, de poussière et de sable",
    ],
    specs: [
      { label: "Matière", value: "Polyéthylène stabilisé UV" },
      { label: "Origine", value: "Ironman 4x4 — Australie" },
      { label: "Pose", value: "Atelier Baraki (Alger)" },
    ],
    problem:
      "En traversée (oued, pluie, sable), la prise d'air d'origine aspire eau et poussière : risque de calage et moteur grasant.",
    solution:
      "Une admission surélevée Ironman 4x4, spécifique à votre modèle : air propre, traversées maîtrisées et allumage sans crainte.",
  },
  bumperFront: {
    label: "Pare-choc avant",
    labelAr: "مصاص أمامي",
    short: "Pare-choc avant en acier haute résistance Ironman 4x4, conçu pour la compatibilité indiquée.",
    features: [
      "Acier plié haute résistance",
      "Points de repose et œillets de treuil",
      "Compatibilité capteurs et radars",
      "Finition thermolaquée anti-corrosion",
    ],
    specs: [
      { label: "Matière", value: "Acier plié 3-4 mm" },
      { label: "Origine", value: "Ironman 4x4 — Australie" },
      { label: "Pose", value: "Atelier Baraki (Alger)" },
    ],
    problem:
      "Le pare-choc d'origine en plastique ne protège rien : collision lente, branche ou rocher = éclat de calandre et voyant moteur.",
    solution:
      "Un pare-choc acier Ironman 4x4 avec repose et points de traction, monté et réglé par nos techniciens certifiés.",
  },
  bumperRear: {
    label: "Pare-choc arrière",
    labelAr: "مصاص خلفي",
    short: "Pare-choc arrière en acier avec protection de plaque Ironman 4x4, conçu pour la compatibilité indiquée.",
    features: [
      "Acier plié haute résistance",
      "Protection de plaque d'immatriculation",
      "Support de remorquage intégré",
      "Finition thermolaquée anti-corrosion",
    ],
    specs: [
      { label: "Matière", value: "Acier plié 3-4 mm" },
      { label: "Origine", value: "Ironman 4x4 — Australie" },
      { label: "Pose", value: "Atelier Baraki (Alger)" },
    ],
    problem:
      "Le pare-choc arrière d'origine se déforme au moindre choc et offre aucun point de traction fiable en récupération.",
    solution:
      "Un pare-choc acier Ironman 4x4 avec plaque protégée et repose de traction — prêt pour le dépannage et le chargement.",
  },
  step: {
    label: "Marche-pied",
    labelAr: "درج جانبي",
    short: "Marche-pied / running board Ironman 4x4 — accès facilité et protection des portes.",
    features: [
      "Structure acier ou aluminium",
      "Plaque d'appui antidérapante",
      "Fixations sur points d'origine",
      "Protège la carrosserie lors des passages en piste",
    ],
    specs: [
      { label: "Matière", value: "Acier thermolaqué / Aluminium" },
      { label: "Origine", value: "Ironman 4x4 — Australie" },
      { label: "Pose", value: "Atelier Baraki (Alger)" },
    ],
    problem:
      "Monter ou descendre d'un 4x4 surélevé fatigue les genoux, et les portes s'ourent sur les rochers en pleine piste.",
    solution:
      "Un marche-pied Ironman 4x4 : appui stable pour toute la famille et ligne de protection le long de la carrosserie.",
  },
};

const KIND_IMAGES: Record<CatalogKind, string[]> = {
  blindage: [IMG.undercarriage, IMG.suspension],
  snorkel: [IMG.red4x4Mud, IMG.mudRacing],
  bumperFront: [IMG.fordCustom, IMG.redBullHilux, IMG.dustyToyota],
  bumperRear: [IMG.coastTruck, IMG.f150Desert],
  step: [IMG.gmc, IMG.redBullHilux],
};

const CATALOG_PRODUCTS: Product[] = CATALOG_ROWS.map((r, index) => {
  const copy = CATALOG_COPY[r.kind];
  const images = KIND_IMAGES[r.kind];
  return {
    id: `p-${r.sku.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "")}`,
    sku: r.sku,
    name: `${copy.label} Ironman 4x4 — ${r.vehicle}`,
    nameAr: `${copy.labelAr} — ${r.vehicle}`,
    categorySlug: r.cat,
    price: r.price,
    oldPrice: r.oldPrice,
    stock: r.stock,
    badge: "PROMO",
    image: images[index % images.length],
    images: [],
    shortDescription: `${copy.short} Compatibilité : ${r.vehicle}. Réf. ${r.sku}.`,
    problem: copy.problem,
    solution: copy.solution,
    features: copy.features,
    specs: copy.specs,
    fitment: [r.vehicle],
    warranty: "",
    active: true,
    featured: true,
    showLowStockBadge: false,
    showDiscountBadge: true,
  };
});

/** One-time price update requested for the CANOPY, CAMPING, RECOVERY and WINCH catalog. */
const PRODUCT_PRICE_VERSION = 1;
const PRODUCT_PRICE_UPDATES: Record<string, number> = {
  "CANOPY003-P": 627324.13,
  "CANOPY010-P": 627324.13,
  "CANOPY013-PW": 743495.26,
  IWT001: 20616.78,
  IWT002: 40660.87,
  IWT003: 62236.04,
  IWT004: 83127.68,
  IWT005: 67893.86,
  IWT006: 57827.95,
  IWTHOSE: 9248.35,
  IRECBDGREEN: 68832.72,
  IRECBDGREY: 68832.72,
  IRECBDSAND: 68832.72,
  IRECBDPINS115: 9465.8,
  IRECBRDBASE: 14198.83,
  IMW12000_MSR: 281057.81,
  IMW12000MWR: 236068.54,
  IMW9500_MSR: 268917.22,
  WWB9500: 196976.48,
  WWB001: 33560.86,
  WWB015: 10326.42,
  WWB031: 10979.98,
  WINCHBLANKET: 8259.93,
  WWWFAIRELEAD: 19362.03,
  WWWHAWSE: 20083.05,
  WWWROPE001: 105000,
};

export const DEFAULT_PRODUCTS: Product[] = [
  ...BASE_PRODUCTS,
  ...CATALOG_PRODUCTS,
  ...AMORTISSEUR_PRODUCTS,
]
  .map((product) => ({
    ...product,
    price: PRODUCT_PRICE_UPDATES[product.sku] ?? product.price,
  }))
  .map(curateProductImage)
  .map(roundProductPrices);

/* ================================================================== */
/*  Hero slider                                                        */
/* ================================================================== */

export const DEFAULT_HERO: HeroSlide[] = [
  {
    id: "slide-1",
    mediaType: "image",
    image: IMG.heroMud,
    videoUrl: "",
    videoPoster: "",
    autoplay: true,
    muted: true,
    badge: {
      fr: "Représentant Officiel Ironman 4x4 — Algérie",
      ar: "الممثل الرسمي لآيرون مان 4x4 — الجزائر",
    },
    title: { fr: "DAHRA MOTORS 4x4", ar: "الضهرة موتورز 4x4" },
    subtitle: {
      fr: "Le Représentant Officiel d'Ironman 4x4 en Algérie. Suspension, protection et équipement overlanding 100% d'origine — avec garantie officielle et installation experte.",
      ar: "الممثل الرسمي لآيرون مان 4x4 في الجزائر. أنظمة تعليق وحماية ومعدات أوفرلاند أصلية 100% — مع ضمان رسمي وتركيب احترافي.",
    },
    ctaLabel: { fr: "Découvrir la Boutique", ar: "اكتشف المتجر" },
    ctaLink: "/shop",
    active: true,
  },
  {
    id: "slide-2",
    mediaType: "image",
    image: IMG.heroTimimoun,
    videoUrl: "",
    videoPoster: "",
    autoplay: true,
    muted: true,
    badge: {
      fr: "Forgé pour les Pistes Algériennes",
      ar: "مصنوع للمسالك الجزائرية",
    },
    title: { fr: "DOMINEZ CHAQUE PISTE", ar: "سيطر على كل مسار" },
    subtitle: {
      fr: "Amortisseurs Foam Cell Pro, pare-buffles acier et treuils Ironman 4x4 — testés dans les conditions les plus extrêmes au monde, prêts pour le Hoggar et la Kabylie.",
      ar: "ممتصات فوم سيل برو، مصاعد فولاذية وونشات آيرون مان 4x4 — مُختبرة في أقسى الظروف عالمياً، جاهزة للهقار والقبائل.",
    },
    ctaLabel: { fr: "Voir les Suspensions", ar: "شاهد أنظمة التعليق" },
    ctaLink: "/shop?category=suspension",
    active: true,
  },
  {
    id: "slide-3",
    mediaType: "image",
    image: IMG.heroDunes,
    videoUrl: "",
    videoPoster: "",
    autoplay: true,
    muted: true,
    badge: {
      fr: `Livraison ${WILAYAS_LABEL} — Paiement à la Livraison`,
      ar: `توصيل 69 ولاية — الدفع عند الاستلام`,
    },
    title: { fr: "L'AVENTURE COMMENCE ICI", ar: "المغامرة تبدأ هنا" },
    subtitle: {
      fr: "Commandez en ligne ou via WhatsApp, payez à la livraison partout en Algérie. Notre équipe vous accompagne du devis à l'installation.",
      ar: "اطلب عبر الموقع أو واتساب، وادفع عند الاستلام في جميع أنحاء الجزائر. فريقنا معك من العرض حتى التركيب.",
    },
    ctaLabel: { fr: "Commander sur WhatsApp", ar: "اطلب عبر واتساب" },
    ctaLink: "/contact",
    active: true,
  },
];

/* ================================================================== */
/*  Video section (16:9 banner under the vehicle selector)            */
/* ================================================================== */

export const DEFAULT_VIDEO_SECTION: VideoSection = {
  enabled: true,
  videoUrl: IRONMAN_VIDEO_EMBED_URL,
  poster: IRONMAN_VIDEO_POSTER,
  badge: { fr: "Ironman 4x4 — Suspension", ar: "آيرون مان 4x4 — نظام التعليق" },
  title: {
    fr: "INTRODUCING IM2.5 MONOTUBE SUSPENSION — IRONMAN 4X4",
    ar: "نقدم نظام التعليق IM2.5 MONOTUBE — آيرون مان 4x4",
  },
  subtitle: {
    fr: "Découvrez la nouvelle génération de suspension monotube IM2.5 conçue par Ironman 4x4 pour la performance, le contrôle et les terrains exigeants.",
    ar: "اكتشف الجيل الجديد من نظام التعليق أحادي الأنبوب IM2.5 المصمم للأداء والتحكم وأصعب التضاريس.",
  },
  ctaLabel: { fr: "VOIR SUR YOUTUBE", ar: "شاهد على يوتيوب" },
  ctaLink: IRONMAN_VIDEO_WATCH_URL,
};

/* ================================================================== */
/*  Site content                                                       */
/* ================================================================== */

export const DEFAULT_CONTENT: SiteContent = {
  aboutTitle: { fr: "Dahra Motors 4x4", ar: "الضهرة موتورز 4x4" },
  aboutText: {
    fr: "Représentant officiel d'Ironman 4x4 en Algérie — showroom et atelier à Baraki (Alger). Pièces 100% d'origine, installation certifiée et livraison dans 69 wilayas.",
    ar: "الممثل الرسمي لآيرون مان 4x4 في الجزائر — معرض وورشة في براقي (الجزائر). قطع أصلية 100%، تركيب معتمد وتوصيل إلى 69 ولاية.",
  },
  aboutText2: {
    fr: "Depuis Alger, nous équipons les passionnés du Hoggar à la Kabylie. Chaque installation est réalisée par des techniciens formés aux standards Ironman 4x4 Australie.",
    ar: "من الجزائر، نجهّز عشاق الطرق الوعرة من الهقار إلى القبائل. كل تركيب يتم بواسطة فنيين مدرّبين وفق معايير آيرون مان 4x4 أستراليا.",
  },
  aboutImage: IMG.f150Desert,
  stats: [
    { value: "500+", label: { fr: "Véhicules équipés", ar: "سيارة مجهزة" } },
    { value: "69", label: { fr: "Wilayas livrées", ar: "ولاية نوصل إليها" } },
    { value: "100%", label: { fr: "Pièces d'origine", ar: "قطع أصلية" } },
    { value: "7 ans", label: { fr: "D'expérience 4x4", ar: "خبرة في 4x4" } },
  ],
  trustBadges: [
    {
      icon: "shipping",
      title: { fr: `Livraison ${WILAYAS_LABEL}`, ar: "توصيل 69 ولاية" },
      text: {
        fr: "Expédition partout en Algérie, paiement à la livraison.",
        ar: "توصيل إلى جميع أنحاء الجزائر، الدفع عند الاستلام.",
      },
      enabled: true,
    },
    {
      icon: "install",
      title: { fr: "Installation Expert", ar: "تركيب احترافي" },
      text: {
        fr: "Atelier certifié à Baraki (Alger) — montage par nos techniciens.",
        ar: "ورشة معتمدة في براقي (الجزائر) — تركيب بواسطة فنيينا.",
      },
      enabled: true,
    },
    {
      icon: "genuine",
      title: { fr: "100% Origine", ar: "أصلي 100%" },
      text: {
        fr: "Pièces d'origine Ironman 4x4 avec garantie officielle.",
        ar: "قطع أصلية من آيرون مان 4x4 مع ضمان رسمي.",
      },
      enabled: true,
    },
    {
      icon: "chat",
      title: { fr: "Support WhatsApp 7j/7", ar: "دعم واتساب 7/7" },
      text: {
        fr: "Conseil, commande et suivi — réponse rapide sur WhatsApp.",
        ar: "استشارة وطلب ومتابعة — رد سريع على واتساب.",
      },
      enabled: true,
    },
  ],
  categoriesTitle: { fr: "Nos Catégories", ar: "فئاتنا" },
  categoriesSubtitle: {
    fr: "Tout l'équipement 4x4 que votre véhicule mérite, par usage.",
    ar: "كل معدّات 4x4 التي تستحقها سيارتك، حسب الاستخدام.",
  },
  featuredTitle: { fr: "Produits en Vedette", ar: "منتجات مميزة" },
  featuredSubtitle: {
    fr: "Les références les plus demandées de la boutique, prêtes à livrer.",
    ar: "أكثر المراجع طلباً في المتجر، جاهزة للتوصيل.",
  },
  selectorTitle: { fr: "Fit My 4x4", ar: "جهّز سيارتك 4x4" },
  selectorSubtitle: {
    fr: "Marque, modèle, année — trouvez les pièces compatibles avec votre 4x4.",
    ar: "الماركة، الموديل، السنة — اعثر على القطع المتوافقة مع سيارتك.",
  },
  bannerTitle: { fr: "Un projet de build en tête ?", ar: "عندك مشروع تجهيز؟" },
  bannerText: {
    fr: "Parlez-nous de votre véhicule et de vos objectifs — nos conseillers vous proposent le kit complet, prix et installation inclus.",
    ar: "حدثنا عن سيارتك وأهدافك — مستشارونا يقترحون عليك الطقم الكامل، مع السعر والتركيب.",
  },
  bannerCta: { fr: "Parler à un Expert", ar: "تحدث مع خبير" },
};

/* ================================================================== */
/*  Gallery (before / after builds)                                    */
/* ================================================================== */

export const DEFAULT_GALLERY: GalleryItem[] = [
  {
    id: "gal-1",
    title: { fr: "Hilux — Pack Overlanding Complet", ar: "هيلوكس — طقم أوفرلاند كامل" },
    customerName: "Karim B.",
    vehicle: "Toyota Hilux 2019",
    wilaya: "Alger",
    testimonial: {
      fr: "Installation nickel, véhicule transformé. La suspension absorbe tout même avec la tente et les réservoirs.",
      ar: "تركيب ممتاز، السيارة تغيّرت تماماً. التعليق يمتص كل شيء حتى مع الخيمة والخزانات.",
    },
    rating: 5,
    beforeImage: IMG.forestTruck,
    afterImage: IMG.redBullHilux,
    videoSrc: "",
    active: true,
  },
  {
    id: "gal-2",
    title: { fr: "Ranger — Canopy + Camping", ar: "رانجر — قاطع حوض + تخييم" },
    customerName: "Amine T.",
    vehicle: "Ford Ranger 2017",
    wilaya: "Oran",
    testimonial: {
      fr: "Livraison rapide à Oran, canopy parfaitement ajusté. Le kit eau 50L fait toute la différence en bivouac.",
      ar: "توصيل سريع إلى وهران، القاطع مضبوط تماماً. طقم الماء 50 لتر يفرق كثيراً في التخييم.",
    },
    rating: 5,
    beforeImage: IMG.coastTruck,
    afterImage: IMG.rooftopTent,
    videoSrc: "",
    active: true,
  },
  {
    id: "gal-3",
    title: { fr: "Navara — Protection + LED", ar: "نافارا — حماية + إضاءة" },
    customerName: "Yacine M.",
    vehicle: "Nissan Navara D40",
    wilaya: "Béjaïa",
    testimonial: {
      fr: "Bull bar + barre LED 52\" : la navara est une bête maintenant. Merci Dahra Motors pour le suivi WhatsApp.",
      ar: "مصعد + شريط LED 52: النافارا صارت وحش الآن. شكراً الضهرة موتورز على المتابعة عبر واتساب.",
    },
    rating: 4,
    beforeImage: IMG.gmc,
    afterImage: IMG.dustyToyota,
    videoSrc: "",
    active: true,
  },
];

/* ================================================================== */
/*  Settings / credentials / default state                             */
/* ================================================================== */

export const DEFAULT_SETTINGS: Settings = {
  storeName: "Dahra Motors 4x4",
  tagline: {
    fr: "Le Représentant Officiel d'Ironman 4x4 en Algérie",
    ar: "الممثل الرسمي لآيرون مان 4x4 في الجزائر",
  },
  phone: DEFAULT_PHONE,
  phones: ["0550 03 08 96", "0560 03 08 95", "0560 03 08 97", "028 30 63 26"],
  contactLines: CONTACT_LINES,
  whatsapp: DEFAULT_WHATSAPP,
  email: "dahramotors4x4@gmail.com",
  address: {
    fr: "Zone d'activité 2004, Baraki, Alger",
    ar: "منطقة النشاط 2004، براقي، الجزائر",
  },
  mapLink: "https://maps.app.goo.gl/qVRWKaqDF8zrk3xw5",
  hours: {
    fr: "08:30 – 17:00 (Du Samedi au Jeudi, Fermé le Vendredi)",
    ar: "08:30 – 17:00 (من السبت إلى الخميس، مغلق يوم الجمعة)",
  },
  headerLogo: "",
  footerLogo: "",
  social: {
    facebook: "",
    instagram: "",
    tiktok: "",
    youtube: "https://www.youtube.com/results?search_query=dahra+motors+4x4+algerie",
  },
};

/** Master owner credentials requested for /admin. Username and password are case-sensitive. */
export const ADMIN_USERNAME = "dahramotors";
export const ADMIN_PASSWORD = "Motors24";

export const DEFAULT_CREDENTIALS: Credentials = {
  username: ADMIN_USERNAME,
  password: ADMIN_PASSWORD,
};

export const DEFAULT_STATE: CmsState = {
  settings: DEFAULT_SETTINGS,
  credentials: DEFAULT_CREDENTIALS,
  hero: DEFAULT_HERO,
  videoSection: DEFAULT_VIDEO_SECTION,
  categories: DEFAULT_CATEGORIES,
  products: DEFAULT_PRODUCTS,
  productPriceVersion: PRODUCT_PRICE_VERSION,
  productImageVersion: PRODUCT_IMAGE_VERSION,
  suspensionCatalogVersion: SUSPENSION_CATALOG_VERSION,
  priceRoundingVersion: PRICE_ROUNDING_VERSION,
  content: DEFAULT_CONTENT,
  gallery: DEFAULT_GALLERY,
  orders: [],
};

/* ================================================================== */
/*  localStorage persistence (CMS)                                     */
/* ================================================================== */

/** Factory identifiers retained for manual maintenance, never automatic deletion. */
export const DEMO_PRODUCT_IDS = [
  "p-fcp-kit-hilux",
  "p-fcp-shock",
  "p-bullbar-hilux",
  "p-roofrack-alu",
  "p-snorkel-hilux",
  "p-winch-12000",
  "p-rooftop-tent",
  "p-led-bar",
  "p-fridge-45",
  "p-side-steps",
  "p-awning-2500",
  "p-compressor",
  "p-kit-medium",
  "p-kit-heavy",
];

/** THE single global persistence key for the whole CMS. */
export const STORAGE_KEY = "dahra_cms_v2";
export const CMS_UPDATED_EVENT = "dahra_cms_updated";
export const CMS_SYNC_CHANNEL = "dahra_cms_sync_v2";
/** Seed metadata only. Version changes must never reset an existing document. */
export const SEED_VERSION = 6;

/** Catalog metadata only; existing saved arrays always take precedence. */
export const DEFAULT_PRODUCT_IDS = DEFAULT_PRODUCTS.map((p) => p.id);
export const DEFAULT_CATEGORY_IDS = DEFAULT_CATEGORIES.map((c) => c.id);

/** Historical demo IDs, available to explicit maintenance tools only. */
export const PURGE_PRODUCT_IDS = DEMO_PRODUCT_IDS.filter(
  (id) => !DEFAULT_PRODUCT_IDS.includes(id)
);

function clone<T>(v: T): T {
  if (typeof structuredClone === "function") return structuredClone(v);
  return JSON.parse(JSON.stringify(v)) as T;
}

// The most recent previous build used v1. Adopt it only if v2 is absent.
const LEGACY_STORAGE_KEYS = ["dahra_cms_v1", "dahra_cms_v3"];

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

/** An unreadable saved document stays on disk; never display a reseeded catalog. */
export function emptyCmsState(): CmsState {
  return {
    ...clone(DEFAULT_STATE),
    products: [],
    categories: [],
    hero: [],
    gallery: [],
    orders: [],
    videoSection: { ...clone(DEFAULT_VIDEO_SECTION), enabled: false },
    content: { ...clone(DEFAULT_CONTENT), stats: [], trustBadges: [] },
  };
}

/** Previous factory contact values — replaced on load, they are not user data. */
const LEGACY_FACTORY_PHONE = "+213 556 40 08 30";
const LEGACY_FACTORY_WHATSAPP = "213556400830";
const LEGACY_FACTORY_CREDENTIALS = new Set([
  "dahramotors4x4\u0000dahra4x4",
  "dahramotors4x4\u0000dahrabaraki",
  "dahramotor\u0000dahra4x4",
  "dahramotors\u0000dahra4x4",
  "dahramotors4x4\u0000dahramotors",
  "dahra4x4\u0000dahramotors",
]);
const LEGACY_FACTORY_EMAILS = new Set([
  "contact@dahramotors4x4.dz",
]);
const LEGACY_FACTORY_ADDRESSES = {
  fr: new Set(["Baraki, Alger 16110, Algérie"]),
  ar: new Set(["براقي، الجزائر 16110، الجزائر"]),
};
const LEGACY_FACTORY_HOURS = {
  fr: new Set(["Lun – Sam : 09:00 – 18:00"]),
  ar: new Set(["الإثنين – السبت: 09:00 – 18:00"]),
};
const LEGACY_FACTORY_MAP_LINKS = new Set([
  "https://www.google.com/maps/search/?api=1&query=Baraki+Alger+16110+Algeria",
  "https://www.google.com/maps/search/?api=1&query=Zone+d%27activite+2004+Baraki+Alger",
]);

/**
 * A phone number the owner really typed always wins. Only values that still
 * equal the old factory default are replaced, and the structured dropdown list
 * is filled in when absent.
 */
function mergeContactSettings(saved?: Partial<Settings>): Settings {
  const phone =
    saved?.phone && saved.phone !== LEGACY_FACTORY_PHONE ? saved.phone : DEFAULT_PHONE;
  const whatsapp =
    saved?.whatsapp && saved.whatsapp !== LEGACY_FACTORY_WHATSAPP
      ? saved.whatsapp
      : DEFAULT_WHATSAPP;
  const storedPhones = saved?.phones ?? [];
  const hasUserPhones = storedPhones.some((p) => p && p !== LEGACY_FACTORY_PHONE);
  const email =
    saved?.email && !LEGACY_FACTORY_EMAILS.has(saved.email)
      ? saved.email
      : DEFAULT_SETTINGS.email;
  const address = {
    fr:
      saved?.address?.fr && !LEGACY_FACTORY_ADDRESSES.fr.has(saved.address.fr)
        ? saved.address.fr
        : DEFAULT_SETTINGS.address.fr,
    ar:
      saved?.address?.ar && !LEGACY_FACTORY_ADDRESSES.ar.has(saved.address.ar)
        ? saved.address.ar
        : DEFAULT_SETTINGS.address.ar,
  };
  const hours = {
    fr:
      saved?.hours?.fr && !LEGACY_FACTORY_HOURS.fr.has(saved.hours.fr)
        ? saved.hours.fr
        : DEFAULT_SETTINGS.hours.fr,
    ar:
      saved?.hours?.ar && !LEGACY_FACTORY_HOURS.ar.has(saved.hours.ar)
        ? saved.hours.ar
        : DEFAULT_SETTINGS.hours.ar,
  };
  const mapLink =
    saved?.mapLink && !LEGACY_FACTORY_MAP_LINKS.has(saved.mapLink)
      ? saved.mapLink
      : DEFAULT_SETTINGS.mapLink;

  return {
    ...clone(DEFAULT_SETTINGS),
    ...saved,
    tagline: { ...DEFAULT_SETTINGS.tagline, ...saved?.tagline },
    address,
    hours,
    social: { ...DEFAULT_SETTINGS.social, ...saved?.social },
    phone,
    whatsapp,
    email,
    mapLink,
    phones: hasUserPhones ? storedPhones : DEFAULT_SETTINGS.phones,
    contactLines: saved?.contactLines?.length ? saved.contactLines : CONTACT_LINES,
    headerLogo: saved?.headerLogo || DEFAULT_SETTINGS.headerLogo,
    footerLogo: saved?.footerLogo || DEFAULT_SETTINGS.footerLogo,
  };
}

/** Upgrade only known factory credentials; an intentional owner change remains valid. */
function mergeCredentials(saved?: Partial<Credentials>): Credentials {
  if (!saved?.username || !saved?.password) return clone(DEFAULT_CREDENTIALS);
  return LEGACY_FACTORY_CREDENTIALS.has(`${saved.username}\u0000${saved.password}`)
    ? clone(DEFAULT_CREDENTIALS)
    : { username: saved.username, password: saved.password };
}

/** Upgrade only the unchanged factory video; admin-customized media always wins. */
function mergeVideoSection(saved?: Partial<VideoSection>): VideoSection {
  if (!saved || !saved.videoUrl || saved.videoUrl === LEGACY_FACTORY_VIDEO_URL) {
    return clone(DEFAULT_VIDEO_SECTION);
  }
  return { ...clone(DEFAULT_VIDEO_SECTION), ...saved };
}

/** Read old envelopes without changing saved prices, credentials, or collections. */
export function parseCmsState(raw: string): CmsState {
  const decoded: unknown = JSON.parse(raw);
  if (!isRecord(decoded)) throw new Error("Les donnees CMS sauvegardees sont invalides.");
  const value = Object.prototype.hasOwnProperty.call(decoded, "state") ? decoded.state : decoded;
  if (!isRecord(value)) throw new Error("Le document CMS sauvegarde est invalide.");
  for (const key of ["products", "categories", "hero", "gallery", "orders"] as const) {
    if (value[key] !== undefined && !Array.isArray(value[key])) {
      throw new Error(`La collection CMS ${key} est invalide. Les donnees sont conservees.`);
    }
  }
  const saved = value as Partial<CmsState>;
  const normalized: CmsState = {
    ...saved,
    // A very old partial document with no products collection is not treated as
    // a catalog to migrate; an explicit [] is, because this batch was requested.
    suspensionCatalogVersion:
      saved.products === undefined
        ? SUSPENSION_CATALOG_VERSION
        : saved.suspensionCatalogVersion,
    settings: mergeContactSettings(saved.settings),
    credentials: mergeCredentials(saved.credentials),
    products: (saved.products ?? []).map((p) => {
      return {
        ...p,
        images: p.images ?? [],
        features: p.features ?? [],
        specs: p.specs ?? [],
        fitment: p.fitment ?? [],
      };
    }),
    productImageVersion: saved.productImageVersion,
    categories: saved.categories ?? [],
    hero: saved.hero ?? [],
    gallery: saved.gallery ?? [],
    orders: saved.orders ?? [],
    videoSection: mergeVideoSection(saved.videoSection),
    content: {
      ...clone(DEFAULT_CONTENT),
      ...saved.content,
      stats: saved.content?.stats ?? [],
      trustBadges: saved.content?.trustBadges ?? [],
    },
  };
  return normalizeCmsProductImages(normalizeCmsPrices(mergeSuspensionCatalog(normalized)));
}

/** Pure read for events and commits: never seeds, migrates, or writes back. */
export function readSavedState(storage: Pick<Storage, "getItem"> = localStorage): CmsState | null {
  const raw = storage.getItem(STORAGE_KEY);
  return raw === null || raw === "" ? null : parseCmsState(raw);
}

/** Defaults are written once, and only when there is no saved CMS document. */
export function loadState(storage: Storage = localStorage): CmsState {
  const currentRaw = storage.getItem(STORAGE_KEY);
  if (currentRaw !== null && currentRaw !== "") {
    const decoded: unknown = JSON.parse(currentRaw);
    const rawValue = isRecord(decoded) && Object.prototype.hasOwnProperty.call(decoded, "state")
      ? decoded.state
      : decoded;
    const rawRecord = isRecord(rawValue) ? rawValue : {};
    const rawProducts: unknown[] | null = Array.isArray(rawRecord.products)
      ? rawRecord.products
      : null;
    const hasRawProducts = rawProducts !== null;
    const rawNeedsRounding = rawProducts?.some((entry: unknown) => {
      if (!isRecord(entry)) return false;
      const price = Number(entry.price ?? 0);
      const priceMax = entry.priceMax == null ? null : Number(entry.priceMax);
      const oldPrice = entry.oldPrice == null ? null : Number(entry.oldPrice);
      return price !== roundDzdPrice(price) ||
        (priceMax !== null && priceMax !== roundDzdPrice(priceMax)) ||
        (oldPrice !== null && oldPrice !== roundDzdPrice(oldPrice));
    }) ?? false;
    const saved = parseCmsState(currentRaw);
    if (
      hasRawProducts &&
      (
        Number(rawRecord.suspensionCatalogVersion ?? 0) < SUSPENSION_CATALOG_VERSION ||
        Number(rawRecord.priceRoundingVersion ?? 0) < PRICE_ROUNDING_VERSION ||
        Number(rawRecord.productImageVersion ?? 0) < PRODUCT_IMAGE_VERSION ||
        rawNeedsRounding
      )
    ) {
      // Explicit owner migrations: Amortisseurs revision + clean whole DZD prices.
      storage.setItem(STORAGE_KEY, JSON.stringify(saved));
    }
    return saved;
  }

  for (const key of LEGACY_STORAGE_KEYS) {
    const raw = storage.getItem(key);
    if (raw === null || raw === "") continue;
    const legacy = parseCmsState(raw);
    storage.setItem(STORAGE_KEY, JSON.stringify(legacy));
    // Old keys remain read-only backups; all future saves use STORAGE_KEY.
    return legacy;
  }

  const initial = clone(DEFAULT_STATE);
  storage.setItem(STORAGE_KEY, JSON.stringify(initial));
  return initial;
}

function openSyncChannel(): BroadcastChannel | null {
  try {
    return typeof window.BroadcastChannel === "function"
      ? new window.BroadcastChannel(CMS_SYNC_CHANNEL)
      : null;
  } catch {
    return null;
  }
}

/** Notify listeners to read the master key, never send a potentially stale snapshot. */
function notifyCmsUpdated(): void {
  window.dispatchEvent(new Event(CMS_UPDATED_EVENT));
  const channel = openSyncChannel();
  if (!channel) return;
  try {
    channel.postMessage({ type: CMS_UPDATED_EVENT, key: STORAGE_KEY });
  } catch {
    // Native storage events still reach other tabs when BroadcastChannel is blocked.
  } finally {
    channel.close();
  }
}

/** All listeners are read-only; receiving a change must never write or reseed data. */
export function subscribeCmsUpdates(onUpdate: () => void): () => void {
  const onStorage = (event: StorageEvent) => {
    if (event.key === STORAGE_KEY || event.key === null) onUpdate();
  };
  const channel = openSyncChannel();
  if (channel) {
    channel.onmessage = (event: MessageEvent) => {
      if (event.data?.type === CMS_UPDATED_EVENT && event.data?.key === STORAGE_KEY) {
        onUpdate();
      }
    };
  }
  window.addEventListener("storage", onStorage);
  window.addEventListener(CMS_UPDATED_EVENT, onUpdate);
  return () => {
    window.removeEventListener("storage", onStorage);
    window.removeEventListener(CMS_UPDATED_EVENT, onUpdate);
    channel?.close();
  };
}

/** A successful write precedes notification. Read-only event handlers never echo it. */
export function saveState(state: CmsState): boolean {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(normalizeCmsProductImages(normalizeCmsPrices(state)))
    );
  } catch {
    return false;
  }
  notifyCmsUpdated();
  return true;
}
