import type { CmsState, Product } from "./types";

/** One-time revision for the all-catalog clean DZD price migration. */
export const PRICE_ROUNDING_VERSION = 1;

/** Commercial DZD pricing: nearest 100 DA, never fractional or negative. */
export function roundDzdPrice(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.round(value / 100) * 100);
}

export function roundProductPrices<T extends Product>(product: T): T {
  return {
    ...product,
    price: roundDzdPrice(product.price),
    priceMax:
      product.priceMax === null || product.priceMax === undefined
        ? product.priceMax
        : roundDzdPrice(product.priceMax),
    oldPrice:
      product.oldPrice === null
        ? null
        : roundDzdPrice(product.oldPrice),
  };
}

/** Normalizes all persisted product price fields in one immutable pass. */
export function normalizeCmsPrices(state: CmsState): CmsState {
  if (
    state.priceRoundingVersion === PRICE_ROUNDING_VERSION &&
    state.products.every(
      (product) =>
        product.price === roundDzdPrice(product.price) &&
        (product.priceMax == null || product.priceMax === roundDzdPrice(product.priceMax)) &&
        (product.oldPrice == null || product.oldPrice === roundDzdPrice(product.oldPrice))
    )
  ) {
    return state;
  }
  return {
    ...state,
    products: state.products.map(roundProductPrices),
    priceRoundingVersion: PRICE_ROUNDING_VERSION,
  };
}