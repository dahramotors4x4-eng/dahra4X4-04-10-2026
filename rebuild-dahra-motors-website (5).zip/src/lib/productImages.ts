import type { CmsState, Product } from "./types";

/**
 * Official Ironman 4x4 catalog media, resolved from product records on
 * ironman4x4.com / ironman4x4.com.au. Shopify's CDN is the image host used by
 * those official sites. Assets are requested at 1600px for crisp retina cards.
 */
const official = (host: "us" | "au", file: string, version: string): string => {
  const domain = host === "au"
    ? "https://www.ironman4x4.com.au"
    : "https://www.ironman4x4.com";
  return `${domain}/cdn/shop/files/${file}?v=${version}&width=1600`;
};

export const OFFICIAL_PRODUCT_MEDIA = {
  canopyFord: official("au", "ICANOPY110-Ford-PY-Ranger-Canopy-Next-Gen-Fibreglass.jpg", "1719363696"),
  canopyPinnacle: official("au", "pinnacle-2-2000-x-1600.jpg", "1766033382"),
  water20: official("us", "IWT001-20L-Plastic-Jerry-Can-Water-Tank-5-Gal-1.jpg", "1721046140"),
  water40: official("us", "IWT003-40L-Vertical-Water-Tank-10-6-Gal-1.jpg", "1721046148"),
  water50Roof: official("us", "IWT004-50L-Roof-Rack-Water-Tank-with-Barbed-Outlet-13-Gal-1.jpg", "1721046140"),
  water50Wheel: official("us", "IWT005-50L-Wheel-Arch-Water-Tank-13-Gal-1.jpg", "1721046141"),
  water50Tapered: official("us", "IWT006-50L-Tapered-Water-Tank-13-Gal-1.jpg", "1721046142"),
  fridge: official("us", "IFRIDGE40LMDR-IceCube-Drawer-Fridge-Freezer-40L-1.jpg", "1721046930"),
  awning: official("us", "IAWNINGXT-DeltaWing-90-degree-Awning-1.jpg", "1721047144"),
  recoveryBoards: official("us", "IRECBRD-Reco-Traks-Off-Road-Recovery-Boards-1.jpg", "1721046626"),
  recoveryPins: official("us", "IRECBRDPINS115-Threaded-Mounting-Pins-with-Securing-Nuts-for-Reco-Traks-1.jpg", "1721046623"),
  recoveryBase: official("us", "IRECBRDBASE-Mounting-Baseplate-for-Reco-Traks-1.jpg", "1721046621"),
  winch12000: official("us", "IMW12000MSR-Frontier-12000-lb-Winch-with-Synthetic-Rope-1.jpg", "1738977939"),
  winch9500: official("us", "IMW9500MSR-Frontier-9500-lb-Winch-with-Synthetic-Rope-1.jpg", "1738977939"),
  wirelessPlug: official("us", "WWB015-MONSTER-WINCH-Replacement-Wireless-Plug-1.jpg", "1721045308"),
  plugExtension: official("us", "WWB032-MONSTER-WINCH-5-ft-Plug-Extension-1.jpg", "1721045302"),
  winchRope: official("us", "IWINCHEXT9-5K-Winch-Extension-Rope-20_900-LBS-1.jpg", "1721046153"),
  recoverySafety: official("us", "ISNATCH8K-Recovery-Strap-17_600-LBS-1.jpg", "1721046276"),
  snorkelPrado120: official("us", "ISNORKEL006-Airforce-Snorkel-Suited-For-Lexus-GX470-Toyota-Prado-120-1.jpg", "1721046292"),
  snorkelLc200: official("us", "ISNORKEL056-Airforce-Snorkel-Suited-For-2016-Toyota-200-Series-Land-Cruiser-Lexus-LX570-2.jpg", "1721046301"),
  snorkelPrado150: official("us", "ISNORKEL035-Airforce-Snorkel-Suited-For-Lexus-GX460-Toyota-Prado-150-2.jpg", "1721046299"),
  foamCellKit: official("us", "toy050kp-100_Series-lx470_LC_FCP_Stage_3_black-2000x1600.jpg", "1780007189"),
  bullbarNavara: official("au", "BBCD048-renault-alaskan-bull-bar-deluxe-3_8f65a190-d7e8-47d1-a7b5-bbbf5e8dbbd0.jpg", "1717052728"),
  bullbarRaid: official("us", "BBR077JKK-Raid-Full-Length-Front-Bumper-Kit-Suited-for-Jeep-Wrangler-JK-2.jpg", "1721047265"),
  rearBarNavara: official("au", "RTB048-nissan-np300-navara-rear-protection-towbar_3fc029ab-f584-4818-a2bf-b47a6c15d184.jpg", "1717440157"),
  sideStepNavara: official("au", "SS048-D-Nissan-NP300-Navara-Side-Steps_e3c01f79-e872-4265-8c48-f37192f8b140.jpg", "1716981561"),
  underbodyLc70: official("au", "UBP019-toyota-70-series-landcruiser-bash-plate-underbody-protection_1978db3d-95b4-4b9a-a101-c4cab6678718.jpg", "1717053562"),
  underbodyNavara: official("au", "UBP048S-nissan-nacvara-np300-bash-plate-underbody-protection_9b856549-3c8f-435b-9ba6-2f1018b8ed0f.jpg", "1716982174"),
  underbodyGeneric: official("us", "UBP056-Heavy-Duty-Skid-Plate-Kit-Suited-For-2015-2021-Toyota-200-Series-Land-Cruiser-Lexus-LX570-1.jpg", "1721045349"),
  roofTent: official("us", "IRTT0067-Cross-1200-Rooftop-Tent-1.jpg", "1721046389"),
  roofRack: official("us", "IRROPEN14-ALLOY-Alloy-Trade-Roof-Rack-4-6-Length-1.jpg", "1721046477"),
  lightBar: official("us", "ILBSR003BW-Bright-Saber-LED-Single-Row-Light-Bar-20-1.jpg", "1721046837"),
  sideSteps: official("us", "SS073-N-edc-steps-toyota-tundra-2nd-gen-crewmax-1-2000x1600.jpg", "1749830396"),
  raidBumper: official("us", "BBR087EK-Raid-Front-Bumper-Kit-Suited-for-2019-2021-Chevrolet-Silverado-1500-3.jpg", "1721047263"),
  battery: official("au", "SA12V105C.jpg", "1739155333"),
  allTerrainTire: "https://cdn11.bigcommerce.com/s-8zxb6tk/images/stencil/1280x1280/products/687030/922909/product_image1__19714.1685677537.png?c=2",
  nitroGas: official("us", "12683GR-Front-Shock-Absorber-Nitro-Gas-Suited-For-Toyota-80-Series-Land-Cruiser-Lexus-LX450-1.jpg", "1721047530"),
  foamCell: official("au", "Foamcell-4_f0be269d-209d-46a9-bb26-82edec777992.jpg", "1724382651"),
  foamCellProShock: official("au", "Foamcell-Pro-3_fd564aa5-db9e-421f-8f8d-5a982cbbc40f.jpg", "1724382253"),
  im25Monotube: official("au", "4x4x-Monotube-Coil-Over-Shock-Absorber-IM25-1.jpg", "1723774652"),
  steeringDamper: official("us", "3544-Steering-Damper-Suited-For-2018-2020-Jeep-Wrangler-JL-JLU-Gladiator-JT-1.jpg", "1721047531"),
  trimPacker: official("au", "Ironman_trim-packers.jpg", "1737435539"),
  strutTop: official("au", "strut-mounts_1_69b9460d-4bcb-4ea1-a4c8-ab1f762bb4c9.webp", "1761275255"),
} as const;

/**
 * Revision 2 removes the historical global winch fallback from every product
 * gallery and sanitizes already-persisted dahra_cms_v2 media arrays.
 */
export const PRODUCT_IMAGE_VERSION = 3;

const officialUs = (file: string, version: string) =>
  official("us", file, version);
const officialAu = (file: string, version: string) =>
  official("au", file, version);

/** Product-specific galleries from official Shopify product records. */
const MEDIA_SETS = {
  canopy: [
    OFFICIAL_PRODUCT_MEDIA.canopyPinnacle,
    OFFICIAL_PRODUCT_MEDIA.canopyFord,
    officialAu("Fibreglass-Canopy-Toyota-Hilux-2018.jpg", "1719450634"),
    officialAu("D-MAX_Raid_Canopy_Tradie_Pack.jpg", "1725423978"),
  ],
  waterTank: [
    OFFICIAL_PRODUCT_MEDIA.water50Wheel,
    officialUs("IWT005-50L-Wheel-Arch-Water-Tank-13-Gal-2.jpg", "1721046141"),
    officialUs("IWT005-50L-Wheel-Arch-Water-Tank-13-Gal-3.jpg", "1721046142"),
  ],
  fridge: [
    OFFICIAL_PRODUCT_MEDIA.fridge,
    officialUs("IFRIDGE40LMDR-IceCube-Drawer-Fridge-Freezer-40L-2.jpg", "1721046926"),
    officialUs("IFRIDGE40LMDR-IceCube-Drawer-Fridge-Freezer-40L-3.jpg", "1721046939"),
    officialUs("IFRIDGE40LMDR-IceCube-Drawer-Fridge-Freezer-40L-4.jpg", "1721046940"),
  ],
  awning: [
    OFFICIAL_PRODUCT_MEDIA.awning,
    officialUs("90-Slide1-2100x1600.jpg", "1762008335"),
    officialUs("90-Slide2-2100x1600.jpg", "1762008335"),
    officialUs("IAWNINGXT-DeltaWing-90-degree-Awning-3.jpg", "1762008335"),
  ],
  recoveryBoards: [
    OFFICIAL_PRODUCT_MEDIA.recoveryBoards,
    officialUs("IRECBRD-Reco-Traks-Off-Road-Recovery-Boards-3.jpg", "1734750253"),
    officialUs("IRECBRD-Reco-Traks-Off-Road-Recovery-Boards-2.jpg", "1734750253"),
    officialUs("irecbrd-lifestle-closeup-reco-traks.jpg", "1772231336"),
  ],
  recoveryHardware: [
    OFFICIAL_PRODUCT_MEDIA.recoveryPins,
    OFFICIAL_PRODUCT_MEDIA.recoveryBase,
    officialUs("IRECBRD-Reco-Traks-Off-Road-Recovery-Boards-3.jpg", "1734750253"),
  ],
  winch12000: [
    OFFICIAL_PRODUCT_MEDIA.winch12000,
    officialUs("IMW12000MSR-Frontier-12000-lb-Winch-with-Synthetic-Rope-2.jpg", "1738977940"),
    officialUs("IMW12000MSR-Frontier-12000-lb-Winch-with-Synthetic-Rope-3.jpg", "1738977940"),
    officialUs("IMW12000MSR-Frontier-12000-lb-Winch-with-Synthetic-Rope-4.jpg", "1738977940"),
  ],
  winch9500: [
    OFFICIAL_PRODUCT_MEDIA.winch9500,
    officialUs("IMW9500MSR-Frontier-9500-lb-Winch-with-Synthetic-Rope-2.jpg", "1738977940"),
    officialUs("IMW9500MSR-Frontier-9500-lb-Winch-with-Synthetic-Rope-3.jpg", "1738977940"),
  ],
  winchAccessories: [
    OFFICIAL_PRODUCT_MEDIA.wirelessPlug,
    OFFICIAL_PRODUCT_MEDIA.plugExtension,
    OFFICIAL_PRODUCT_MEDIA.winchRope,
    OFFICIAL_PRODUCT_MEDIA.recoverySafety,
  ],
  nitroGas: [
    OFFICIAL_PRODUCT_MEDIA.nitroGas,
    officialAu("Nitrogas-2_98caeec5-3353-4e76-89da-5ded8be3467e.jpg", "1724382960"),
    officialAu("Nitrogas-2_631245c8-70b8-43f5-9f05-2adeb5e7f682.jpg", "1724382486"),
    officialAu("Nitrogas-2_62034a7d-be8a-4db1-94d2-484f0824566d.jpg", "1724382445"),
  ],
  foamCell: [
    OFFICIAL_PRODUCT_MEDIA.foamCell,
    officialAu("Foamcell-4_2eed2935-ea8d-4540-a86f-20578d49713e.jpg", "1724382328"),
    officialUs("45744FE-Foam-Cell-Pro-Rear-Shock-Suited-For-2005-2023-Toyota-Tacoma-1_0c4dd739-6b2e-4ddc-93c5-6e8ed678b197.jpg", "1721047476"),
  ],
  foamCellPro: [
    OFFICIAL_PRODUCT_MEDIA.foamCellProShock,
    officialAu("Foamcell-Pro-3_095e7722-9645-43af-a913-cc61a9afb705.jpg", "1724382923"),
    officialAu("Foamcell-Pro-3_e93a7c45-5e15-4a59-966f-b2c3bb7dea75.jpg", "1724382250"),
    officialAu("Foamcell-Pro-3_ecd19510-89af-40e9-b751-da140495a4f6.jpg", "1724382609"),
  ],
  im25: [
    OFFICIAL_PRODUCT_MEDIA.im25Monotube,
    officialUs("im2-5-shock-absorber-1-2000x1600.jpg", "1742947393"),
    officialAu("4x4x-Monotube-Coil-Over-Shock-Absorber-IM25-1.jpg", "1723774652"),
  ],
  steering: [
    OFFICIAL_PRODUCT_MEDIA.steeringDamper,
    officialUs("3524-Steering-Damper-Suited-For-Toyota-60-70-73-74-75-80-Series-Land-Cruiser-Lexus-LX450-1.jpg", "1721047531"),
  ],
  spacers: [
    OFFICIAL_PRODUCT_MEDIA.trimPacker,
    OFFICIAL_PRODUCT_MEDIA.strutTop,
    officialAu("strut-mounts_3352639b-1e63-4959-8aef-e0e2b55c94b6.webp", "1746512223"),
  ],
  snorkel: [
    OFFICIAL_PRODUCT_MEDIA.snorkelPrado120,
    officialUs("ISNORKEL006-Airforce-Snorkel-Suited-For-Lexus-GX470-Toyota-Prado-120-2.jpg", "1721046270"),
    OFFICIAL_PRODUCT_MEDIA.snorkelLc200,
    OFFICIAL_PRODUCT_MEDIA.snorkelPrado150,
  ],
  underbody: [
    OFFICIAL_PRODUCT_MEDIA.underbodyLc70,
    OFFICIAL_PRODUCT_MEDIA.underbodyNavara,
    OFFICIAL_PRODUCT_MEDIA.underbodyGeneric,
  ],
  bullbar: [
    OFFICIAL_PRODUCT_MEDIA.bullbarNavara,
    officialAu("BBCD048-renault-alaskan-bull-bar-deluxe-4_78f9660d-c80f-4195-8358-4ed01b0f55d8.jpg", "1717052728"),
    officialAu("BBCD048-renault-alaskan-bull-bar-deluxe-1_ad751f88-89d9-4ad6-a460-7ccc5b174f80.jpg", "1717052728"),
    OFFICIAL_PRODUCT_MEDIA.bullbarRaid,
  ],
  rearBar: [
    OFFICIAL_PRODUCT_MEDIA.rearBarNavara,
    officialAu("ram-dt-rear-row-protect-2000x1600.jpg", "1742171804"),
  ],
  sideSteps: [
    OFFICIAL_PRODUCT_MEDIA.sideStepNavara,
    OFFICIAL_PRODUCT_MEDIA.sideSteps,
    officialUs("SS077JT-Raid-Heavy-Duty-Side-Steps-Suited-For-2020-2022-Jeep-Gladiator-JT-1.jpg", "1721045810"),
  ],
  roofTent: [
    OFFICIAL_PRODUCT_MEDIA.roofTent,
    officialUs("Cross-Slide1-2100x1600.jpg", "1775146392"),
    officialUs("Cross-Slide2-2100x1600.jpg", "1762008701"),
    officialUs("IRTT0067-Cross-1200-Rooftop-Tent-3.jpg", "1762008701"),
  ],
  roofRack: [
    OFFICIAL_PRODUCT_MEDIA.roofRack,
    officialUs("IRRTENT18-Steel-Hybrid-Flat-Top-Roof-Rack-6_-Length-1.jpg", "1721046477"),
    officialUs("IRRTRADE22-ALLOY-78-Alloy-Trade-Roof-Rack-7-2-Length-Suited-For-Toyota-78-Series-Land-Cruiser-1.jpg", "1721046475"),
  ],
  lightBar: [
    OFFICIAL_PRODUCT_MEDIA.lightBar,
    officialUs("ILBDR002B-Bright-Saber-LED-Dual-Row-Light-Bar-32-1.jpg", "1721046837"),
    officialUs("ILBSR001-Night-Saber-LED-Single-Row-Light-Bar-37-1.jpg", "1721046837"),
  ],
  battery: [
    officialAu("SA12V105C.jpg", "1739155333"),
    officialAu("SA12V125C.jpg", "1739155379"),
  ],
  tires: [
    "https://cdn11.bigcommerce.com/s-8zxb6tk/images/stencil/1280x1280/products/687030/922909/product_image1__19714.1685677537.png?c=2",
    "https://cdn11.bigcommerce.com/s-8zxb6tk/images/stencil/1280x1280/products/687030/922910/product_image2__33483.1685677537.png?c=2",
    "https://cdn11.bigcommerce.com/s-8zxb6tk/images/stencil/1280x1280/products/687030/922911/product_image0__63321.1685677537.png?c=2",
  ],
} as const;

const bySku: Record<string, string> = {
  "CANOPY003-P": OFFICIAL_PRODUCT_MEDIA.canopyPinnacle,
  "CANOPY010-P": OFFICIAL_PRODUCT_MEDIA.canopyFord,
  "CANOPY013-PW": OFFICIAL_PRODUCT_MEDIA.canopyPinnacle,
  IWT001: OFFICIAL_PRODUCT_MEDIA.water20,
  IWT002: OFFICIAL_PRODUCT_MEDIA.water40,
  IWT003: OFFICIAL_PRODUCT_MEDIA.water40,
  IWT004: OFFICIAL_PRODUCT_MEDIA.water50Roof,
  IWT005: OFFICIAL_PRODUCT_MEDIA.water50Wheel,
  IWT006: OFFICIAL_PRODUCT_MEDIA.water50Tapered,
  IWTHOSE: OFFICIAL_PRODUCT_MEDIA.water20,
  IFR45: OFFICIAL_PRODUCT_MEDIA.fridge,
  IAW2500: OFFICIAL_PRODUCT_MEDIA.awning,
  IRECBDGREEN: OFFICIAL_PRODUCT_MEDIA.recoveryBoards,
  IRECBDGREY: OFFICIAL_PRODUCT_MEDIA.recoveryBoards,
  IRECBDSAND: OFFICIAL_PRODUCT_MEDIA.recoveryBoards,
  IRECBDPINS115: OFFICIAL_PRODUCT_MEDIA.recoveryPins,
  IRECBRDBASE: OFFICIAL_PRODUCT_MEDIA.recoveryBase,
  IMW12000_MSR: OFFICIAL_PRODUCT_MEDIA.winch12000,
  IMW12000MWR: OFFICIAL_PRODUCT_MEDIA.winch12000,
  IMW9500_MSR: OFFICIAL_PRODUCT_MEDIA.winch9500,
  WWB9500: OFFICIAL_PRODUCT_MEDIA.winch9500,
  WWB001: OFFICIAL_PRODUCT_MEDIA.winch9500,
  WWB015: OFFICIAL_PRODUCT_MEDIA.wirelessPlug,
  WWB031: OFFICIAL_PRODUCT_MEDIA.plugExtension,
  WINCHBLANKET: OFFICIAL_PRODUCT_MEDIA.recoverySafety,
  WWWFAIRELEAD: OFFICIAL_PRODUCT_MEDIA.winch12000,
  WWWHAWSE: OFFICIAL_PRODUCT_MEDIA.winch12000,
  WWWROPE001: OFFICIAL_PRODUCT_MEDIA.winchRope,
  "IFCPKIT-HILUX": OFFICIAL_PRODUCT_MEDIA.foamCellKit,
  "IFCP-SHOCK": OFFICIAL_PRODUCT_MEDIA.foamCellProShock,
  "IFCPKIT-PRADO": OFFICIAL_PRODUCT_MEDIA.foamCellKit,
  "IBULL-HILUX": OFFICIAL_PRODUCT_MEDIA.bullbarNavara,
  "ISIDE-ALU": OFFICIAL_PRODUCT_MEDIA.sideSteps,
  "ITENT-DBL": OFFICIAL_PRODUCT_MEDIA.roofTent,
  "IGAL-4B": OFFICIAL_PRODUCT_MEDIA.roofRack,
  "ISNR-HILUX": OFFICIAL_PRODUCT_MEDIA.snorkelPrado120,
  "ISNR-NAVARA": OFFICIAL_PRODUCT_MEDIA.snorkelPrado150,
  "ILED-52": OFFICIAL_PRODUCT_MEDIA.lightBar,
  "IAGM-100": OFFICIAL_PRODUCT_MEDIA.battery,
  UBP019: OFFICIAL_PRODUCT_MEDIA.underbodyLc70,
  UBP048: OFFICIAL_PRODUCT_MEDIA.underbodyNavara,
  ISNORKEL006: OFFICIAL_PRODUCT_MEDIA.snorkelPrado120,
  ISNORKEL056: OFFICIAL_PRODUCT_MEDIA.snorkelLc200,
  ISNORKEL064: OFFICIAL_PRODUCT_MEDIA.snorkelPrado150,
  "BBCD048 + IRP005": OFFICIAL_PRODUCT_MEDIA.bullbarNavara,
  BBR077: OFFICIAL_PRODUCT_MEDIA.bullbarRaid,
  BBR077ST: OFFICIAL_PRODUCT_MEDIA.bullbarRaid,
  "RTB048 + RTBPLATE001": OFFICIAL_PRODUCT_MEDIA.rearBarNavara,
  SS048: OFFICIAL_PRODUCT_MEDIA.sideStepNavara,
};

const byCategory: Record<string, string> = {
  canopy: OFFICIAL_PRODUCT_MEDIA.canopyPinnacle,
  camping: OFFICIAL_PRODUCT_MEDIA.fridge,
  recovery: OFFICIAL_PRODUCT_MEDIA.recoveryBoards,
  "treuil-winch": OFFICIAL_PRODUCT_MEDIA.winch12000,
  suspension: OFFICIAL_PRODUCT_MEDIA.foamCellProShock,
  protection: OFFICIAL_PRODUCT_MEDIA.underbodyGeneric,
  "pare-choc-avant": OFFICIAL_PRODUCT_MEDIA.raidBumper,
  "pare-choc-arriere": OFFICIAL_PRODUCT_MEDIA.rearBarNavara,
  "marche-pied": OFFICIAL_PRODUCT_MEDIA.sideSteps,
  snorkels: OFFICIAL_PRODUCT_MEDIA.snorkelPrado150,
  "roof-racks": OFFICIAL_PRODUCT_MEDIA.roofRack,
  lighting: OFFICIAL_PRODUCT_MEDIA.lightBar,
  "wheels-tires": OFFICIAL_PRODUCT_MEDIA.allTerrainTire,
};

const bySkuSet: Record<string, readonly string[]> = {
  "CANOPY003-P": MEDIA_SETS.canopy,
  "CANOPY010-P": MEDIA_SETS.canopy,
  "CANOPY013-PW": MEDIA_SETS.canopy,
  IWT001: MEDIA_SETS.waterTank,
  IWT002: MEDIA_SETS.waterTank,
  IWT003: MEDIA_SETS.waterTank,
  IWT004: MEDIA_SETS.waterTank,
  IWT005: MEDIA_SETS.waterTank,
  IWT006: MEDIA_SETS.waterTank,
  IWTHOSE: [
    officialAu("IWTHOSE-water-tank-hose-kit-4x4_04dc6746-5c1c-4af4-b99d-47e38a78b402.jpg", "1716981854"),
    OFFICIAL_PRODUCT_MEDIA.water20,
  ],
  IFR45: MEDIA_SETS.fridge,
  IAW2500: MEDIA_SETS.awning,
  IRECBDGREEN: MEDIA_SETS.recoveryBoards,
  IRECBDGREY: MEDIA_SETS.recoveryBoards,
  IRECBDSAND: MEDIA_SETS.recoveryBoards,
  IRECBDPINS115: MEDIA_SETS.recoveryHardware,
  IRECBRDBASE: MEDIA_SETS.recoveryHardware,
  IMW12000_MSR: MEDIA_SETS.winch12000,
  IMW12000MWR: MEDIA_SETS.winch12000,
  IMW9500_MSR: MEDIA_SETS.winch9500,
  WWB9500: MEDIA_SETS.winch9500,
  WWB001: MEDIA_SETS.winchAccessories,
  WWB015: MEDIA_SETS.winchAccessories,
  WWB031: MEDIA_SETS.winchAccessories,
  WINCHBLANKET: MEDIA_SETS.winchAccessories,
  WWWFAIRELEAD: MEDIA_SETS.winchAccessories,
  WWWHAWSE: MEDIA_SETS.winchAccessories,
  WWWROPE001: MEDIA_SETS.winchAccessories,
  "IFCPKIT-HILUX": MEDIA_SETS.foamCellPro,
  "IFCP-SHOCK": MEDIA_SETS.foamCellPro,
  "IFCPKIT-PRADO": MEDIA_SETS.foamCellPro,
  "IBULL-HILUX": MEDIA_SETS.bullbar,
  "ISIDE-ALU": MEDIA_SETS.sideSteps,
  "ITENT-DBL": MEDIA_SETS.roofTent,
  "IGAL-4B": MEDIA_SETS.roofRack,
  "ISNR-HILUX": MEDIA_SETS.snorkel,
  "ISNR-NAVARA": MEDIA_SETS.snorkel,
  "ILED-52": MEDIA_SETS.lightBar,
  "IAGM-100": MEDIA_SETS.battery,
  "IAT-315-17": MEDIA_SETS.tires,
  "IMT-37": MEDIA_SETS.tires,
};

const byCategorySet: Record<string, readonly string[]> = {
  canopy: MEDIA_SETS.canopy,
  camping: MEDIA_SETS.fridge,
  recovery: MEDIA_SETS.recoveryBoards,
  "treuil-winch": MEDIA_SETS.winchAccessories,
  suspension: MEDIA_SETS.foamCellPro,
  protection: MEDIA_SETS.underbody,
  "pare-choc-avant": MEDIA_SETS.bullbar,
  "pare-choc-arriere": MEDIA_SETS.rearBar,
  "marche-pied": MEDIA_SETS.sideSteps,
  snorkels: MEDIA_SETS.snorkel,
  "roof-racks": MEDIA_SETS.roofRack,
  lighting: MEDIA_SETS.lightBar,
  "wheels-tires": MEDIA_SETS.tires,
};

function suspensionSeriesImage(sku: string): string | null {
  const value = sku.toUpperCase();
  if (/^12\d{3}(?:L?GR|GRC)|^127\d{2}GR|^12851/.test(value)) {
    return OFFICIAL_PRODUCT_MEDIA.nitroGas;
  }
  if (/^240|^247/.test(value)) return OFFICIAL_PRODUCT_MEDIA.foamCell;
  if (/^45\d{3}FE/.test(value)) return OFFICIAL_PRODUCT_MEDIA.foamCellProShock;
  if (/^(?:71|72|73)-057-/.test(value)) return OFFICIAL_PRODUCT_MEDIA.im25Monotube;
  if (/^35\d{2}/.test(value)) return OFFICIAL_PRODUCT_MEDIA.steeringDamper;
  if (/^HILFR/.test(value)) return OFFICIAL_PRODUCT_MEDIA.trimPacker;
  if (/^ISST/.test(value)) return OFFICIAL_PRODUCT_MEDIA.strutTop;
  return null;
}

function suspensionSeriesSet(sku: string): readonly string[] | null {
  const value = sku.toUpperCase();
  if (/^12\d{3}(?:L?GR|GRC)|^127\d{2}GR|^12851/.test(value)) return MEDIA_SETS.nitroGas;
  if (/^240|^247/.test(value)) return MEDIA_SETS.foamCell;
  if (/^45\d{3}FE/.test(value)) return MEDIA_SETS.foamCellPro;
  if (/^(?:71|72|73)-057-/.test(value)) return MEDIA_SETS.im25;
  if (/^35\d{2}/.test(value)) return MEDIA_SETS.steering;
  if (/^HILFR|^ISST/.test(value)) return MEDIA_SETS.spacers;
  return null;
}

/** The authoritative 2–4 image set for a catalog product. */
export function officialMediaSetFor(
  product: Pick<Product, "sku" | "categorySlug">
): string[] {
  const set = bySkuSet[product.sku] ??
    (product.categorySlug === "suspension" ? suspensionSeriesSet(product.sku) : null) ??
    byCategorySet[product.categorySlug] ??
    [];
  return Array.from(new Set(set.filter(Boolean))).slice(0, 4);
}

/** Returns an official SKU image first, then an official product-family image. */
export function officialImageFor(product: Pick<Product, "sku" | "categorySlug">): string | null {
  return officialMediaSetFor(product)[0] ??
    bySku[product.sku] ??
    (product.categorySlug === "suspension" ? suspensionSeriesImage(product.sku) : null) ??
    byCategory[product.categorySlug] ??
    null;
}

const WINCH_CATEGORIES = new Set(["treuil-winch"]);
const WINCH_SKU = /^(?:IMW|WWB|WWW)|WINCH/i;
const WINCH_MEDIA = new Set([
  OFFICIAL_PRODUCT_MEDIA.winch12000,
  OFFICIAL_PRODUCT_MEDIA.winch9500,
  OFFICIAL_PRODUCT_MEDIA.wirelessPlug,
  OFFICIAL_PRODUCT_MEDIA.plugExtension,
  OFFICIAL_PRODUCT_MEDIA.winchRope,
]);

export function isWinchProduct(
  product: Pick<Product, "sku" | "categorySlug">
): boolean {
  return WINCH_CATEGORIES.has(product.categorySlug) || WINCH_SKU.test(product.sku);
}

/** Recognizes every winch fallback URL used by previous catalog revisions. */
export function isWinchImage(source: string): boolean {
  if (WINCH_MEDIA.has(source)) return true;
  return /(?:\/images\/winch-kit\.jpg|IMW(?:12000|9500)|MONSTER-WINCH|Frontier-(?:12000|9500)-lb-Winch|monster-winch)/i.test(
    source
  );
}

function allowedProductSource(
  product: Pick<Product, "sku" | "categorySlug">,
  source: string
): boolean {
  return isWinchProduct(product) || !isWinchImage(source);
}

/**
 * Apply official imagery while retaining the previous high-resolution image as
 * a runtime fallback / secondary gallery item. The operation is deterministic.
 */
export function curateProductImage(product: Product): Product {
  const officialSet = officialMediaSetFor(product);
  const previousSources = [product.image, ...(product.images ?? [])].filter(
    (source): source is string => Boolean(source) && allowedProductSource(product, source)
  );
  const set = officialSet.length >= 2 ? officialSet : previousSources.slice(0, 4);
  const primary = set[0] ?? "";
  return {
    ...product,
    image: primary,
    images: Array.from(new Set(set.slice(1, 4))),
  };
}

/**
 * Prior builds seeded local generated files and Pexels category photos. Replace
 * those once. Data URLs and arbitrary/admin-hosted URLs are owner content and
 * must never be overwritten by an automatic catalog migration.
 */
export function shouldReplaceLegacyProductImage(image: string): boolean {
  if (!image) return true;
  if (image.startsWith("data:")) return false;
  if (image.startsWith("/images/")) return true;
  return /images\.pexels\.com/i.test(image);
}

/**
 * Product-specific source chain only. There is deliberately no global image
 * fallback: a canopy, spacer, bushing or shock can never fall through to a
 * winch thumbnail.
 */
export function productImageSources(product: Pick<Product, "image" | "images" | "sku" | "categorySlug">): string[] {
  const officialSet = officialMediaSetFor(product);
  return Array.from(
    new Set(
      [
        product.image,
        ...(product.images ?? []),
        ...officialSet,
      ].filter(
        (source): source is string => {
          if (!source) return false;
          return allowedProductSource(product, source);
        }
      )
    )
  ).slice(0, 4);
}

/** Removes historical winch fallbacks from non-winch primary/gallery media. */
export function sanitizeProductImages(product: Product): Product {
  const sources = productImageSources(product).slice(0, 4);
  const primary = sources[0] ?? "";
  return {
    ...product,
    image: primary,
    images: Array.from(new Set(sources.filter((source) => source !== primary))),
  };
}

/** Strictly sanitize every persisted product media field for revision 2. */
export function normalizeCmsProductImages(state: CmsState): CmsState {
  if ((state.productImageVersion ?? 0) >= PRODUCT_IMAGE_VERSION) return state;
  return {
    ...state,
    products: state.products.map(curateProductImage),
    productImageVersion: PRODUCT_IMAGE_VERSION,
  };
}