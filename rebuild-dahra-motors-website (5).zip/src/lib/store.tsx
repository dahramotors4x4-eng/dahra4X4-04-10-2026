import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type {
  ActivityEntry,
  Analytics,
  Category,
  CmsState,
  Credentials,
  GalleryItem,
  HeroSlide,
  Localized,
  Order,
  OrderStatus,
  Product,
  Settings,
  SiteContent,
  VideoSection,
} from "./types";
import {
  ADMIN_PASSWORD,
  ADMIN_USERNAME,
  STORAGE_KEY,
  emptyCmsState,
  loadState,
  readSavedState,
  saveState,
  subscribeCmsUpdates,
} from "./data";
import { translate, type Lang, type TKey } from "./i18n";
import { WHATSAPP_GREETING } from "./data";
import { normalizeCmsPrices, roundDzdPrice } from "./pricing";
import { normalizeCmsProductImages } from "./productImages";

const ANALYTICS_KEY = "dahra_analytics_v1";
const VISIT_FLAG = "dahra_visit_counted";
const ACTIVITY_KEY = "dahra_activity_v1";
const ADMIN_USER_KEY = "dahra_admin_user";
const THEME_KEY = "dahra_theme";
const LANG_KEY = "dahra_lang";
/** Persistent, versioned admin token. It survives route changes, reloads and browser restarts. */
export const ADMIN_SESSION_KEY = "dahra_admin_session_v2";
const LEGACY_SESSION_KEY = "dahra_admin_session";
const ADMIN_SESSION_VERSION = 1;

export const ADMIN_USERS = ["issam", "halim", "samir", "bilal"];

function readPreference(key: string, session = false): string | null {
  try {
    return (session ? sessionStorage : localStorage).getItem(key);
  } catch {
    return null;
  }
}

function writePreference(key: string, value: string | null, session = false): void {
  try {
    const storage = session ? sessionStorage : localStorage;
    if (value === null) storage.removeItem(key);
    else storage.setItem(key, value);
  } catch {
    // Optional UI preferences must not hide the CMS storage error notice.
  }
}

interface AdminSessionToken {
  version: number;
  authenticated: true;
  username: string;
  issuedAt: number;
  nonce: string;
}

function parseAdminSession(raw: string | null): AdminSessionToken | null {
  if (!raw) return null;
  try {
    const value = JSON.parse(raw) as Partial<AdminSessionToken>;
    return value.version === ADMIN_SESSION_VERSION &&
      value.authenticated === true &&
      typeof value.username === "string" &&
      typeof value.issuedAt === "number" &&
      typeof value.nonce === "string"
      ? (value as AdminSessionToken)
      : null;
  } catch {
    return null;
  }
}

function getAdminSession(): AdminSessionToken | null {
  try {
    return parseAdminSession(localStorage.getItem(ADMIN_SESSION_KEY)) ??
      parseAdminSession(sessionStorage.getItem(ADMIN_SESSION_KEY));
  } catch {
    return null;
  }
}

function persistAdminSession(username: string): void {
  const token: AdminSessionToken = {
    version: ADMIN_SESSION_VERSION,
    authenticated: true,
    username,
    issuedAt: Date.now(),
    nonce: globalThis.crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2),
  };
  const raw = JSON.stringify(token);
  try {
    localStorage.setItem(ADMIN_SESSION_KEY, raw);
    sessionStorage.removeItem(ADMIN_SESSION_KEY);
  } catch {
    // Storage-restricted browsers still retain access for the current tab.
    try {
      sessionStorage.setItem(ADMIN_SESSION_KEY, raw);
    } catch {
      // React state still grants access for the current mounted application.
    }
  }
}

function clearAdminSession(): void {
  try {
    localStorage.removeItem(ADMIN_SESSION_KEY);
  } catch {
    /* ignore */
  }
  try {
    sessionStorage.removeItem(ADMIN_SESSION_KEY);
    sessionStorage.removeItem(LEGACY_SESSION_KEY);
  } catch {
    /* ignore */
  }
}

function loadActivity(): ActivityEntry[] {
  try {
    const raw = localStorage.getItem(ACTIVITY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as ActivityEntry[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

const EMPTY_ANALYTICS: Analytics = {
  visits: 0,
  orders: 0,
  searches: 0,
  queries: {},
  daily: {},
};

function loadAnalytics(): Analytics {
  try {
    const raw = localStorage.getItem(ANALYTICS_KEY);
    if (!raw) return { ...EMPTY_ANALYTICS };
    return { ...EMPTY_ANALYTICS, ...(JSON.parse(raw) as Partial<Analytics>) };
  } catch {
    return { ...EMPTY_ANALYTICS };
  }
}

/** Brand colors exposed globally (mirrors the CSS tokens in index.css). */
export const BRAND_COLORS = { brand: "#22C55E", brandStrong: "#84CC16", charcoal: "#18181B" } as const;

/** Global, read-only view of the site configuration for every component. */
export interface SiteConfig {
  logo: { header: string; footer: string };
  storeName: string;
  contact: { phone: string; phones: string[]; whatsapp: string; email: string };
  hero: {
    slides: HeroSlide[];
    title: Localized | null;
    subtitle: Localized | null;
    background: string;
  };
  theme: "dark" | "light";
  colors: typeof BRAND_COLORS;
  products: Product[];
  delivery: { title: Localized; text: Localized } | null;
}

/** Anything updateCmsConfig accepts: a partial (or full) config, or a function returning one. */
export type CmsConfigInput = Partial<CmsState> | ((prev: CmsState) => Partial<CmsState>);

interface CmsContextValue {
  state: CmsState;
  /** Unified site configuration (logo, hero text/background, theme, colors, products). */
  siteConfig: SiteConfig;
  /**
   * Global save: updates React state, synchronously runs
   * localStorage.setItem('dahra_cms_v2', JSON.stringify(newConfig)),
   * and dispatches window 'dahra_cms_updated'. Returns whether the write succeeded.
   */
  updateCmsConfig: (config: CmsConfigInput, label?: string) => boolean;
  refreshCms: () => void;
  lang: Lang;
  theme: "dark" | "light";
  isAdmin: boolean;
  backendMode: "localStorage";
  remoteEnabled: boolean;
  /** Timestamp of the last successful localStorage write (null = none yet). */
  lastSavedAt: number | null;
  storageError: string | null;
  analytics: Analytics;
  activity: ActivityEntry[];
  adminUser: string | null;
  setAdminUser: (name: string | null) => void;
  trackSearch: (query: string) => void;
  trackOrder: () => void;
  t: (key: TKey) => string;
  setLang: (lang: Lang) => void;
  toggleTheme: () => void;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  updateSettings: (patch: Partial<Settings>) => boolean;
  updateCredentials: (creds: Credentials) => boolean;
  updateContent: (patch: Partial<SiteContent>) => boolean;
  updateVideoSection: (patch: Partial<VideoSection>) => boolean;
  saveHeroSlide: (slide: HeroSlide) => boolean;
  deleteHeroSlide: (id: string) => boolean;
  saveCategory: (cat: Category) => boolean;
  deleteCategory: (id: string) => boolean;
  saveGalleryItem: (item: GalleryItem) => boolean;
  deleteGalleryItem: (id: string) => boolean;
  saveProduct: (product: Product) => boolean;
  deleteProduct: (id: string) => boolean;
  addOrder: (order: Order) => boolean;
  updateOrderStatus: (id: string, status: OrderStatus) => boolean;
  deleteOrder: (id: string) => boolean;
}

const CmsContext = createContext<CmsContextValue | null>(null);

export function CmsProvider({ children }: { children: ReactNode }) {
  const [initial] = useState(() => {
    try {
      return { state: loadState(), error: null as string | null };
    } catch {
      return {
        state: emptyCmsState(),
        error: "Lecture du stockage impossible. Les donnees existantes n'ont pas ete remplacees.",
      };
    }
  });
  const [state, setState] = useState<CmsState>(initial.state);
  const [storageError, setStorageError] = useState<string | null>(initial.error);
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    const saved = readPreference(THEME_KEY);
    return saved === "dark" ? "dark" : "light";
  });
  const [lang, setLangState] = useState<Lang>(() => {
    const saved = readPreference(LANG_KEY);
    return saved === "ar" ? "ar" : "fr";
  });
  const [isAdmin, setIsAdmin] = useState<boolean>(
    () => getAdminSession() !== null
  );
  const [analytics, setAnalytics] = useState<Analytics>(loadAnalytics);
  const [activity, setActivity] = useState<ActivityEntry[]>(loadActivity);
  const [adminUser, setAdminUserState] = useState<string | null>(
    () => readPreference(ADMIN_USER_KEY, true)
  );
  // Timestamp of the last successful localStorage write — drives the admin
  // "saved" confirmation so persistence is visible, not assumed.
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);
  const stateRef = useRef(state);
  const adminUserRef = useRef(adminUser);
  adminUserRef.current = adminUser;

  // Reads never persist or broadcast: this avoids stale-tab and remote echo loops.
  const acceptState = useCallback((next: CmsState) => {
    if (JSON.stringify(stateRef.current) === JSON.stringify(next)) return;
    stateRef.current = next;
    setState(next);
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(ACTIVITY_KEY, JSON.stringify(activity));
    } catch {
      /* ignore quota errors */
    }
  }, [activity]);

  const setAdminUser = useCallback((name: string | null) => {
    writePreference(ADMIN_USER_KEY, name, true);
    setAdminUserState(name);
  }, []);

  /** Audit trail: records every admin CRUD operation with the selected user. */
  const logActivity = useCallback((action: string, item: string) => {
    const entry: ActivityEntry = {
      id: globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      ts: Date.now(),
      user: adminUserRef.current ?? "admin",
      action,
      item,
    };
    setActivity((prev) => [entry, ...prev].slice(0, 500));
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(ANALYTICS_KEY, JSON.stringify(analytics));
    } catch {
      /* ignore */
    }
  }, [analytics]);

  // Count one site visit per browser session
  useEffect(() => {
    if (readPreference(VISIT_FLAG, true)) return;
    writePreference(VISIT_FLAG, "1", true);
    const today = new Date().toISOString().slice(0, 10);
    setAnalytics((a) => ({
      ...a,
      visits: a.visits + 1,
      daily: { ...a.daily, [today]: (a.daily[today] ?? 0) + 1 },
    }));
  }, []);

  // Real-time analytics sync: cross-tab storage events + 5s polling refresh
  useEffect(() => {
    const pull = () => {
      try {
        const raw = localStorage.getItem(ANALYTICS_KEY);
        if (!raw) return;
        const next = JSON.parse(raw) as Analytics;
        setAnalytics((prev) =>
          JSON.stringify(prev) === JSON.stringify(next) ? prev : { ...EMPTY_ANALYTICS, ...next }
        );
      } catch {
        /* ignore malformed payloads */
      }
    };
    const onStorage = (e: StorageEvent) => {
      if (e.key === ANALYTICS_KEY) pull();
    };
    window.addEventListener("storage", onStorage);
    const id = setInterval(pull, 5000);
    return () => {
      window.removeEventListener("storage", onStorage);
      clearInterval(id);
    };
  }, []);

  const trackSearch = useCallback((query: string) => {
    const q = query.trim().toLowerCase();
    if (!q) return;
    setAnalytics((a) => ({
      ...a,
      searches: a.searches + 1,
      queries: { ...a.queries, [q]: (a.queries[q] ?? 0) + 1 },
    }));
  }, []);

  const trackOrder = useCallback(() => {
    setAnalytics((a) => ({ ...a, orders: a.orders + 1 }));
  }, []);

  // Navigation, tab notifications and focus can only READ the latest saved document.
  const refreshCms = useCallback(() => {
    try {
      const fresh = readSavedState();
      if (fresh === null) {
        setStorageError(`Le document ${STORAGE_KEY} est absent. La derniere version reste affichee ; aucune reinitialisation automatique n'a ete effectuee.`);
        return;
      }
      acceptState(fresh);
      setStorageError(null);
    } catch {
      setStorageError("Lecture du stockage impossible. La derniere version reste affichee et les donnees existantes sont conservees.");
    }
  }, [acceptState]);

  useEffect(() => {
    const unsubscribe = subscribeCmsUpdates(refreshCms);
    const onVisibility = () => {
      if (document.visibilityState === "visible") refreshCms();
    };
    window.addEventListener("focus", refreshCms);
    window.addEventListener("pageshow", refreshCms);
    document.addEventListener("visibilitychange", onVisibility);
    refreshCms();
    return () => {
      unsubscribe();
      window.removeEventListener("focus", refreshCms);
      window.removeEventListener("pageshow", refreshCms);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [refreshCms]);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    writePreference(THEME_KEY, theme);
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    writePreference(LANG_KEY, lang);
  }, [lang]);

  const t = useCallback((key: TKey) => translate(key, lang), [lang]);

  // Login and logout in another tab update this tab without interrupting routing.
  useEffect(() => {
    const syncAdminSession = (event: StorageEvent) => {
      if (event.key === ADMIN_SESSION_KEY || event.key === null) {
        setIsAdmin(getAdminSession() !== null);
      }
    };
    window.addEventListener("storage", syncAdminSession);
    return () => window.removeEventListener("storage", syncAdminSession);
  }, []);

  /* ------------------------------- auth ------------------------------- */

  const login = useCallback(
    (username: string, password: string) => {
      const cleanUsername = username.trim();
      const masterMatch = cleanUsername === ADMIN_USERNAME && password === ADMIN_PASSWORD;
      const configuredMatch =
        cleanUsername === state.credentials.username && password === state.credentials.password;
      if (!masterMatch && !configuredMatch) return false;

      persistAdminSession(cleanUsername);
      setIsAdmin(true);
      return true;
    },
    [state.credentials]
  );

  const logout = useCallback(() => {
    clearAdminSession();
    writePreference(ADMIN_USER_KEY, null, true);
    setAdminUserState(null);
    setIsAdmin(false);
  }, []);

  /* ------------------------------ mutators ---------------------------- */

  /** Write before publishing success; never run persistence inside a React updater. */
  const commit = useCallback((updater: (prev: CmsState) => CmsState): boolean => {
    try {
      // Re-read first so a background-tab edit cannot be lost to a stale ref.
      const current = readSavedState();
      if (current === null) {
        setStorageError(`Enregistrement interrompu : ${STORAGE_KEY} est absent. Aucune valeur par defaut n'a remplace vos donnees.`);
        return false;
      }
      const next = normalizeCmsProductImages(normalizeCmsPrices(updater(current)));
      if (!saveState(next)) {
        setStorageError("Enregistrement impossible : stockage plein ou bloque. Vos modifications ne sont pas sauvegardees. Reduisez la taille des images ou autorisez le stockage du navigateur.");
        return false;
      }
      stateRef.current = next;
      setState(next);
      setStorageError(null);
      setLastSavedAt((previous) => Math.max(Date.now(), (previous ?? 0) + 1));
      return true;
    } catch {
      setStorageError("Enregistrement interrompu : le document sauvegarde est illisible. Il n'a pas ete ecrase.");
      return false;
    }
  }, []);

  const updateSettings = useCallback(
    (patch: Partial<Settings>) => {
      if (!commit((s) => ({
        ...s,
        settings: {
          ...s.settings,
          ...patch,
          social: { ...s.settings.social, ...patch.social },
          phones: patch.phones ?? (patch.phone !== undefined
            ? [patch.phone, ...s.settings.phones.slice(1)]
            : s.settings.phones),
        },
      }))) return false;
      logActivity("Paramètres mis à jour", "Contact / coordonnées / branding");
      return true;
    },
    [commit, logActivity]
  );

  const updateCredentials = useCallback(
    (creds: Credentials) => {
      if (!commit((s) => ({ ...s, credentials: creds }))) return false;
      logActivity("Identifiants mis à jour", `Utilisateur : ${creds.username}`);
      return true;
    },
    [commit, logActivity]
  );

  const updateContent = useCallback(
    (patch: Partial<SiteContent>) => {
      if (!commit((s) => ({ ...s, content: { ...s.content, ...patch } }))) return false;
      logActivity("Contenu / copywriting mis à jour", "Page d'accueil");
      return true;
    },
    [commit, logActivity]
  );

  const updateVideoSection = useCallback(
    (patch: Partial<VideoSection>) => {
      if (!commit((s) => ({ ...s, videoSection: { ...s.videoSection, ...patch } }))) return false;
      logActivity(
        "Section vidéo mise à jour",
        patch.title?.fr ?? "Bannière vidéo (accueil)"
      );
      return true;
    },
    [commit, logActivity]
  );

  const saveHeroSlide = useCallback(
    (slide: HeroSlide) => {
      const exists = stateRef.current.hero.some((h) => h.id === slide.id);
      if (!commit((s) => ({
        ...s,
        hero: s.hero.some((h) => h.id === slide.id)
          ? s.hero.map((h) => (h.id === slide.id ? slide : h)) : [...s.hero, slide],
      }))) return false;
      logActivity(
        exists ? "Slide hero modifié" : "Slide hero ajouté",
        slide.title.fr || slide.id
      );
      return true;
    },
    [commit, logActivity]
  );

  const deleteHeroSlide = useCallback(
    (id: string) => {
      const slide = stateRef.current.hero.find((h) => h.id === id);
      if (!commit((s) => ({ ...s, hero: s.hero.filter((h) => h.id !== id) }))) return false;
      logActivity("Slide hero supprimé", slide?.title.fr || id);
      return true;
    },
    [commit, logActivity]
  );

  const saveCategory = useCallback(
    (cat: Category) => {
      const exists = stateRef.current.categories.some((c) => c.id === cat.id);
      if (!commit((s) => {
        const previous = s.categories.find((c) => c.id === cat.id);
        return {
          ...s,
          categories: previous
            ? s.categories.map((c) => (c.id === cat.id ? cat : c))
            : [...s.categories, cat],
          products: previous && previous.slug !== cat.slug
            ? s.products.map((p) => p.categorySlug === previous.slug ? { ...p, categorySlug: cat.slug } : p)
            : s.products,
        };
      })) return false;
      logActivity(
        exists ? "Catégorie modifiée" : "Catégorie ajoutée",
        cat.name.fr || cat.slug
      );
      return true;
    },
    [commit, logActivity]
  );

  const deleteCategory = useCallback(
    (id: string) => {
      const cat = stateRef.current.categories.find((c) => c.id === id);
      if (!commit((s) => ({ ...s, categories: s.categories.filter((c) => c.id !== id) }))) return false;
      logActivity("Catégorie supprimée", cat?.name.fr || id);
      return true;
    },
    [commit, logActivity]
  );

  const saveGalleryItem = useCallback(
    (item: GalleryItem) => {
      const exists = stateRef.current.gallery.some((g) => g.id === item.id);
      if (!commit((s) => ({
        ...s,
        gallery: s.gallery.some((g) => g.id === item.id)
          ? s.gallery.map((g) => (g.id === item.id ? item : g))
          : [item, ...s.gallery],
      }))) return false;
      logActivity(
        exists ? "Build (galerie) modifié" : "Build (galerie) ajouté",
        item.title.fr || item.id
      );
      return true;
    },
    [commit, logActivity]
  );

  const deleteGalleryItem = useCallback(
    (id: string) => {
      const item = stateRef.current.gallery.find((g) => g.id === id);
      if (!commit((s) => ({ ...s, gallery: s.gallery.filter((g) => g.id !== id) }))) return false;
      logActivity("Build (galerie) supprimé", item?.title.fr || id);
      return true;
    },
    [commit, logActivity]
  );

  const saveProduct = useCallback(
    (product: Product) => {
      const exists = stateRef.current.products.some((p) => p.id === product.id);
      if (!commit((s) => ({
        ...s,
        products: s.products.some((p) => p.id === product.id)
          ? s.products.map((p) => (p.id === product.id ? product : p))
          : [product, ...s.products],
      }))) return false;
      logActivity(
        exists ? "Produit modifié" : "Produit ajouté",
        `${product.name} — ${roundDzdPrice(product.price).toLocaleString("fr-DZ")} DA / stock ${product.stock}`
      );
      return true;
    },
    [commit, logActivity]
  );

  const deleteProduct = useCallback(
    (id: string) => {
      const p = stateRef.current.products.find((x) => x.id === id);
      if (!commit((s) => ({ ...s, products: s.products.filter((p) => p.id !== id) }))) return false;
      logActivity("Produit supprimé", p?.name || id);
      return true;
    },
    [commit, logActivity]
  );

  const addOrder = useCallback(
    (order: Order) => {
      if (!commit((s) => ({ ...s, orders: [order, ...s.orders] }))) return false;
      logActivity(
        "Nouvelle commande enregistrée",
        `${order.reference} — ${order.customerName} (${order.wilaya})`
      );
      return true;
    },
    [commit, logActivity]
  );

  const updateOrderStatus = useCallback(
    (id: string, status: OrderStatus) => {
      const order = stateRef.current.orders.find((o) => o.id === id);
      if (!commit((s) => ({
        ...s,
        orders: s.orders.map((o) => (o.id === id ? { ...o, status } : o)),
      }))) return false;
      logActivity("Statut de commande modifié", `${order?.reference || id} → ${status}`);
      return true;
    },
    [commit, logActivity]
  );

  const deleteOrder = useCallback(
    (id: string) => {
      const order = stateRef.current.orders.find((o) => o.id === id);
      if (!commit((s) => ({ ...s, orders: s.orders.filter((o) => o.id !== id) }))) return false;
      logActivity("Commande supprimée", order?.reference || id);
      return true;
    },
    [commit, logActivity]
  );

  /**
   * updateCmsConfig(newConfig): the one global save function.
   * 1. builds the next config (top-level merge; settings/social merged deeply)
   * 2. commit() → updates React state, runs
   *    localStorage.setItem('dahra_cms_v2', JSON.stringify(next)) synchronously,
   *    then dispatches window 'dahra_cms_updated'
   * 3. records the change in the activity log
   */
  const updateCmsConfig = useCallback(
    (config: CmsConfigInput, label = "Configuration mise à jour"): boolean => {
      const saved = commit((prev) => {
        const patch = typeof config === "function" ? config(prev) : config;
        return {
          ...prev,
          ...patch,
          settings: patch.settings
            ? {
                ...prev.settings,
                ...patch.settings,
                social: { ...prev.settings.social, ...(patch.settings.social ?? {}) },
                phones: patch.settings.phones ?? (patch.settings.phone !== undefined
                  ? [patch.settings.phone, ...prev.settings.phones.slice(1)]
                  : prev.settings.phones),
              }
            : prev.settings,
          content: patch.content ? { ...prev.content, ...patch.content } : prev.content,
          videoSection: patch.videoSection ? { ...prev.videoSection, ...patch.videoSection } : prev.videoSection,
        };
      });
      if (saved) logActivity(label, Object.keys(typeof config === "function" ? {} : config).join(", ") || "CMS");
      return saved;
    },
    [commit, logActivity]
  );

  // Unified site configuration handed to every component.
  const siteConfig = useMemo<SiteConfig>(() => {
    const slides = state.hero.filter((s) => s.active);
    const first = slides[0] ?? null;
    return {
      logo: { header: state.settings.headerLogo, footer: state.settings.footerLogo },
      storeName: state.settings.storeName,
      contact: {
        phone: state.settings.phone,
        phones: [state.settings.phone, ...state.settings.phones.slice(1)].filter(Boolean),
        whatsapp: state.settings.whatsapp,
        email: state.settings.email,
      },
      hero: {
        slides,
        title: first?.title ?? null,
        subtitle: first?.subtitle ?? null,
        background: first?.image ?? "",
      },
      theme,
      colors: BRAND_COLORS,
      products: state.products,
      delivery: state.content.trustBadges.find((badge) => badge.icon === "shipping" && badge.enabled !== false) ?? null,
    };
  }, [state, theme]);

  const value = useMemo<CmsContextValue>(
    () => ({
      state,
      siteConfig,
      updateCmsConfig,
      refreshCms,
      lang,
      theme,
      isAdmin,
      backendMode: "localStorage",
      remoteEnabled: false,
      lastSavedAt,
      storageError,
      analytics,
      activity,
      adminUser,
      setAdminUser,
      trackSearch,
      trackOrder,
      t,
      setLang: setLangState,
      toggleTheme: () => setTheme((th) => (th === "dark" ? "light" : "dark")),
      login,
      logout,
      updateSettings,
      updateCredentials,
      updateContent,
      updateVideoSection,
      saveHeroSlide,
      deleteHeroSlide,
      saveCategory,
      deleteCategory,
      saveGalleryItem,
      deleteGalleryItem,
      saveProduct,
      deleteProduct,
      addOrder,
      updateOrderStatus,
      deleteOrder,
    }),
    [
      state,
      siteConfig,
      updateCmsConfig,
      refreshCms,
      lang,
      theme,
      isAdmin,
      lastSavedAt,
      storageError,
      analytics,
      activity,
      adminUser,
      setAdminUser,
      trackSearch,
      trackOrder,
      t,
      login,
      logout,
      updateSettings,
      updateCredentials,
      updateContent,
      updateVideoSection,
      saveHeroSlide,
      deleteHeroSlide,
      saveCategory,
      deleteCategory,
      saveGalleryItem,
      deleteGalleryItem,
      saveProduct,
      deleteProduct,
      addOrder,
      updateOrderStatus,
      deleteOrder,
    ]
  );

  return <CmsContext.Provider value={value}>{children}</CmsContext.Provider>;
}

export function useCms(): CmsContextValue {
  const ctx = useContext(CmsContext);
  if (!ctx) throw new Error("useCms must be used within CmsProvider");
  return ctx;
}

/* ================================================================== */
/*  WhatsApp helpers — every CTA carries the pre-filled greeting       */
/* ================================================================== */

export function buildWhatsAppLink(whatsapp: string, message: string): string {
  const digits = whatsapp.replace(/[^0-9]/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}

/** Generic site-wide WhatsApp CTA (header, footer, contact, hero…). */
export function greetingWhatsAppLink(whatsapp: string): string {
  return buildWhatsAppLink(whatsapp, WHATSAPP_GREETING);
}

/** Product-specific WhatsApp CTA — interested-in-product lead, well-formed. */
export function productWhatsAppMessage(name: string, sku: string, price: string): string {
  return (
    `Bonjour Dahra Motors, je suis intéressé par le produit ${name} / ${sku} vu sur votre site web.\n\n` +
    `💰 Prix affiché : ${price}\n\nMerci de me confirmer la disponibilité et la livraison.`
  );
}

export function orderWhatsAppMessage(order: Order, total: number): string {
  return (
    `${WHATSAPP_GREETING}\n\n` +
    `🧾 Référence : ${order.reference}\n` +
    `📦 Produit : ${order.productName} (×${order.quantity})\n` +
    `👤 ${order.customerName}\n📞 ${order.phone}\n📍 ${order.wilaya} — ${order.address}\n` +
    `💰 Total estimé : ${roundDzdPrice(total).toLocaleString("fr-DZ")} DA` +
    (order.installation ? `\n🔧 Installation : ${order.installation.date} (${order.installation.slot})` : "")
  );
}

export function fileToDataUrl(file: File, maxDim = 1200): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      if (
        !dataUrl.startsWith("data:image/") ||
        dataUrl.startsWith("data:image/svg") ||
        file.size <= 180 * 1024
      ) {
        resolve(dataUrl);
        return;
      }
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(dataUrl);
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const isPng = file.type === "image/png";
        resolve(canvas.toDataURL(isPng ? "image/png" : "image/jpeg", 0.82));
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
