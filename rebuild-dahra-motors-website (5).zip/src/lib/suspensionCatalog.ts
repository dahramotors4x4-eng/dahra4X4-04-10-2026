import type { Category, CmsState, Product, Spec } from "./types";
import { OFFICIAL_PRODUCT_MEDIA } from "./productImages";
import { roundDzdPrice } from "./pricing";

export const SUSPENSION_CATALOG_VERSION = 3;
export const SUSPENSION_CATEGORY_SLUG = "suspension";

/** Used only if an older/admin state is missing the main category entirely. */
export const SUSPENSION_CATEGORY: Category = {
  id: "cat-suspension",
  slug: SUSPENSION_CATEGORY_SLUG,
  name: { fr: "Suspension & Lift Kits", ar: "نظام التعليق ورفعات الهيكل" },
  image: OFFICIAL_PRODUCT_MEDIA.foamCellProShock,
  description: {
    fr: "Kits de suspension, Nitro Gas, Foam Cell, Foam Cell Pro, IM2.5 Monotube, amortisseurs de direction, cales et tasseaux Ironman 4x4.",
    ar: "أطقم التعليق وممتصات صدمات آيرون مان 4x4: نيترو غاز، فوم سيل، IM2.5 وملحقات التعليق.",
  },
  active: true,
};

type SuspensionFamily =
  | "nitro"
  | "foam-cell"
  | "foam-cell-pro"
  | "im25"
  | "steering"
  | "spacer"
  | "strut-top";

interface SuspensionRow {
  sku: string;
  name: string;
  nameAr: string;
  price: number;
  priceMax?: number;
  family: SuspensionFamily;
}

const ROWS: SuspensionRow[] = [
  { sku: "12648GR", name: "Amortisseur Nitro Gas 12648GR", nameAr: "ممتص صدمات نيترو غاز 12648GR", price: 20400, family: "nitro" },
  { sku: "12650GR", name: "Amortisseur Nitro Gas 12650GR", nameAr: "ممتص صدمات نيترو غاز 12650GR", price: 20400, family: "nitro" },
  { sku: "12650GRC", name: "Amortisseur Nitro Gas 12650GRC Comfort", nameAr: "ممتص صدمات نيترو غاز كومفورت 12650GRC", price: 20400, family: "nitro" },
  { sku: "12658GR", name: "Amortisseur Nitro Gas 12658GR", nameAr: "ممتص صدمات نيترو غاز 12658GR", price: 20400, family: "nitro" },
  { sku: "12661GR", name: "Amortisseur Nitro Gas 12661GR", nameAr: "ممتص صدمات نيترو غاز 12661GR", price: 20400, family: "nitro" },
  { sku: "12665GR", name: "Amortisseur Nitro Gas 12665GR", nameAr: "ممتص صدمات نيترو غاز 12665GR", price: 20400, family: "nitro" },
  { sku: "12669GR", name: "Amortisseur Nitro Gas 12669GR", nameAr: "ممتص صدمات نيترو غاز 12669GR", price: 17500, family: "nitro" },
  { sku: "12670GR", name: "Amortisseur Nitro Gas 12670GR", nameAr: "ممتص صدمات نيترو غاز 12670GR", price: 20400, family: "nitro" },
  { sku: "12682GR", name: "Amortisseur Nitro Gas 12682GR", nameAr: "ممتص صدمات نيترو غاز 12682GR", price: 17500, family: "nitro" },
  { sku: "12682GRC", name: "Amortisseur Nitro Gas 12682GRC Comfort", nameAr: "ممتص صدمات نيترو غاز كومفورت 12682GRC", price: 22900, family: "nitro" },
  { sku: "12683GR", name: "Amortisseur Nitro Gas 12683GR", nameAr: "ممتص صدمات نيترو غاز 12683GR", price: 21700, family: "nitro" },
  { sku: "12691GR", name: "Amortisseur Nitro Gas 12691GR", nameAr: "ممتص صدمات نيترو غاز 12691GR", price: 22900, family: "nitro" },
  { sku: "12696GR", name: "Amortisseur Nitro Gas 12696GR", nameAr: "ممتص صدمات نيترو غاز 12696GR", price: 33300, family: "nitro" },
  { sku: "12697GR", name: "Amortisseur Nitro Gas 12697GR", nameAr: "ممتص صدمات نيترو غاز 12697GR", price: 20400, family: "nitro" },
  { sku: "12698GRC", name: "Amortisseur Nitro Gas 12698GRC Comfort", nameAr: "ممتص صدمات نيترو غاز كومفورت 12698GRC", price: 20400, family: "nitro" },
  { sku: "12710GR - 12715GR", name: "Amortisseurs Nitro Gas Series 12710GR-12715GR", nameAr: "سلسلة ممتصات نيترو غاز 12710GR-12715GR", price: 20400, priceMax: 33300, family: "nitro" },
  { sku: "12759GR", name: "Amortisseur Nitro Gas 12759GR", nameAr: "ممتص صدمات نيترو غاز 12759GR", price: 24500, family: "nitro" },
  { sku: "12760GR", name: "Amortisseur Nitro Gas 12760GR", nameAr: "ممتص صدمات نيترو غاز 12760GR", price: 24500, family: "nitro" },
  { sku: "12764GR_LH", name: "Amortisseur Nitro Gas 12764GR_LH", nameAr: "ممتص صدمات نيترو غاز يسار 12764GR_LH", price: 31200, family: "nitro" },
  { sku: "12764GR_RH", name: "Amortisseur Nitro Gas 12764GR_RH", nameAr: "ممتص صدمات نيترو غاز يمين 12764GR_RH", price: 31200, family: "nitro" },
  { sku: "12851GR / 12851GRC / 12851LGR", name: "Amortisseur Nitro Gas Series 12851", nameAr: "سلسلة ممتصات نيترو غاز 12851", price: 24500, priceMax: 25800, family: "nitro" },
  { sku: "24080FE / 24081FE / 24087FE", name: "Amortisseur Foam Cell Series", nameAr: "سلسلة ممتصات فوم سيل", price: 29500, priceMax: 34400, family: "foam-cell" },
  { sku: "24713FE - 24796FE", name: "Amortisseurs Foam Cell Heavy Duty 247xx", nameAr: "ممتصات فوم سيل للخدمة الشاقة 247xx", price: 34400, priceMax: 48100, family: "foam-cell" },
  { sku: "45094FE - 45796FE", name: "Amortisseurs Foam Cell Pro 45xxx", nameAr: "ممتصات فوم سيل برو 45xxx", price: 47200, priceMax: 76900, family: "foam-cell-pro" },
  { sku: "71-057-730 / 72-057-682 / 73-057-081", name: "Amortisseurs IM2.5 Monotube 2.5", nameAr: "ممتصات IM2.5 أحادية الأنبوب 2.5", price: 77300, priceMax: 154700, family: "im25" },
  { sku: "3501 - 3544", name: "Amortisseurs de Direction Ironman 4x4", nameAr: "ممتصات التوجيه آيرون مان 4x4", price: 29500, priceMax: 38100, family: "steering" },
  { sku: "HILFR05 / HILFR10 / HILFR15", name: "Cale d'Amortisseur Hilux", nameAr: "حلقة ضبط ممتص صدمات هيلوكس", price: 5000, priceMax: 5200, family: "spacer" },
  { sku: "ISST001 - ISST090", name: "Tasseau d'Amortisseur Ironman 4x4", nameAr: "قاعدة ممتص صدمات آيرون مان 4x4", price: 12900, priceMax: 25200, family: "strut-top" },
];

const familyConfig: Record<
  SuspensionFamily,
  { image: string; description: string; features: string[]; specs: Spec[] }
> = {
  nitro: {
    image: OFFICIAL_PRODUCT_MEDIA.nitroGas,
    description: "Amortisseur Ironman 4x4 Nitro Gas à azote basse pression, conçu pour améliorer le contrôle, la stabilité et le confort sur route et en tout-terrain.",
    features: ["Charge d'azote basse pression", "Corps twin-tube", "Tarage spécifique au véhicule", "Tige chromée renforcée"],
    specs: [{ label: "Technologie", value: "Nitro Gas twin-tube" }, { label: "Conditionnement", value: "À l'unité / selon référence" }],
  },
  "foam-cell": {
    image: OFFICIAL_PRODUCT_MEDIA.foamCell,
    description: "Amortisseur Foam Cell Ironman 4x4 à grand volume d'huile, destiné au touring, aux charges soutenues et aux conditions exigeantes.",
    features: ["Technologie Foam Cell", "Corps acier twin-wall", "Refroidissement optimisé", "Tarage spécifique au véhicule"],
    specs: [{ label: "Technologie", value: "Foam Cell" }, { label: "Construction", value: "Twin-wall acier" }],
  },
  "foam-cell-pro": {
    image: OFFICIAL_PRODUCT_MEDIA.foamCellProShock,
    description: "Amortisseur Foam Cell Pro Ironman 4x4 surdimensionné, conçu pour le contrôle des charges lourdes, les longues distances et les pistes sévères.",
    features: ["Corps Foam Cell Pro surdimensionné", "Grand volume d'huile", "Contrôle thermique renforcé", "Construction heavy duty"],
    specs: [{ label: "Technologie", value: "Foam Cell Pro" }, { label: "Usage", value: "Touring / Heavy Duty" }],
  },
  im25: {
    image: OFFICIAL_PRODUCT_MEDIA.im25Monotube,
    description: "Amortisseur IM2.5 Monotube Ironman 4x4 en aluminium 6061-T6, avec piston billet 57 mm et tarage de précision.",
    features: ["Monotube aluminium 2.5 pouces", "Piston billet 57 mm", "Dissipation thermique avancée", "Tarage sensible à la vitesse"],
    specs: [{ label: "Technologie", value: "IM2.5 Monotube" }, { label: "Matériau", value: "Aluminium 6061-T6" }],
  },
  steering: {
    image: OFFICIAL_PRODUCT_MEDIA.steeringDamper,
    description: "Amortisseur de direction Ironman 4x4 conçu pour stabiliser la direction et réduire les réactions du volant sur les terrains irréguliers.",
    features: ["Piston 35 mm", "Contrôle directionnel amélioré", "Réduction des chocs au volant", "Kit de fixation selon application"],
    specs: [{ label: "Type", value: "Amortisseur de direction" }, { label: "Piston", value: "35 mm" }],
  },
  spacer: {
    image: OFFICIAL_PRODUCT_MEDIA.trimPacker,
    description: "Cale de réglage Ironman 4x4 pour ajuster précisément la hauteur d'assiette des combinés avant Hilux.",
    features: ["Réglage précis d'assiette", "Acier usiné", "Montage sur amortisseur compatible", "Sélection selon épaisseur"],
    specs: [{ label: "Type", value: "Cale / trim packer" }, { label: "Application", value: "Toyota Hilux" }],
  },
  "strut-top": {
    image: OFFICIAL_PRODUCT_MEDIA.strutTop,
    description: "Tasseau et support supérieur d'amortisseur Ironman 4x4 avec silentblocs et composants de montage renforcés.",
    features: ["Remplacement direct OEM", "Silentblocs caoutchouc renforcés", "Rondelles heavy duty", "Écrous autobloquants"],
    specs: [{ label: "Type", value: "Tasseau / strut top" }, { label: "Montage", value: "Selon référence véhicule" }],
  },
};

function productId(sku: string): string {
  return `p-shock-${sku.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "")}`;
}

export const AMORTISSEUR_PRODUCTS: Product[] = ROWS.map((row) => {
  const config = familyConfig[row.family];
  return {
    id: productId(row.sku),
    sku: row.sku,
    name: row.name,
    nameAr: row.nameAr,
    categorySlug: SUSPENSION_CATEGORY_SLUG,
    price: roundDzdPrice(row.price),
    priceMax: row.priceMax === undefined ? null : roundDzdPrice(row.priceMax),
    oldPrice: null,
    stock: 1,
    badge: "IRONMAN 4X4",
    image: config.image,
    images: [],
    shortDescription: `${config.description} Réf. ${row.sku}.`,
    problem: "Un amortissement usé ou inadapté réduit la stabilité, le contrôle et le confort du 4x4, surtout en charge et sur piste.",
    solution: "Une technologie Ironman 4x4 adaptée à l'application du véhicule, sélectionnée selon la référence constructeur.",
    features: config.features,
    specs: [{ label: "Référence", value: row.sku }, ...config.specs],
    fitment: ["Compatibilité véhicule à confirmer selon la référence Ironman 4x4"],
    warranty: "",
    active: true,
    featured: true,
    showLowStockBadge: false,
    showDiscountBadge: false,
  };
});

const LEGACY_SUSPENSION_SLUGS = new Set([
  "amortisseurs",
  "shock-absorbers",
  "shocks",
  "suspension-kits",
]);

function isShockOrSuspensionComponent(product: Product): boolean {
  if (LEGACY_SUSPENSION_SLUGS.has(product.categorySlug)) return true;
  const sku = product.sku.toUpperCase();
  const text = `${product.name} ${product.shortDescription}`.toLowerCase();
  return /^(?:12\d{3}(?:L?GR|GRC)|127\d{2}GR|12851|240\d{2}FE|247\d{2}FE|45\d{3}FE|(?:71|72|73)-057-|35\d{2}|HILFR|ISST|IFCP)/.test(sku) ||
    /amortisseur|shock absorber|foam cell|nitro gas|im2\.5|steering damper|cale d'amortisseur|tasseau d'amortisseur/.test(text);
}

/** Append missing catalog rows and consolidate all shocks under the main node. */
export function mergeSuspensionCatalog(state: CmsState): CmsState {
  if ((state.suspensionCatalogVersion ?? 0) >= SUSPENSION_CATALOG_VERSION) return state;
  const catalogBySku = new Map(
    AMORTISSEUR_PRODUCTS.map((product) => [product.sku.trim().toUpperCase(), product])
  );
  // This requested revision updates only the supplied Amortisseurs price fields;
  // product copy, stock, visibility and admin images remain untouched.
  const updatedProducts = state.products.map((product) => {
    const catalog = catalogBySku.get(product.sku.trim().toUpperCase());
    return catalog
      ? {
          ...product,
          categorySlug: SUSPENSION_CATEGORY_SLUG,
          price: catalog.price,
          priceMax: catalog.priceMax,
          oldPrice: null,
        }
      : isShockOrSuspensionComponent(product)
        ? { ...product, categorySlug: SUSPENSION_CATEGORY_SLUG }
        : product;
  });
  const existing = new Set(state.products.map((product) => product.sku.trim().toUpperCase()));
  const additions = AMORTISSEUR_PRODUCTS.filter(
    (product) => !existing.has(product.sku.trim().toUpperCase())
  );
  const cleanedCategories = state.categories.filter(
    (category) =>
      category.id !== "cat-amortisseurs" &&
      !LEGACY_SUSPENSION_SLUGS.has(category.slug)
  );
  const hasCategory = cleanedCategories.some(
    (category) => category.slug === SUSPENSION_CATEGORY_SLUG
  );
  return {
    ...state,
    products: [...updatedProducts, ...additions],
    categories: hasCategory
      ? cleanedCategories
      : [SUSPENSION_CATEGORY, ...cleanedCategories],
    suspensionCatalogVersion: SUSPENSION_CATALOG_VERSION,
  };
}