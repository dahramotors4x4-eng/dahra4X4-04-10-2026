/** Complete shared vehicle roster for Fit My 4x4 and the suspension calculator. */
export interface VehicleModel {
  name: string;
  years: number[];
  /** Generation-specific names/codes found in Ironman product fitments. */
  aliases: string[];
  /** Generic family wording used when a product fits multiple generations. */
  familyAliases: string[];
  family: string;
  /** Generic selector entries, e.g. Hilux (All Models), accept explicit siblings. */
  acceptsFamilyVariants?: boolean;
}

export interface VehicleBrand {
  brand: string;
  aliases: string[];
  models: VehicleModel[];
}

export interface VehicleSelection {
  brand: string;
  model: string;
  year?: string | number;
}

export function vehicleYears(from: number, to = 2026): number[] {
  const years: number[] = [];
  for (let year = to; year >= from; year--) years.push(year);
  return years;
}

const model = (
  name: string,
  from: number,
  to: number,
  family: string,
  aliases: string[],
  familyAliases: string[],
  acceptsFamilyVariants = false
): VehicleModel => ({
  name,
  years: vehicleYears(from, to),
  aliases,
  familyAliases,
  family,
  acceptsFamilyVariants,
});

export const VEHICLE_DATABASE: VehicleBrand[] = [
  {
    brand: "Toyota",
    aliases: ["toyota"],
    models: [
      model("Hilux (All Models)", 1984, 2026, "hilux", [], ["hilux", "toyota hilux"], true),
      model("Hilux Vigo", 2005, 2015, "hilux", ["hilux vigo", "vigo", "hilux n70", "n70"], ["hilux", "toyota hilux"]),
      model("Hilux Vigo Champ", 2011, 2015, "hilux", ["hilux vigo champ", "vigo champ"], ["hilux", "toyota hilux"]),
      model("Hilux Revo", 2015, 2026, "hilux", ["hilux revo", "revo", "hilux an120", "hilux an130"], ["hilux", "toyota hilux"]),
      model("Hilux Revo Rocco", 2018, 2026, "hilux", ["hilux revo rocco", "revo rocco", "hilux rocco", "rocco"], ["hilux", "toyota hilux"]),
      model("Land Cruiser Series 70", 1984, 2026, "land-cruiser", ["land cruiser 70", "70 series", "series 70", "lc 70", "lc70", "lc 71", "lc 75", "lc 76", "lc 78", "lc 79"], ["land cruiser", "toyota land cruiser", "lc"]),
      model("Land Cruiser Series 80", 1990, 1997, "land-cruiser", ["land cruiser 80", "80 series", "series 80", "lc 80", "lc80"], ["land cruiser", "toyota land cruiser", "lc"]),
      model("Land Cruiser Series 100", 1998, 2007, "land-cruiser", ["land cruiser 100", "100 series", "series 100", "lc 100", "lc100"], ["land cruiser", "toyota land cruiser", "lc"]),
      model("Land Cruiser Series 200", 2007, 2021, "land-cruiser", ["land cruiser 200", "200 series", "series 200", "lc 200", "lc200"], ["land cruiser", "toyota land cruiser", "lc"]),
      model("Land Cruiser Series 300", 2021, 2026, "land-cruiser", ["land cruiser 300", "300 series", "series 300", "lc 300", "lc300"], ["land cruiser", "toyota land cruiser", "lc"]),
      model("Land Cruiser Prado 120", 2002, 2009, "prado", ["prado 120", "land cruiser prado 120", "lc prado 120"], ["prado", "land cruiser prado"]),
      model("Land Cruiser Prado 150", 2009, 2024, "prado", ["prado 150", "land cruiser prado 150", "lc prado 150"], ["prado", "land cruiser prado"]),
      model("Land Cruiser Prado 250", 2024, 2026, "prado", ["prado 250", "land cruiser prado 250", "lc prado 250"], ["prado", "land cruiser prado"]),
      model("FJ Cruiser", 2006, 2023, "fj-cruiser", ["fj cruiser", "fjcruiser"], ["fj"]),
      model("Fortuner", 2004, 2026, "fortuner", ["fortuner"], ["toyota fortuner"]),
    ],
  },
  {
    brand: "Jeep",
    aliases: ["jeep"],
    models: [
      model("Wrangler JK", 2007, 2018, "wrangler", ["wrangler jk", "jeep jk"], ["wrangler", "jeep wrangler"]),
      model("Wrangler JL", 2018, 2026, "wrangler", ["wrangler jl", "jeep jl"], ["wrangler", "jeep wrangler"]),
      model("Gladiator JT", 2020, 2026, "gladiator", ["gladiator", "gladiator jt", "jeep jt"], ["jeep gladiator"]),
      model("Cherokee", 1984, 2023, "cherokee", ["cherokee", "cherokee xj", "cherokee kl"], ["jeep cherokee"]),
    ],
  },
  {
    brand: "Nissan",
    aliases: ["nissan"],
    models: [
      model("Patrol Y60", 1987, 1997, "patrol", ["patrol y60", "patrol gq", "y60"], ["patrol", "nissan patrol"]),
      model("Patrol Y61", 1997, 2016, "patrol", ["patrol y61", "patrol gu", "y61"], ["patrol", "nissan patrol"]),
      model("Patrol Y62", 2010, 2026, "patrol", ["patrol y62", "y62"], ["patrol", "nissan patrol"]),
      model("Navara D22", 1997, 2015, "navara", ["navara d22", "d22"], ["navara", "nissan navara"]),
      model("Navara D40", 2005, 2015, "navara", ["navara d40", "pathfinder r51", "d40"], ["navara", "nissan navara", "pathfinder"]),
      model("Navara NP300 / D23", 2015, 2026, "navara", ["navara np300", "np300", "navara d23", "d23", "alaskan"], ["navara", "nissan navara"]),
      model("X-Trail", 2001, 2026, "x-trail", ["x trail", "xtrail"], ["nissan x trail"]),
    ],
  },
  {
    brand: "Isuzu",
    aliases: ["isuzu"],
    models: [
      model("D-Max", 2002, 2026, "d-max", ["d max", "dmax"], ["isuzu d max"]),
      model("MU-X", 2013, 2026, "mu-x", ["mu x", "mux"], ["isuzu mu x"]),
    ],
  },
  {
    brand: "Mitsubishi",
    aliases: ["mitsubishi", "mits"],
    models: [
      model("L200 Triton", 2005, 2026, "l200", ["l200 triton", "triton"], ["l200", "mits l200", "mitsubishi l200"]),
      model("L200 Sportero", 2005, 2015, "l200", ["l200 sportero", "sportero"], ["l200", "mits l200", "mitsubishi l200"]),
      model("Pajero V60", 1999, 2006, "pajero", ["pajero v60", "v60", "pajero nm", "pajero np"], ["pajero", "mitsubishi pajero"]),
      model("Pajero V80", 2006, 2021, "pajero", ["pajero v80", "v80", "pajero ns", "pajero nt", "pajero nx"], ["pajero", "mitsubishi pajero"]),
      model("Pajero Sport", 1996, 2026, "pajero-sport", ["pajero sport", "montero sport", "challenger"], ["mitsubishi pajero sport"]),
    ],
  },
  {
    brand: "Ford",
    aliases: ["ford"],
    models: [
      model("Ranger PX", 2011, 2022, "ranger", ["ranger px", "px ranger", "ranger t6", "ranger t7"], ["ranger", "ford ranger"]),
      model("Ranger T6 / T7", 2011, 2022, "ranger", ["ranger t6", "ranger t7", "t6 ranger", "t7 ranger"], ["ranger", "ford ranger"]),
      model("Ranger Next-Gen", 2022, 2026, "ranger", ["ranger next gen", "next gen ranger", "ranger p703"], ["ranger", "ford ranger"]),
      model("Ranger Raptor", 2018, 2026, "ranger-raptor", ["ranger raptor", "ford raptor", "raptor"], ["ford ranger"]),
      model("Everest", 2003, 2026, "everest", ["everest", "endeavour"], ["ford everest"]),
    ],
  },
  {
    brand: "Suzuki",
    aliases: ["suzuki"],
    models: [
      model("Jimny", 1998, 2026, "jimny", ["jimny", "jimny jb43", "jimny jb74"], ["suzuki jimny"]),
      model("Vitara", 1988, 2026, "vitara", ["vitara", "grand vitara"], ["suzuki vitara"]),
    ],
  },
  {
    brand: "Land Rover",
    aliases: ["land rover", "lr"],
    models: [
      model("Defender", 1983, 2026, "defender", ["defender", "defender 90", "defender 110", "defender 130"], ["land rover defender"]),
      model("Discovery", 1989, 2026, "discovery", ["discovery", "discovery 1", "discovery 2", "discovery 3", "discovery 4"], ["land rover discovery"]),
    ],
  },
  {
    brand: "Mercedes-Benz",
    aliases: ["mercedes benz", "mercedes"],
    models: [
      model("G-Class", 1979, 2026, "g-class", ["g class", "g-class", "gelandewagen"], ["mercedes g class"]),
      model("X-Class", 2017, 2020, "x-class", ["x class", "x-class"], ["mercedes x class"]),
    ],
  },
  {
    brand: "Volkswagen",
    aliases: ["volkswagen", "vw"],
    models: [
      model("Amarok", 2010, 2026, "amarok", ["amarok"], ["volkswagen amarok", "vw amarok"]),
    ],
  },
  {
    brand: "SsangYong",
    aliases: ["ssangyong", "ssang yong"],
    models: [
      model("Musso", 1993, 2026, "musso", ["musso"], ["ssangyong musso"]),
      model("Rexton", 2001, 2026, "rexton", ["rexton"], ["ssangyong rexton"]),
      model("Korando", 1996, 2026, "korando", ["korando"], ["ssangyong korando"]),
    ],
  },
  {
    brand: "Mazda",
    aliases: ["mazda"],
    models: [
      model("BT-50", 2006, 2026, "bt-50", ["bt 50", "bt50"], ["mazda bt 50"]),
      model("B-Series", 1985, 2011, "b-series", ["b series", "bravo"], ["mazda b series"]),
    ],
  },
  {
    brand: "Great Wall",
    aliases: ["great wall", "gwm"],
    models: [
      model("Wingle", 2006, 2026, "wingle", ["wingle", "wingle 5", "wingle 7"], ["great wall wingle"]),
      model("Poer / Cannon", 2019, 2026, "poer", ["poer", "cannon", "p series"], ["great wall poer", "gwm cannon"]),
      model("Steed", 2006, 2021, "steed", ["steed"], ["great wall steed"]),
    ],
  },
  {
    brand: "Haval",
    aliases: ["haval"],
    models: [
      model("H5", 2010, 2020, "h5", ["haval h5", "hover h5"], ["h5"]),
      model("H9", 2015, 2026, "h9", ["haval h9"], ["h9"]),
    ],
  },
  {
    brand: "Hyundai",
    aliases: ["hyundai"],
    models: [
      model("Terracan", 2001, 2007, "terracan", ["terracan"], ["hyundai terracan"]),
      model("Santa Fe", 2000, 2026, "santa-fe", ["santa fe"], ["hyundai santa fe"]),
      model("Tucson", 2004, 2026, "tucson", ["tucson"], ["hyundai tucson"]),
      model("Palisade", 2018, 2026, "palisade", ["palisade"], ["hyundai palisade"]),
    ],
  },
  {
    brand: "JMC",
    aliases: ["jmc"],
    models: [
      model("Vigus", 2012, 2026, "vigus", ["vigus"], ["jmc vigus"]),
      model("Yuhu", 2012, 2026, "yuhu", ["yuhu"], ["jmc yuhu"]),
      model("Grand Avenue", 2023, 2026, "grand-avenue", ["grand avenue"], ["jmc grand avenue"]),
    ],
  },
  {
    brand: "LDV",
    aliases: ["ldv", "maxus"],
    models: [
      model("T60", 2017, 2026, "t60", ["t60"], ["ldv t60", "maxus t60"]),
      model("D90", 2017, 2026, "d90", ["d90"], ["ldv d90", "maxus d90"]),
    ],
  },
  {
    brand: "Mahindra",
    aliases: ["mahindra"],
    models: [
      model("Scorpio", 2002, 2026, "scorpio", ["scorpio", "scorpio n"], ["mahindra scorpio"]),
      model("Pik Up", 2007, 2026, "pik-up", ["pik up", "pickup"], ["mahindra pik up"]),
      model("Thar", 2010, 2026, "thar", ["thar"], ["mahindra thar"]),
    ],
  },
  /* Additional fitments referenced by the seeded Ironman catalog. */
  {
    brand: "Renault",
    aliases: ["renault"],
    models: [model("Alaskan", 2017, 2026, "navara", ["alaskan"], ["renault alaskan"])],
  },
  {
    brand: "Fiat",
    aliases: ["fiat"],
    models: [model("Fullback", 2016, 2019, "l200", ["fullback", "full back"], ["fiat fullback"])],
  },
];

export function findVehicleModel(brand: string, name: string): VehicleModel | undefined {
  return VEHICLE_DATABASE.find((entry) => entry.brand === brand)?.models.find(
    (entry) => entry.name === name
  );
}

function normalize(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function containsTerm(text: string, term: string): boolean {
  const normalized = normalize(term);
  return normalized.length > 0 && ` ${text} `.includes(` ${normalized} `);
}

function isUniversalFitment(text: string): boolean {
  return [
    "universel",
    "universal",
    "pickup suv 4x4",
    "pickup and suv 4x4",
    "systeme electrique double 12v",
    "12v 24v vehicule ou secteur",
    "caisse ou soubassement",
    "galerie de toit 4 barres",
    "galerie de toit ou rail dedie",
    "compatible reservoirs iwt",
    "amortisseurs renforces requis",
  ].some((term) => containsTerm(text, term));
}

function matchesYear(text: string, yearValue?: string | number): boolean {
  if (!yearValue) return true;
  const selected = Number(yearValue);
  if (!Number.isFinite(selected)) return true;

  const found = [...text.matchAll(/\b(?:19|20)\d{2}\b/g)].map((item) => Number(item[0]));
  if (found.length === 0) return true;
  if (found.includes(selected)) return true;
  if (found.length === 1) {
    return /(?:19|20)\d{2}\s*\+/.test(text) ? selected >= found[0] : selected === found[0];
  }
  return selected >= Math.min(...found) && selected <= Math.max(...found);
}

/**
 * Matches Ironman fitment strings against a selected vehicle.
 *
 * It supports generation aliases (D23 / NP300, LC 76/78/79, Ranger T7),
 * abbreviated brands (MITS / VW), multi-vehicle rows, generic model families,
 * year ranges written as 2005-2015 or 2005/2015, and universal accessories.
 */
export function matchesVehicleFitment(
  fitments: string[],
  selection: VehicleSelection
): boolean {
  if (!selection.brand && !selection.model && !selection.year) return true;
  const brand = VEHICLE_DATABASE.find((entry) => entry.brand === selection.brand);
  const selectedModel = brand?.models.find((entry) => entry.name === selection.model);
  if (!brand) return false;

  // Brand-only searches remain useful: include rows naming this brand/model
  // family plus all universal recovery, winch, camping and overland equipment.
  if (!selectedModel) {
    return fitments.some((raw) => {
      const text = normalize(raw);
      if (!text) return false;
      if (isUniversalFitment(text)) return true;
      const namesBrand = brand.aliases.some((alias) => containsTerm(text, alias));
      const namesBrandModel = brand.models.some((entry) =>
        [...entry.aliases, ...entry.familyAliases].some((alias) =>
          containsTerm(text, alias)
        )
      );
      return (namesBrand || namesBrandModel) && matchesYear(raw, selection.year);
    });
  }

  return fitments.some((raw) => {
    const text = normalize(raw);
    if (!text) return false;
    if (isUniversalFitment(text)) return true;

    // Find generation-specific aliases in this product row. A shorter alias
    // nested inside a longer one is removed (Vigo does not steal Vigo Champ),
    // while independent multi-fitment entries remain valid (JL + Gladiator).
    const explicit = brand.models.flatMap((entry) =>
      entry.aliases
        .filter((alias) => containsTerm(text, alias))
        .map((alias) => ({ entry, alias: normalize(alias) }))
    );
    const specific = explicit.filter(
      (candidate) =>
        !explicit.some(
          (other) =>
            other.entry.name !== candidate.entry.name &&
            other.alias !== candidate.alias &&
            containsTerm(other.alias, candidate.alias)
        )
    );

    const selectedSpecific = specific.some(
      (match) => match.entry.name === selectedModel.name
    );
    let modelMatches = false;
    if (specific.length > 0) {
      modelMatches = selectedModel.acceptsFamilyVariants
        ? specific.some((match) => match.entry.family === selectedModel.family)
        : specific.some((match) => match.entry.name === selectedModel.name);
    } else {
      modelMatches = selectedModel.familyAliases.some((alias) => containsTerm(text, alias));
    }
    if (!modelMatches) return false;

    // If the row names brands, at least one must be the selected brand. Rows
    // such as LC 76/78/79 omit Toyota, so no explicit brand remains valid.
    const presentBrands = VEHICLE_DATABASE.filter((entry) =>
      entry.aliases.some((alias) => containsTerm(text, alias))
    );
    if (
      presentBrands.length > 0 &&
      !selectedSpecific &&
      !presentBrands.some((entry) => entry.brand === brand.brand)
    ) {
      return false;
    }

    return matchesYear(raw, selection.year);
  });
}