import { Link } from "react-router-dom";
import { ShieldCheck, Target, ArrowRight, MessageCircle } from "lucide-react";
import { useCms, greetingWhatsAppLink } from "../lib/store";
import { loc } from "../lib/i18n";
import { Reveal } from "../components/bits";

export default function About() {
  const { state, lang, t } = useCms();
  const { content, settings } = state;

  return (
    <div>
      <section className="border-b border-line bg-bg-alt py-12">
        <div className="mx-auto max-w-7xl px-4 text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded border border-brand/50 bg-brand/10 px-4 py-1.5">
            <ShieldCheck size={15} className="text-brand" />
            <span className="font-display text-xs font-bold uppercase tracking-[0.22em] text-brand">
              {t("about.officialRep")}
            </span>
          </div>
          <h1 className="font-display text-4xl font-extrabold uppercase tracking-wide text-ink sm:text-5xl">
            {loc(content.aboutTitle, lang)}
          </h1>
        </div>
      </section>

      <section className="bg-bg py-14">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 lg:grid-cols-2">
          <Reveal>
            <div className="relative">
              <div className="aspect-[4/3] overflow-hidden rounded-xl border border-line">
                <img src={content.aboutImage} alt={loc(content.aboutTitle, lang)} className="h-full w-full object-cover" />
              </div>
              <div className="absolute -bottom-5 start-6 rounded-lg bg-brand px-5 py-3 shadow-xl">
                <p className="font-display text-lg font-extrabold uppercase tracking-wide text-black">
                  {settings.storeName}
                </p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <div className="flex items-center gap-2.5">
              <Target size={20} className="text-brand" />
              <h2 className="font-display text-2xl font-extrabold uppercase tracking-wide text-ink">
                {t("about.mission")}
              </h2>
            </div>
            <p className="mt-4 text-base leading-relaxed text-muted">{t("about.missionText")}</p>
            <p className="mt-4 text-base leading-relaxed text-muted">
              {loc(content.aboutText, lang)}
            </p>
            <p className="mt-3 text-base leading-relaxed text-muted">
              {loc(content.aboutText2, lang)}
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link
                to="/shop"
                className="inline-flex items-center gap-2 rounded bg-brand px-6 py-3 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong"
              >
                {t("nav.shop")} <ArrowRight size={16} className="rtl:rotate-180" />
              </Link>
              <a
                href={greetingWhatsAppLink(settings.whatsapp)}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded border-2 border-ink px-6 py-3 font-display text-sm font-bold uppercase tracking-wider text-ink transition-all hover:border-brand hover:bg-brand hover:text-black"
              >
                <MessageCircle size={16} /> {settings.phone}
              </a>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-onyx py-12">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-4 lg:grid-cols-4">
          {content.stats.map((s, i) => (
            <Reveal key={i} delay={i * 0.07} className="text-center">
              <p className="font-display text-4xl font-extrabold text-brand sm:text-5xl">{s.value}</p>
              <p className="mt-1 text-xs uppercase tracking-widest text-slate-400">
                {loc(s.label, lang)}
              </p>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}
