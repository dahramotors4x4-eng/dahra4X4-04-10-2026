import { Fragment, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Tags,
  Camera,
  Images,
  Video,
  FileText,
  Phone,
  Lock,
  LogOut,
  ExternalLink,
  Plus,
  Pencil,
  Trash2,
  Upload,
  Check,
} from "lucide-react";
import { useCms, fileToDataUrl } from "../lib/store";
import { ADMIN_USERNAME, ANNOUNCEMENT, STORAGE_KEY } from "../lib/data";
import LogoMark from "../components/LogoMark";
import type { Category, GalleryItem, HeroSlide, Order, OrderStatus, Product, SiteContent, TrustBadgeIcon } from "../lib/types";
import { loc } from "../lib/i18n";
import { productImageSources } from "../lib/productImages";
import SafeImage from "../components/SafeImage";
import { roundDzdPrice } from "../lib/pricing";

const inputCls =
  "w-full rounded border border-line bg-surface px-3 py-2 text-sm text-ink placeholder:text-muted/50 focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30";
const labelCls = "mb-1 block text-xs font-bold uppercase tracking-wider text-muted";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className={labelCls}>{label}</span>
      {children}
    </label>
  );
}

function ImageInput({ value, onChange, label = "Image" }: { value: string; onChange: (v: string) => void; label?: string }) {
  return (
    <div>
      <span className={labelCls}>{label}</span>
      <div className="flex items-center gap-3">
        {value ? (
          <img src={value} alt="" className="h-12 w-16 rounded border border-line object-cover" />
        ) : (
          <div className="flex h-12 w-16 items-center justify-center rounded border border-dashed border-line text-muted">
            <Upload size={14} />
          </div>
        )}
        <div className="min-w-0 flex-1">
          <input
            className={inputCls}
            value={value.startsWith("data:") ? "(image téléversée)" : value}
            placeholder="https://… ou /images/…"
            onChange={(e) => onChange(e.target.value)}
          />
          <label className="mt-1.5 inline-block cursor-pointer rounded border border-line px-2.5 py-1 text-xs font-semibold text-ink hover:border-brand hover:text-brand">
            <Upload size={11} className="mr-1 inline" />
            {loc({ fr: "Téléverser", ar: "تحميل" }, "fr")}
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (f) onChange(await fileToDataUrl(f));
              }}
            />
          </label>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Login                                                              */
/* ================================================================== */

function Login() {
  const { login, t } = useCms();
  // Prefill the owner username so only the case-sensitive password is required.
  const [username, setUsername] = useState(ADMIN_USERNAME);
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-onyx px-4 py-12">
      {/* Workshop backdrop — keeps the gate on-brand without competing with the form */}
      <div
        className="pointer-events-none absolute inset-0 opacity-20"
        style={{
          backgroundImage:
            "url(https://images.pexels.com/photos/38263042/pexels-photo-38263042.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200)",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-onyx/70 via-onyx/85 to-onyx" />

      <div className="relative w-full max-w-md">
        <div className="rounded-xl border border-white/10 bg-surface p-7 shadow-2xl sm:p-8">
          {/* Brand block — transparent graphic logo, no bounding box */}
          <div className="mb-6 flex flex-col items-center text-center">
            <LogoMark className="h-11 text-ink" />
            <h1 className="font-display mt-4 text-2xl font-extrabold uppercase tracking-wide text-ink">
              Dahra Motors — Admin
            </h1>
            <p className="mt-1 text-xs font-semibold uppercase tracking-[0.22em] text-brand">
              Espace de gestion du site
            </p>
            <p className="mt-3 text-xs uppercase tracking-widest text-muted">
              {ANNOUNCEMENT.split("—")[0].trim()}
            </p>
          </div>

          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              if (login(username, password)) {
                setError(false);
                setPassword("");
                return;
              }
              setError(true);
            }}
          >
            <Field label={t("admin.username")}>
              <input
                className={inputCls}
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                  setError(false);
                }}
                autoComplete="username"
                autoCapitalize="none"
                spellCheck={false}
              />
            </Field>
            <Field label={t("admin.password")}>
              <input
                type="password"
                className={inputCls}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError(false);
                }}
                autoComplete="current-password"
                autoFocus
              />
            </Field>
            {error && (
              <div
                role="alert"
                aria-live="assertive"
                className="rounded border border-red-400/40 bg-red-500/10 px-3 py-2 text-sm font-semibold text-red-500"
              >
                Nom d'utilisateur ou mot de passe incorrect. Vérifiez les majuscules et réessayez.
              </div>
            )}
            <button
              type="submit"
              className="w-full rounded bg-brand px-4 py-3 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong hover:shadow-lg hover:shadow-brand/30"
            >
              {t("admin.signIn")}
            </button>
          </form>

          <p className="mt-4 border-t border-line pt-4 text-center text-xs text-muted">
            Accès direct au tableau de bord — aucune sélection de profil requise.
          </p>

          <p className="mt-4 rounded border border-line bg-bg-alt px-3 py-2 text-center text-xs text-muted">
            <Lock size={12} className="mr-1 inline align-[-1px] text-brand" />
            Session sécurisée et persistante sur cet appareil.
          </p>
        </div>

        <Link
          to="/"
          className="mt-4 block text-center text-sm text-slate-400 transition-colors hover:text-brand"
        >
          ← {t("admin.backToSite")}
        </Link>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Tab: dashboard stats                                               */
/* ================================================================== */

function TabDashboard() {
  const { state, analytics, activity, t } = useCms();
  const revenue = state.orders
    .filter((o) => o.status !== "cancelled")
    .reduce((s, o) => s + o.unitPrice * o.quantity, 0);
  const stats = [
    { label: t("admin.statsProducts"), value: state.products.length },
    { label: t("admin.statsOrders"), value: state.orders.length },
    { label: t("admin.statsRevenue"), value: `${roundDzdPrice(revenue).toLocaleString("fr-DZ")} DA` },
    { label: t("admin.statsCategories"), value: state.categories.length },
    { label: "Visites", value: analytics.visits },
    { label: "Recherches", value: analytics.searches },
  ];
  const topQueries = Object.entries(analytics.queries).sort((a, b) => b[1] - a[1]).slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
        {stats.map((s) => (
          <div key={s.label} className="rounded-lg border border-line bg-surface p-4">
            <p className="font-display text-2xl font-extrabold text-brand">{s.value}</p>
            <p className="mt-1 text-xs uppercase tracking-wider text-muted">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-line bg-surface p-5">
          <h3 className="font-display mb-4 text-base font-extrabold uppercase tracking-wide text-ink">
            {t("admin.recentOrders")}
          </h3>
          {state.orders.length === 0 ? (
            <p className="text-sm text-muted">{t("admin.noOrders")}</p>
          ) : (
            <ul className="divide-y divide-line text-sm">
              {state.orders.slice(0, 5).map((o) => (
                <li key={o.id} className="flex items-center justify-between py-2.5">
                  <div>
                    <p className="font-bold text-ink">
                      {o.reference} — {o.customerName}
                    </p>
                    <p className="text-xs text-muted">
                      {o.productName} × {o.quantity} · {o.wilaya}
                    </p>
                  </div>
                  <span className="text-xs font-bold text-brand">{t(`admin.status.${o.status}` as never)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="space-y-6">
          <div className="rounded-lg border border-line bg-surface p-5">
            <h3 className="font-display mb-3 text-base font-extrabold uppercase tracking-wide text-ink">
              Requêtes populaires
            </h3>
            {topQueries.length === 0 ? (
              <p className="text-sm text-muted">—</p>
            ) : (
              <ul className="space-y-1.5 text-sm">
                {topQueries.map(([q, n]) => (
                  <li key={q} className="flex justify-between">
                    <span className="text-ink">« {q} »</span>
                    <span className="font-bold text-brand">{n}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="rounded-lg border border-line bg-surface p-5">
            <h3 className="font-display mb-3 text-base font-extrabold uppercase tracking-wide text-ink">
              {t("admin.activity")}
            </h3>
            {activity.length === 0 ? (
              <p className="text-sm text-muted">{t("admin.activityEmpty")}</p>
            ) : (
              <ul className="max-h-56 space-y-1.5 overflow-y-auto text-xs">
                {activity.slice(0, 12).map((a) => (
                  <li key={a.id} className="flex justify-between gap-3">
                    <span className="text-muted">
                      <span className="font-bold text-ink">{a.user}</span> — {a.action} : {a.item}
                    </span>
                    <span className="shrink-0 text-muted/70">
                      {new Date(a.ts).toLocaleDateString("fr-DZ")}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Tab: orders                                                        */
/* ================================================================== */

function TabOrders() {
  const { state, t, updateOrderStatus, deleteOrder } = useCms();
  const statuses: OrderStatus[] = ["pending", "confirmed", "shipped", "delivered", "cancelled"];
  const [open, setOpen] = useState<string | null>(null);

  if (state.orders.length === 0)
    return <p className="py-16 text-center text-muted">{t("admin.noOrders")}</p>;

  return (
    <div className="space-y-3">
      {state.orders.map((o: Order) => (
        <div key={o.id} className="rounded-lg border border-line bg-surface">
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
            <div className="flex items-center gap-4">
              <button onClick={() => setOpen(open === o.id ? null : o.id)} className="font-display font-bold text-brand hover:underline" dir="ltr">
                {o.reference}
              </button>
              <div>
                <p className="text-sm font-bold text-ink">
                  {o.customerName} <span className="font-normal text-muted">({o.phone})</span>
                </p>
                <p className="text-xs text-muted">
                  {o.productName} × {o.quantity} — {o.wilaya} · {new Date(o.createdAt).toLocaleString("fr-DZ")}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <select
                value={o.status}
                onChange={(e) => updateOrderStatus(o.id, e.target.value as OrderStatus)}
                className="rounded border border-line bg-bg px-2.5 py-1.5 text-xs font-bold text-ink focus:border-brand focus:outline-none"
              >
                {statuses.map((s) => (
                  <option key={s} value={s}>
                    {t(`admin.status.${s}` as never)}
                  </option>
                ))}
              </select>
              <button
                onClick={() => deleteOrder(o.id)}
                className="rounded border border-line p-2 text-muted hover:border-red-400 hover:text-red-500"
                title={t("admin.delete")}
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>
          {open === o.id && (
            <div className="border-t border-line px-4 py-3 text-xs text-muted">
              <p>
                {t("product.sku")} : <b className="text-ink">{o.sku}</b> · {roundDzdPrice(o.unitPrice).toLocaleString("fr-DZ")} DA / unité · Total :{" "}
                <b className="text-ink">{roundDzdPrice(o.unitPrice * o.quantity).toLocaleString("fr-DZ")} DA</b>
              </p>
              <p className="mt-1">
                {t("cod.address")} : {o.address}
              </p>
              {o.note && <p className="mt-1">{t("cod.note")} : {o.note}</p>}
              {o.installation && (
                <p className="mt-1 text-brand">
                  🔧 {o.installation.date} · {o.installation.slot}
                </p>
              )}
              <p className="mt-1">Canal : {o.channel}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

/* ================================================================== */
/*  Tab: products                                                      */
/* ================================================================== */

const emptyProduct = (cat: string): Product => ({
  id: `p-${Date.now().toString(36)}`,
  sku: "",
  name: "",
  nameAr: "",
  categorySlug: cat,
  price: 100,
  priceMax: null,
  oldPrice: null,
  stock: 1,
  badge: "",
  image: "",
  images: [],
  shortDescription: "",
  problem: "",
  solution: "",
  features: [],
  specs: [],
  fitment: [],
  warranty: "",
  active: true,
  featured: true,
  showLowStockBadge: false,
  showDiscountBadge: false,
});

function TabProducts() {
  const { state, t, saveProduct, deleteProduct } = useCms();
  const [draft, setDraft] = useState<Product | null>(null);
  const [catFilter, setCatFilter] = useState("");
  const [query, setQuery] = useState("");

  const set = (patch: Partial<Product>) =>
    setDraft((d) => d ? { ...d, ...patch } : d);

  // Filter by category + search by title / SKU, then order by category so
  // products of the same category always appear together.
  const visible = state.products
    .filter((p) => (catFilter ? p.categorySlug === catFilter : true))
    .filter((p) => {
      const q = query.trim().toLowerCase();
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.nameAr.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q)
      );
    })
    .sort((a, b) => {
      const order = (slug: string) => {
        const i = state.categories.findIndex((c) => c.slug === slug);
        return i === -1 ? 999 : i;
      };
      return order(a.categorySlug) - order(b.categorySlug) || a.name.localeCompare(b.name);
    });

  return (
    <div className="space-y-4">
      <button
        onClick={() => {
          setDraft(emptyProduct(state.categories[0]?.slug ?? "camping"));
        }}
        className="flex items-center gap-2 rounded bg-brand px-4 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
      >
        <Plus size={16} /> {t("admin.add")} {t("admin.products")}
      </button>

      {draft && (
        <div className="rounded-lg border-2 border-brand/50 bg-surface p-5">
          <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Nom (FR) *">
              <input className={inputCls} value={draft.name} onChange={(e) => set({ name: e.target.value })} />
            </Field>
            <Field label="Nom (AR)">
              <input className={inputCls} value={draft.nameAr} onChange={(e) => set({ nameAr: e.target.value })} dir="rtl" />
            </Field>
            <Field label="SKU / Référence *">
              <input className={inputCls} value={draft.sku} onChange={(e) => set({ sku: e.target.value })} />
            </Field>
            <Field label="Catégorie">
              <select className={inputCls} value={draft.categorySlug} onChange={(e) => set({ categorySlug: e.target.value })}>
                {state.categories.map((c) => (
                  <option key={c.id} value={c.slug}>
                    {c.name.fr}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Prix (DA)">
              <input type="number" step="100" min="0" className={inputCls} value={draft.price} onChange={(e) => set({ price: roundDzdPrice(Number(e.target.value)) })} />
            </Field>
            <Field label="Prix maximum (DA, optionnel)">
              <input type="number" step="100" min="0" className={inputCls} value={draft.priceMax ?? ""} onChange={(e) => set({ priceMax: e.target.value ? roundDzdPrice(Number(e.target.value)) : null })} />
            </Field>
            <Field label="Ancien prix (DA)">
              <input type="number" step="100" min="0" className={inputCls} value={draft.oldPrice ?? ""} onChange={(e) => set({ oldPrice: e.target.value ? roundDzdPrice(Number(e.target.value)) : null })} />
            </Field>
            <Field label="Stock">
              <input type="number" className={inputCls} value={draft.stock} onChange={(e) => set({ stock: Number(e.target.value) })} />
            </Field>
            <Field label="Badge (ex: Nouveau)">
              <input className={inputCls} value={draft.badge} onChange={(e) => set({ badge: e.target.value })} />
            </Field>
            <div className="flex items-end gap-4 pb-1">
              <label className="flex items-center gap-2 text-sm text-ink">
                <input type="checkbox" checked={draft.active} onChange={(e) => set({ active: e.target.checked })} className="accent-orange-500" />
                {t("admin.active")}
              </label>
              <label className="flex items-center gap-2 text-sm text-ink">
                <input type="checkbox" checked={draft.featured} onChange={(e) => set({ featured: e.target.checked })} className="accent-orange-500" />
                {t("shop.sortFeatured")}
              </label>
            </div>
          </div>
          <div className="grid gap-3 lg:grid-cols-2">
            <ImageInput label="Image principale" value={draft.image} onChange={(v) => set({ image: v })} />
            <div className="sm:col-span-2">
              <span className={labelCls}>Images secondaires / Galerie</span>
              <div className="space-y-2">
                {(draft.images ?? []).map((src, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <img
                      src={src}
                      alt=""
                      className="h-10 w-14 shrink-0 rounded border border-line object-cover"
                    />
                    <input
                      className={inputCls}
                      value={src.startsWith("data:") ? "(image téléversée)" : src}
                      placeholder="https://… ou /images/…"
                      onChange={(e) =>
                        set({ images: (draft.images ?? []).map((x, j) => (j === i ? e.target.value : x)) })
                      }
                    />
                    <button
                      type="button"
                      onClick={() => set({ images: (draft.images ?? []).filter((_, j) => j !== i) })}
                      className="rounded border border-line p-2 text-muted transition-colors hover:border-red-400 hover:text-red-500"
                      aria-label="Supprimer l'image"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => set({ images: [...(draft.images ?? []), ""] })}
                    className="flex items-center gap-1.5 rounded border border-line px-3 py-2 text-xs font-bold uppercase tracking-wider text-ink transition-colors hover:border-brand hover:text-brand"
                  >
                    <Plus size={14} /> Ajouter une URL
                  </button>
                  <label className="flex cursor-pointer items-center gap-1.5 rounded border border-line px-3 py-2 text-xs font-bold uppercase tracking-wider text-ink transition-colors hover:border-brand hover:text-brand">
                    <Upload size={14} /> Téléverser
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      className="hidden"
                      onChange={async (e) => {
                        const files = Array.from(e.target.files ?? []);
                        const urls = await Promise.all(files.map((f) => fileToDataUrl(f)));
                        set({ images: [...(draft.images ?? []), ...urls] });
                      }}
                    />
                  </label>
                </div>
              </div>
            </div>
            <Field label="Description courte *">
              <input className={inputCls} value={draft.shortDescription} onChange={(e) => set({ shortDescription: e.target.value })} />
            </Field>
            <Field label="Problème">
              <textarea rows={2} className={inputCls} value={draft.problem} onChange={(e) => set({ problem: e.target.value })} />
            </Field>
            <Field label="Solution">
              <textarea rows={2} className={inputCls} value={draft.solution} onChange={(e) => set({ solution: e.target.value })} />
            </Field>
            <Field label="Caractéristiques (une par ligne)">
              <textarea
                rows={3}
                className={inputCls}
                value={draft.features.join("\n")}
                onChange={(e) => set({ features: e.target.value.split("\n").filter(Boolean) })}
              />
            </Field>
            <Field label="Compatibilité (une par ligne)">
              <textarea
                rows={3}
                className={inputCls}
                value={draft.fitment.join("\n")}
                onChange={(e) => set({ fitment: e.target.value.split("\n").filter(Boolean) })}
              />
            </Field>
            <Field label="Garantie">
              <input className={inputCls} value={draft.warranty} onChange={(e) => set({ warranty: e.target.value })} />
            </Field>
          </div>
          <div className="mt-4 flex gap-3">
            <button
              onClick={() => {
                const trimmedName = draft.name.trim() || "Nouveau produit 4x4";
                const trimmedSku =
                  draft.sku.trim() ||
                  `REF-${Date.now().toString(36).toUpperCase().slice(-5)}`;
                if (!saveProduct({ ...draft, name: trimmedName, sku: trimmedSku })) return;
                setDraft(null);
              }}
              className="flex items-center gap-2 rounded bg-brand px-5 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
            >
              <Check size={15} /> {t("admin.save")}
            </button>
            <button
              onClick={() => {
                setDraft(null);
              }}
              className="rounded border border-line px-5 py-2.5 text-sm font-bold text-ink hover:border-brand hover:text-brand"
            >
              {t("admin.cancel")}
            </button>
          </div>
        </div>
      )}

      {/* Category filter + search (card design above/below untouched) */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <select
          value={catFilter}
          onChange={(e) => setCatFilter(e.target.value)}
          className="rounded border border-line bg-surface px-3 py-2.5 text-sm font-semibold text-ink focus:border-brand focus:outline-none"
          aria-label="Filtrer par catégorie"
        >
          <option value="">Toutes les catégories</option>
          {state.categories.map((c) => (
            <option key={c.id} value={c.slug}>
              {c.name.fr}
            </option>
          ))}
        </select>
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Rechercher par titre ou SKU…"
          className="min-w-0 flex-1 rounded border border-line bg-surface px-3.5 py-2.5 text-sm text-ink placeholder:text-muted/60 focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30"
        />
        <span className="shrink-0 text-xs font-bold uppercase tracking-wider text-muted">
          {visible.length} / {state.products.length} produit(s)
        </span>
      </div>

      <div className="overflow-x-auto rounded-lg border border-line bg-surface">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b border-line text-start text-xs uppercase tracking-wider text-muted">
              <th className="px-3 py-3 text-start">Produit</th>
              <th className="px-3 py-3 text-start">Catégorie</th>
              <th className="px-3 py-3 text-start">Prix</th>
              <th className="px-3 py-3 text-start">Stock</th>
              <th className="px-3 py-3 text-center">Vedette</th>
              <th className="px-3 py-3 text-center">Visible</th>
              <th className="px-3 py-3 text-end">Actions</th>
            </tr>
          </thead>
          <tbody>
            {visible.map((p, i) => {
              const prev = visible[i - 1];
              const newGroup = !prev || prev.categorySlug !== p.categorySlug;
              const groupLabel =
                state.categories.find((c) => c.slug === p.categorySlug)?.name.fr ??
                p.categorySlug;
              const groupCount = visible.filter(
                (x) => x.categorySlug === p.categorySlug
              ).length;
              return (
                <Fragment key={p.id}>
                  {newGroup && (
                    <tr>
                      <th
                        colSpan={7}
                        className="bg-bg-alt px-3 py-2.5 text-start font-display text-[11px] font-extrabold uppercase tracking-[0.2em] text-brand"
                      >
                        {groupLabel}
                        <span className="ms-2 font-sans font-semibold normal-case tracking-normal text-muted">
                          {groupCount} produit(s)
                        </span>
                      </th>
                    </tr>
                  )}
              <tr className="border-b border-line last:border-0">
                <td className="px-3 py-2.5">
                  <div className="flex items-center gap-3">
                    <SafeImage
                      sources={productImageSources(p)}
                      alt=""
                      loading="lazy"
                      className="h-10 w-14 rounded border border-line object-cover"
                    />
                    <div>
                      <p className="font-bold text-ink">{p.name}</p>
                      <p className="text-xs text-muted" dir="ltr">{p.sku}</p>
                    </div>
                  </div>
                </td>
                <td className="px-3 py-2.5 text-muted">{state.categories.find((c) => c.slug === p.categorySlug)?.name.fr ?? p.categorySlug}</td>
                <td className="px-3 py-2.5">
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      step="100"
                      min="0"
                      value={p.price}
                      onChange={(e) =>
                        saveProduct({ ...p, price: roundDzdPrice(Number(e.target.value) || 0) })
                      }
                      aria-label={`Prix ${p.name}`}
                      className="w-28 rounded border border-line bg-bg px-2 py-1 font-display text-sm font-bold text-brand focus:border-brand focus:outline-none"
                    />
                    <span className="text-xs font-bold text-muted">DA</span>
                  </div>
                  {p.priceMax && p.priceMax > p.price && (
                    <span className="mt-1 block text-[10px] font-semibold text-muted">
                      max. {roundDzdPrice(p.priceMax).toLocaleString("fr-DZ")} DA
                    </span>
                  )}
                </td>
                <td className="px-3 py-2.5">
                  <input
                    type="number"
                    value={p.stock}
                    onChange={(e) =>
                      saveProduct({ ...p, stock: Math.max(0, Number(e.target.value) || 0) })
                    }
                    aria-label={`Stock ${p.name}`}
                    className={`w-16 rounded border border-line bg-bg px-2 py-1 text-sm font-bold focus:border-brand focus:outline-none ${
                      p.stock <= 0 ? "text-red-500" : "text-ink"
                    }`}
                  />
                </td>
                <td className="px-3 py-2.5 text-center">
                  <input type="checkbox" checked={p.featured} onChange={(e) => saveProduct({ ...p, featured: e.target.checked })} className="accent-orange-500" />
                </td>
                <td className="px-3 py-2.5 text-center">
                  <input type="checkbox" checked={p.active} onChange={(e) => saveProduct({ ...p, active: e.target.checked })} className="accent-orange-500" />
                </td>
                <td className="px-3 py-2.5">
                  <div className="flex justify-end gap-1.5">
                    <button
                      onClick={() => {
                        setDraft(p);
                        window.scrollTo({ top: 0, behavior: "smooth" });
                      }}
                      className="rounded border border-line p-1.5 text-muted hover:border-brand hover:text-brand"
                      title={t("admin.edit")}
                    >
                      <Pencil size={13} />
                    </button>
                    <button
                      onClick={() => deleteProduct(p.id)}
                      className="rounded border border-line p-1.5 text-muted hover:border-red-400 hover:text-red-500"
                      title={t("admin.delete")}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </td>
              </tr>
                </Fragment>
              );
            })}
            {visible.length === 0 && (
              <tr>
                <td colSpan={7} className="px-3 py-10 text-center text-sm text-muted">
                  Aucun produit ne correspond à votre recherche.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Tab: categories                                                    */
/* ================================================================== */

const emptyCategory = (): Category => ({
  id: `cat-${Date.now().toString(36)}`,
  slug: "",
  name: { fr: "", ar: "" },
  image: "",
  description: { fr: "", ar: "" },
  active: true,
});

function TabCategories() {
  const { state, t, saveCategory, deleteCategory } = useCms();
  const [draft, setDraft] = useState<Category | null>(null);
  const set = (patch: Partial<Category>) =>
    setDraft((d) => d ? { ...d, ...patch } : d);

  return (
    <div className="space-y-4">
      <button
        onClick={() => {
          setDraft(emptyCategory());
        }}
        className="flex items-center gap-2 rounded bg-brand px-4 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
      >
        <Plus size={16} /> {t("admin.add")} {t("admin.categoriesAdmin")}
      </button>

      {draft && (
        <div className="rounded-lg border-2 border-brand/50 bg-surface p-5">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Nom (FR) *">
              <input className={inputCls} value={draft.name.fr} onChange={(e) => set({ name: { ...draft.name, fr: e.target.value } })} />
            </Field>
            <Field label="Nom (AR)">
              <input className={inputCls} dir="rtl" value={draft.name.ar} onChange={(e) => set({ name: { ...draft.name, ar: e.target.value } })} />
            </Field>
            <Field label="Slug *">
              <input className={inputCls} value={draft.slug} onChange={(e) => set({ slug: e.target.value.toLowerCase().replace(/\s+/g, "-") })} />
            </Field>
          </div>
          <div className="mt-3 grid gap-3 lg:grid-cols-2">
            <ImageInput label="Image" value={draft.image} onChange={(v) => set({ image: v })} />
            <Field label="Description (FR)">
              <textarea rows={2} className={inputCls} value={draft.description.fr} onChange={(e) => set({ description: { ...draft.description, fr: e.target.value } })} />
            </Field>
          </div>
          <div className="mt-4 flex items-center gap-3">
            <button
              onClick={() => {
                const frName = draft.name.fr.trim() || "Nouvelle catégorie";
                const slug =
                  draft.slug.trim() ||
                  frName
                    .toLowerCase()
                    .normalize("NFD")
                    .replace(/[\u0300-\u036f]/g, "")
                    .replace(/[^a-z0-9]+/g, "-")
                    .replace(/^-+|-+$/g, "") ||
                  `cat-${Date.now().toString(36)}`;
                if (!saveCategory({
                  ...draft,
                  name: { ...draft.name, fr: frName },
                  slug,
                })) return;
                setDraft(null);
              }}
              className="flex items-center gap-2 rounded bg-brand px-5 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
            >
              <Check size={15} /> {t("admin.save")}
            </button>
            <label className="flex items-center gap-2 text-sm text-ink">
              <input type="checkbox" checked={draft.active} onChange={(e) => set({ active: e.target.checked })} className="accent-orange-500" />
              {t("admin.active")}
            </label>
            <button
              onClick={() => {
                setDraft(null);
              }}
              className="rounded border border-line px-5 py-2.5 text-sm font-bold text-ink hover:border-brand hover:text-brand"
            >
              {t("admin.cancel")}
            </button>
          </div>
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {state.categories.map((c) => (
          <div key={c.id} className="flex items-center gap-3 rounded-lg border border-line bg-surface p-3">
            <img src={c.image} alt="" className="h-14 w-20 rounded border border-line object-cover" />
            <div className="min-w-0 flex-1">
              <p className="truncate font-bold text-ink">{c.name.fr}</p>
              <p className="truncate text-xs text-muted" dir="ltr">/{c.slug}</p>
              <div className="mt-1.5 flex items-center gap-3">
                <input type="checkbox" checked={c.active} onChange={(e) => saveCategory({ ...c, active: e.target.checked })} className="accent-orange-500" title={t("admin.active")} />
                <button
                  onClick={() => {
                    setDraft(c);
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  className="text-muted hover:text-brand"
                  title={t("admin.edit")}
                >
                  <Pencil size={14} />
                </button>
                <button
                  onClick={() => deleteCategory(c.id)}
                  className="text-muted hover:text-red-500"
                  title={t("admin.delete")}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Tab: gallery                                                       */
/* ================================================================== */

const emptyGallery = (): GalleryItem => ({
  id: `gal-${Date.now().toString(36)}`,
  title: { fr: "", ar: "" },
  customerName: "",
  vehicle: "",
  wilaya: "",
  testimonial: { fr: "", ar: "" },
  rating: 5,
  beforeImage: "",
  afterImage: "",
  videoSrc: "",
  active: true,
});

function TabGallery() {
  const { state, t, saveGalleryItem, deleteGalleryItem } = useCms();
  const [draft, setDraft] = useState<GalleryItem | null>(null);
  const set = (patch: Partial<GalleryItem>) =>
    setDraft((d) => d ? { ...d, ...patch } : d);

  return (
    <div className="space-y-4">
      <button
        onClick={() => {
          setDraft(emptyGallery());
        }}
        className="flex items-center gap-2 rounded bg-brand px-4 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
      >
        <Plus size={16} /> {t("admin.add")} Build
      </button>

      {draft && (
        <div className="rounded-lg border-2 border-brand/50 bg-surface p-5">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Titre (FR) *">
              <input className={inputCls} value={draft.title.fr} onChange={(e) => set({ title: { ...draft.title, fr: e.target.value } })} />
            </Field>
            <Field label="Titre (AR)">
              <input className={inputCls} dir="rtl" value={draft.title.ar} onChange={(e) => set({ title: { ...draft.title, ar: e.target.value } })} />
            </Field>
            <Field label="Client">
              <input className={inputCls} value={draft.customerName} onChange={(e) => set({ customerName: e.target.value })} />
            </Field>
            <Field label="Véhicule">
              <input className={inputCls} value={draft.vehicle} onChange={(e) => set({ vehicle: e.target.value })} />
            </Field>
            <Field label="Wilaya">
              <input className={inputCls} value={draft.wilaya} onChange={(e) => set({ wilaya: e.target.value })} />
            </Field>
            <Field label="Note (1-5)">
              <input type="number" min={1} max={5} className={inputCls} value={draft.rating} onChange={(e) => set({ rating: Math.min(5, Math.max(1, Number(e.target.value))) })} />
            </Field>
          </div>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <ImageInput label="Avant" value={draft.beforeImage} onChange={(v) => set({ beforeImage: v })} />
            <ImageInput label="Après" value={draft.afterImage} onChange={(v) => set({ afterImage: v })} />
          </div>
          <div className="mt-3">
            <Field label="Témoignage (FR)">
              <textarea rows={2} className={inputCls} value={draft.testimonial.fr} onChange={(e) => set({ testimonial: { ...draft.testimonial, fr: e.target.value } })} />
            </Field>
          </div>
          <div className="mt-4 flex items-center gap-3">
            <button
              onClick={() => {
                const frTitle = draft.title.fr.trim() || "Nouveau build 4x4";
                if (!saveGalleryItem({ ...draft, title: { ...draft.title, fr: frTitle } })) return;
                setDraft(null);
              }}
              className="flex items-center gap-2 rounded bg-brand px-5 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
            >
              <Check size={15} /> {t("admin.save")}
            </button>
            <button
              onClick={() => {
                setDraft(null);
              }}
              className="rounded border border-line px-5 py-2.5 text-sm font-bold text-ink hover:border-brand hover:text-brand"
            >
              {t("admin.cancel")}
            </button>
          </div>
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {state.gallery.map((g) => (
          <div key={g.id} className="rounded-lg border border-line bg-surface p-3">
            <div className="mb-2 grid grid-cols-2 gap-1">
              <img src={g.beforeImage} alt="" className="h-20 w-full rounded object-cover" />
              <img src={g.afterImage} alt="" className="h-20 w-full rounded object-cover" />
            </div>
            <p className="truncate font-bold text-ink">{g.title.fr}</p>
            <p className="truncate text-xs text-muted">
              {g.customerName} — {g.vehicle} ({g.wilaya})
            </p>
            <div className="mt-2 flex items-center gap-3">
              <input type="checkbox" checked={g.active} onChange={(e) => saveGalleryItem({ ...g, active: e.target.checked })} className="accent-orange-500" />
              <button
                onClick={() => {
                  setDraft(g);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="text-muted hover:text-brand"
                title={t("admin.edit")}
              >
                <Pencil size={14} />
              </button>
              <button
                onClick={() => deleteGalleryItem(g.id)}
                className="text-muted hover:text-red-500"
                title={t("admin.delete")}
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Tab: hero                                                          */
/* ================================================================== */

function TabHero() {
  const { state, t, saveHeroSlide, deleteHeroSlide } = useCms();
  const [draft, setDraft] = useState<HeroSlide | null>(null);
  const set = (patch: Partial<HeroSlide>) =>
    setDraft((d) => d ? { ...d, ...patch } : d);

  return (
    <div className="space-y-4">
      <button
        onClick={() => {
          setDraft({
            id: `slide-${Date.now().toString(36)}`,
            mediaType: "image",
            image: "",
            videoUrl: "",
            videoPoster: "",
            autoplay: true,
            muted: true,
            badge: { fr: "", ar: "" },
            title: { fr: "", ar: "" },
            subtitle: { fr: "", ar: "" },
            ctaLabel: { fr: "Découvrir", ar: "استكشف" },
            ctaLink: "/shop",
            active: true,
          });
        }}
        className="flex items-center gap-2 rounded bg-brand px-4 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
      >
        <Plus size={16} /> {t("admin.add")} Slide
      </button>

      {draft && (
        <div className="rounded-lg border-2 border-brand/50 bg-surface p-5">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Type">
              <select className={inputCls} value={draft.mediaType} onChange={(e) => set({ mediaType: e.target.value as "image" | "video" })}>
                <option value="image">Image</option>
                <option value="video">Vidéo</option>
              </select>
            </Field>
            <Field label="Titre (FR) *">
              <input className={inputCls} value={draft.title.fr} onChange={(e) => set({ title: { ...draft.title, fr: e.target.value } })} />
            </Field>
            <Field label="Badge (FR)">
              <input className={inputCls} value={draft.badge.fr} onChange={(e) => set({ badge: { ...draft.badge, fr: e.target.value } })} />
            </Field>
            <Field label="Sous-titre (FR)">
              <textarea rows={2} className={inputCls} value={draft.subtitle.fr} onChange={(e) => set({ subtitle: { ...draft.subtitle, fr: e.target.value } })} />
            </Field>
            <Field label="Label CTA (FR)">
              <input className={inputCls} value={draft.ctaLabel.fr} onChange={(e) => set({ ctaLabel: { ...draft.ctaLabel, fr: e.target.value } })} />
            </Field>
            <Field label="Lien CTA">
              <input className={inputCls} value={draft.ctaLink} onChange={(e) => set({ ctaLink: e.target.value })} />
            </Field>
          </div>
          <div className="mt-3 grid gap-3 lg:grid-cols-2">
            {draft.mediaType === "image" ? (
              <ImageInput label="Image hero" value={draft.image} onChange={(v) => set({ image: v })} />
            ) : (
              <Field label="URL vidéo (MP4 / YouTube / Vimeo)">
                <input className={inputCls} value={draft.videoUrl} onChange={(e) => set({ videoUrl: e.target.value })} />
              </Field>
            )}
          </div>
          <div className="mt-4 flex items-center gap-3">
            <button
              onClick={() => {
                const frTitle = draft.title.fr.trim() || "DAHRA MOTORS 4x4";
                if (!saveHeroSlide({ ...draft, title: { ...draft.title, fr: frTitle } })) return;
                setDraft(null);
              }}
              className="flex items-center gap-2 rounded bg-brand px-5 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
            >
              <Check size={15} /> {t("admin.save")}
            </button>
            <button
              onClick={() => {
                setDraft(null);
              }}
              className="rounded border border-line px-5 py-2.5 text-sm font-bold text-ink hover:border-brand hover:text-brand"
            >
              {t("admin.cancel")}
            </button>
          </div>
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {state.hero.map((s) => (
          <div key={s.id} className="rounded-lg border border-line bg-surface p-3">
            <div className="relative mb-2">
              <img src={s.image || s.videoPoster} alt="" className="h-24 w-full rounded object-cover" />
              <span className="absolute bottom-1.5 start-1.5 rounded bg-black/70 px-1.5 py-0.5 text-[10px] font-bold uppercase text-white">
                {s.mediaType === "video" ? "Vidéo" : "Image"}
              </span>
            </div>
            <p className="truncate font-bold text-ink">{s.title.fr}</p>
            <div className="mt-2 flex items-center gap-3">
              <input type="checkbox" checked={s.active} onChange={(e) => saveHeroSlide({ ...s, active: e.target.checked })} className="accent-orange-500" />
              <button
                onClick={() => {
                  setDraft(s);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="text-muted hover:text-brand"
                title={t("admin.edit")}
              >
                <Pencil size={14} />
              </button>
              <button
                onClick={() => deleteHeroSlide(s.id)}
                className="text-muted hover:text-red-500"
                title={t("admin.delete")}
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Tab: video section                                                 */
/* ================================================================== */

function TabVideo() {
  const { state, updateVideoSection } = useCms();
  const v = state.videoSection;

  return (
    <div className="max-w-3xl space-y-4 rounded-lg border border-line bg-surface p-5">
      <label className="flex items-center gap-2.5 text-sm font-bold text-ink">
        <input type="checkbox" checked={v.enabled} onChange={(e) => updateVideoSection({ enabled: e.target.checked })} className="accent-orange-500" />
        Section vidéo activée (bannière 16:9 avec Unmute + lien YouTube)
      </label>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="URL vidéo (MP4 / YouTube / Vimeo)">
          <input className={inputCls} value={v.videoUrl} onChange={(e) => updateVideoSection({ videoUrl: e.target.value })} />
        </Field>
        <Field label="Image de couverture (poster)">
          <input className={inputCls} value={v.poster} onChange={(e) => updateVideoSection({ poster: e.target.value })} />
        </Field>
        <Field label="Badge (FR)">
          <input className={inputCls} value={v.badge.fr} onChange={(e) => updateVideoSection({ badge: { ...v.badge, fr: e.target.value } })} />
        </Field>
        <Field label="Titre (FR)">
          <input className={inputCls} value={v.title.fr} onChange={(e) => updateVideoSection({ title: { ...v.title, fr: e.target.value } })} />
        </Field>
        <Field label="Sous-titre (FR)">
          <textarea rows={2} className={inputCls} value={v.subtitle.fr} onChange={(e) => updateVideoSection({ subtitle: { ...v.subtitle, fr: e.target.value } })} />
        </Field>
        <Field label="YouTube (lien de la bannière)">
          <input
            className={inputCls}
            value={v.ctaLink}
            onChange={(e) => updateVideoSection({ ctaLink: e.target.value })}
          />
        </Field>
      </div>
      <p className="text-xs text-muted">
        Sauvegarde locale automatique. La bannière reste en 16:9 avec bouton Unmute et lien YouTube.
      </p>
    </div>
  );
}

/* ================================================================== */
/*  Tab: content                                                       */
/* ================================================================== */

function TabContent() {
  const { state, t, updateContent } = useCms();
  const c = state.content;
  const set = (patch: Partial<SiteContent>) => updateContent(patch);
  const setBadge = (i: number, patch: Partial<SiteContent["trustBadges"][number]>) =>
    updateContent({ trustBadges: c.trustBadges.map((b, j) => (j === i ? { ...b, ...patch } : b)) });

  return (
    <div className="max-w-3xl space-y-6">
      <div className="rounded-lg border border-line bg-surface p-5">
        <h3 className="font-display mb-4 text-base font-extrabold uppercase tracking-wide text-ink">
          Badges de confiance
        </h3>
        <div className="space-y-3">
          {c.trustBadges.map((b: { icon: TrustBadgeIcon } & SiteContent["trustBadges"][number], i: number) => (
            <div key={i} className="flex flex-wrap items-start gap-3 rounded border border-line p-3">
              <input type="checkbox" checked={b.enabled} onChange={(e) => setBadge(i, { enabled: e.target.checked })} className="mt-2 accent-orange-500" />
              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold uppercase tracking-wider text-muted">{b.icon}</p>
                <div className="mt-1.5 grid gap-2 sm:grid-cols-2">
                  <input className={inputCls} value={b.title.fr} onChange={(e) => setBadge(i, { title: { ...b.title, fr: e.target.value } })} />
                  <input className={inputCls} value={b.text.fr} onChange={(e) => setBadge(i, { text: { ...b.text, fr: e.target.value } })} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-3 rounded-lg border border-line bg-surface p-5">
        <h3 className="font-display mb-1 text-base font-extrabold uppercase tracking-wide text-ink">
          {t("admin.contentAdmin")}
        </h3>
        <Field label="Texte À propos (FR)">
          <textarea rows={2} className={inputCls} value={c.aboutText.fr} onChange={(e) => set({ aboutText: { ...c.aboutText, fr: e.target.value } })} />
        </Field>
        <Field label="Texte À propos 2 (FR)">
          <textarea rows={2} className={inputCls} value={c.aboutText2.fr} onChange={(e) => set({ aboutText2: { ...c.aboutText2, fr: e.target.value } })} />
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Titre catégories (FR)">
            <input className={inputCls} value={c.categoriesTitle.fr} onChange={(e) => set({ categoriesTitle: { ...c.categoriesTitle, fr: e.target.value } })} />
          </Field>
          <Field label="Titre produits vedette (FR)">
            <input className={inputCls} value={c.featuredTitle.fr} onChange={(e) => set({ featuredTitle: { ...c.featuredTitle, fr: e.target.value } })} />
          </Field>
          <Field label="Bannière — titre (FR)">
            <input className={inputCls} value={c.bannerTitle.fr} onChange={(e) => set({ bannerTitle: { ...c.bannerTitle, fr: e.target.value } })} />
          </Field>
          <Field label="Bannière — CTA (FR)">
            <input className={inputCls} value={c.bannerCta.fr} onChange={(e) => set({ bannerCta: { ...c.bannerCta, fr: e.target.value } })} />
          </Field>
        </div>
        <ImageInput label="Image À propos" value={c.aboutImage} onChange={(v) => set({ aboutImage: v })} />
        <p className="text-xs text-muted">Les champs utilisent la sauvegarde locale automatique.</p>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Tab: contact & socials                                             */
/* ================================================================== */

function TabContact() {
  const { state, t, updateCmsConfig } = useCms();
  // Edits are held in a draft until "Enregistrer" is pressed.
  const [draft, setDraft] = useState(state.settings);
  const [dirty, setDirty] = useState(false);
  const [saveResult, setSaveResult] = useState<"ok" | "fail" | null>(null);

  // Follow external changes (other tab / remote) only while nothing is being edited.
  useEffect(() => {
    if (!dirty) setDraft(state.settings);
  }, [state.settings, dirty]);

  const s = draft;
  const set = (patch: Partial<typeof s>) => {
    setDraft((d) => ({ ...d, ...patch }));
    setDirty(true);
    setSaveResult(null);
  };

  const save = () => {
    const ok = updateCmsConfig({ settings: draft }, "Paramètres mis à jour");
    setSaveResult(ok ? "ok" : "fail");
    if (ok) setDirty(false);
  };

  return (
    <div className="max-w-3xl space-y-4 rounded-lg border border-line bg-surface p-5">
      {/* Logo & branding — uploaded files are blended into the header */}
      <div className="border-b border-line pb-4">
        <p className="mb-3 text-xs font-bold uppercase tracking-wider text-muted">
          Logo & Branding
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          <ImageInput
            label="Logo en-tête (PNG/SVG transparent)"
            value={s.headerLogo}
            onChange={(v) => set({ headerLogo: v })}
          />
          <ImageInput
            label="Logo pied de page"
            value={s.footerLogo}
            onChange={(v) => set({ footerLogo: v })}
          />
        </div>
        <p className="mt-2 text-xs text-muted">
          Les logos importés sont fondus automatiquement (mix-blend-mode) : aucun cadre
          blanc, y compris en mode sombre.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Nom du store">
          <input className={inputCls} value={s.storeName} onChange={(e) => set({ storeName: e.target.value })} />
        </Field>
        <Field label="Téléphone principal">
          <input className={inputCls} value={s.phone} onChange={(e) => set({ phone: e.target.value, phones: [e.target.value, ...s.phones.slice(1)] })} dir="ltr" />
        </Field>
        <Field label="WhatsApp (chiffres)">
          <input className={inputCls} value={s.whatsapp} onChange={(e) => set({ whatsapp: e.target.value })} dir="ltr" />
        </Field>
        <Field label="Email">
          <input className={inputCls} value={s.email} onChange={(e) => set({ email: e.target.value })} dir="ltr" />
        </Field>
        <Field label="Téléphones supplémentaires (un par ligne)">
          <textarea rows={2} className={inputCls} value={s.phones.slice(1).join("\n")} onChange={(e) => set({ phones: [s.phone, ...e.target.value.split("\n").filter(Boolean)] })} dir="ltr" />
        </Field>
        <Field label="Horaires (FR)">
          <input className={inputCls} value={s.hours.fr} onChange={(e) => set({ hours: { ...s.hours, fr: e.target.value } })} />
        </Field>
        <Field label="Adresse (FR)">
          <input className={inputCls} value={s.address.fr} onChange={(e) => set({ address: { ...s.address, fr: e.target.value } })} />
        </Field>
        <Field label="Lien carte Google Maps">
          <input className={inputCls} value={s.mapLink} onChange={(e) => set({ mapLink: e.target.value })} dir="ltr" />
        </Field>
      </div>
      <div className="border-t border-line pt-4">
        <p className="mb-2 text-xs font-bold uppercase tracking-wider text-muted">{t("contact.follow")}</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Facebook">
            <input className={inputCls} value={s.social.facebook} onChange={(e) => set({ social: { ...s.social, facebook: e.target.value } })} dir="ltr" />
          </Field>
          <Field label="Instagram">
            <input className={inputCls} value={s.social.instagram} onChange={(e) => set({ social: { ...s.social, instagram: e.target.value } })} dir="ltr" />
          </Field>
          <Field label="TikTok">
            <input className={inputCls} value={s.social.tiktok} onChange={(e) => set({ social: { ...s.social, tiktok: e.target.value } })} dir="ltr" />
          </Field>
          <Field label="YouTube">
            <input className={inputCls} value={s.social.youtube} onChange={(e) => set({ social: { ...s.social, youtube: e.target.value } })} dir="ltr" />
          </Field>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-3 border-t border-line pt-4">
        <button
          type="button"
          onClick={save}
          disabled={!dirty}
          className="flex items-center gap-2 rounded bg-brand px-5 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong disabled:cursor-not-allowed disabled:opacity-40"
        >
          <Check size={15} /> Enregistrer
        </button>
        {dirty && <span className="text-xs font-semibold text-amber-500">Modifications non enregistrées</span>}
        {saveResult === "ok" && <span className="text-xs font-bold text-brand">{t("admin.saved")}</span>}
        {saveResult === "fail" && (
          <span className="text-xs font-bold text-red-500">
            Échec de sauvegarde locale. Vos modifications restent dans ce formulaire.
          </span>
        )}
      </div>
      <p className="text-xs text-muted">
        Le message WhatsApp pré-rempli est : « Bonjour Dahra Motors, je vous contacte depuis votre site web… »
      </p>
    </div>
  );
}

/* ================================================================== */
/*  Tab: security                                                      */
/* ================================================================== */

function TabSecurity() {
  const { state, t, updateCredentials } = useCms();
  const [current, setCurrent] = useState("");
  const [username, setUsername] = useState(state.credentials.username);
  const [password, setPassword] = useState("");
  const [ok, setOk] = useState(false);
  const [err, setErr] = useState(false);

  return (
    <div className="max-w-md space-y-4 rounded-lg border border-line bg-surface p-5">
      <p className="text-sm text-muted">{t("admin.securityNote")}</p>
      <Field label={t("admin.currentPassword")}>
        <input type="password" className={inputCls} value={current} onChange={(e) => setCurrent(e.target.value)} />
      </Field>
      <Field label={t("admin.newUsername")}>
        <input className={inputCls} value={username} onChange={(e) => setUsername(e.target.value)} />
      </Field>
      <Field label={t("admin.newPassword")}>
        <input type="password" className={inputCls} value={password} onChange={(e) => setPassword(e.target.value)} />
      </Field>
      {err && <p className="text-sm text-red-500">{t("admin.securityError")}</p>}
      {ok && <p className="text-sm font-bold text-brand">{t("admin.saved")}</p>}
      <button
        onClick={() => {
          if (current !== state.credentials.password) {
            setErr(true);
            setOk(false);
            return;
          }
          if (!updateCredentials({ username: username.trim() || state.credentials.username, password: password || state.credentials.password })) {
            setOk(false);
            return;
          }
          setErr(false);
          setOk(true);
          setCurrent("");
          setPassword("");
        }}
        className="rounded bg-brand px-5 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
      >
        {t("admin.save")}
      </button>
    </div>
  );
}

/* ================================================================== */
/*  Shell                                                              */
/* ================================================================== */

const TABS = [
  { id: "dashboard", label: "admin.dashboard", icon: LayoutDashboard },
  { id: "orders", label: "admin.orders", icon: ShoppingCart },
  { id: "products", label: "admin.products", icon: Package },
  { id: "categories", label: "admin.categoriesAdmin", icon: Tags },
  { id: "gallery", label: "admin.galleryAdmin", icon: Camera },
  { id: "hero", label: "admin.heroAdmin", icon: Images },
  { id: "video", label: "admin.videoSection", icon: Video },
  { id: "content", label: "admin.contentAdmin", icon: FileText },
  { id: "contact", label: "admin.contactAdmin", icon: Phone },
  { id: "security", label: "admin.security", icon: Lock },
] as const;

function Dashboard() {
  const { t, logout, adminUser, analytics, lastSavedAt, storageError } = useCms();
  // A successful login lands directly in the product/content management area.
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("products");
  const [savedFlash, setSavedFlash] = useState(false);

  // Visible confirmation that the write to localStorage actually landed.
  useEffect(() => {
    if (!lastSavedAt || storageError) {
      setSavedFlash(false);
      return;
    }
    setSavedFlash(true);
    const id = setTimeout(() => setSavedFlash(false), 2400);
    return () => clearTimeout(id);
  }, [lastSavedAt, storageError]);

  return (
    <div className="min-h-screen bg-bg-alt">
      {/* Top bar */}
      <div className="sticky top-0 z-40 border-b border-line bg-bg">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded bg-brand text-black">
              <LayoutDashboard size={18} />
            </span>
            <div>
              <h1 className="font-display text-lg font-extrabold uppercase tracking-wide text-ink">
                {t("nav.adminSpace")}
              </h1>
              <p className="text-[11px] text-muted">
                {t("admin.analytics")} : {analytics.visits} visites · {analytics.searches} recherches
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span
              className="hidden rounded border border-brand/40 bg-brand/10 px-3 py-2 font-display text-xs font-bold uppercase tracking-wider text-brand sm:block"
              title="Session active"
            >
              {adminUser ?? "admin"}
            </span>
            <span
              className="hidden items-center gap-1.5 rounded border border-line bg-bg-alt px-2.5 py-1.5 text-[11px] font-bold uppercase tracking-wider text-muted sm:flex"
              title={`Stockage local synchronise : ${STORAGE_KEY}`}
            >
              <span className="h-1.5 w-1.5 rounded-full bg-current" />
              LocalStorage
            </span>
            <span
              className={`flex items-center gap-1.5 rounded border px-2.5 py-1.5 text-[11px] font-bold uppercase tracking-wider transition-all duration-300 ${
                savedFlash
                  ? "translate-y-0 border-brand/50 bg-brand/15 text-brand opacity-100"
                  : "pointer-events-none -translate-y-1 border-transparent opacity-0"
              }`}
              title={`localStorage → ${STORAGE_KEY}`}
              role="status"
              aria-hidden={!savedFlash}
            >
              <Check size={12} />
              {t("admin.saved")}
            </span>
            <Link to="/" className="flex items-center gap-1.5 rounded border border-line px-3 py-2 text-xs font-bold uppercase tracking-wider text-ink transition-colors hover:border-brand hover:text-brand">
              <ExternalLink size={13} /> {t("admin.viewSite")}
            </Link>
            <button
              onClick={logout}
              className="flex items-center gap-1.5 rounded bg-onyx px-3 py-2 text-xs font-bold uppercase tracking-wider text-white transition-colors hover:bg-black"
            >
              <LogOut size={13} /> {t("admin.logout")}
            </button>
          </div>
        </div>
        {/* Tabs */}
        <div className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 pb-2">
          {TABS.map((tb) => (
            <button
              key={tb.id}
              onClick={() => setTab(tb.id)}
              className={`flex shrink-0 items-center gap-1.5 rounded px-3 py-2 font-display text-xs font-bold uppercase tracking-wider transition-colors ${
                tab === tb.id ? "bg-brand text-black" : "text-muted hover:bg-bg-alt hover:text-ink"
              }`}
            >
              <tb.icon size={14} /> {t(tb.label as never)}
            </button>
          ))}
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-6">
        {tab === "dashboard" && <TabDashboard />}
        {tab === "orders" && <TabOrders />}
        {tab === "products" && <TabProducts />}
        {tab === "categories" && <TabCategories />}
        {tab === "gallery" && <TabGallery />}
        {tab === "hero" && <TabHero />}
        {tab === "video" && <TabVideo />}
        {tab === "content" && <TabContent />}
        {tab === "contact" && <TabContact />}
        {tab === "security" && <TabSecurity />}
      </div>
    </div>
  );
}

export default function AdminDashboard() {
  const { isAdmin } = useCms();
  return isAdmin ? <Dashboard /> : <Login />;
}
