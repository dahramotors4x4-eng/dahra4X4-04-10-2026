import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { CarFront, Weight, ArrowRight, MessageCircle, Scale } from "lucide-react";
import { VEHICLE_DATABASE, matchesVehicleFitment } from "../lib/vehicles";
import { useCms, buildWhatsAppLink } from "../lib/store";
import { WHATSAPP_GREETING } from "../lib/data";
import { formatPrice } from "../lib/i18n";
import { SectionHeading, Reveal } from "../components/bits";

const ACCESSORIES = [
  { id: "canopy", fr: "Canopy rigide", ar: "قاطع حوض", kg: 60 },
  { id: "tent", fr: "Tente de toit", ar: "خيمة سقف", kg: 90 },
  { id: "fridge", fr: "Réfrigérateur 45L", ar: "ثلاجة 45 لتر", kg: 30 },
  { id: "water", fr: "Eau 50L", ar: "ماء 50 لتر", kg: 20 },
  { id: "bullbar", fr: "Pare-buffle acier", ar: "مصعد فولاذي", kg: 38 },
  { id: "snorkel", fr: "Snorkel", ar: "سنوركيل", kg: 15 },
  { id: "led", fr: "Barre LED", ar: "شريط LED", kg: 10 },
  { id: "agm", fr: "Batterie AGM 100Ah", ar: "بطارية AGM", kg: 25 },
  { id: "winch", fr: "Treuil", ar: "ونش", kg: 60 },
  { id: "rack", fr: "Galerie de toit", ar: "حامل سقف", kg: 25 },
  { id: "tires", fr: "Pneus 37\"", ar: "إطارات 37", kg: 100 },
];

const selectClass =
  "w-full rounded border border-line bg-surface px-3.5 py-3 text-sm text-ink focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30 transition-colors";

export default function Calculator() {
  const { state, lang, t } = useCms();
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [checked, setChecked] = useState<Record<string, boolean>>({});

  const models = VEHICLE_DATABASE.find((b) => b.brand === brand)?.models ?? [];

  const totalKg = useMemo(
    () => ACCESSORIES.filter((a) => checked[a.id]).reduce((s, a) => s + a.kg, 0),
    [checked]
  );

  const isHeavy = totalKg >= 120;

  const recommended = useMemo(() => {
    if (!brand || !model) return null;
    const suspensions = state.products.filter(
      (p) =>
        p.active &&
        p.categorySlug === "suspension" &&
        matchesVehicleFitment(p.fitment, { brand, model })
    );
    if (suspensions.length === 0) return null;
    const preferred = isHeavy
      ? suspensions.find((p) => p.id === "p-fcp-kit-prado") ?? suspensions[0]
      : suspensions.find((p) => p.id === "p-fcp-kit-hilux") ?? suspensions[0];
    return preferred;
  }, [state.products, isHeavy, brand, model]);

  const quoteMessage = `${WHATSAPP_GREETING}\n\n🚗 Véhicule : ${[brand, model].filter(Boolean).join(" ")}\n⚖️ Charge ajoutée : ${totalKg} kg\n🔧 Profil : ${isHeavy ? "Heavy Duty" : "Medium Load"}${
    recommended ? `\n📦 Kit conseillé : ${recommended.name} (${formatPrice(recommended.price, lang)})` : ""
  }`;

  return (
    <div>
      <section className="border-b border-line bg-bg-alt py-12">
        <div className="mx-auto max-w-7xl px-4">
          <SectionHeading
            align="start"
            title={{ fr: t("calc.title"), ar: t("calc.title") }}
            subtitle={{ fr: t("calc.subtitle"), ar: t("calc.subtitle") }}
          />
        </div>
      </section>

      <section className="bg-bg py-12">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 lg:grid-cols-2">
          {/* Step 1 — vehicle */}
          <Reveal>
            <div className="rounded-xl border border-line bg-surface p-6">
              <h3 className="font-display mb-5 flex items-center gap-2.5 text-lg font-extrabold uppercase tracking-wide text-ink">
                <CarFront size={22} className="text-brand" /> {t("calc.step1")}
              </h3>
              <div className="grid gap-3 sm:grid-cols-2">
                <select
                  className={selectClass}
                  value={brand}
                  onChange={(e) => {
                    setBrand(e.target.value);
                    setModel("");
                  }}
                >
                  <option value="">{t("selector.brand")} — {t("selector.allBrands")}</option>
                  {VEHICLE_DATABASE.map((b) => (
                    <option key={b.brand} value={b.brand}>
                      {b.brand}
                    </option>
                  ))}
                </select>
                <select
                  className={selectClass}
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  disabled={!brand}
                >
                  <option value="">{t("selector.model")} — {t("selector.allModels")}</option>
                  {models.map((m) => (
                    <option key={m.name} value={m.name}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </Reveal>

          {/* Step 2 — accessories */}
          <Reveal delay={0.1}>
            <div className="rounded-xl border border-line bg-surface p-6">
              <h3 className="font-display mb-5 flex items-center gap-2.5 text-lg font-extrabold uppercase tracking-wide text-ink">
                <Scale size={22} className="text-brand" /> {t("calc.step2")}
              </h3>
              <div className="grid gap-2 sm:grid-cols-2">
                {ACCESSORIES.map((a) => (
                  <label
                    key={a.id}
                    className={`flex cursor-pointer items-center justify-between gap-2 rounded border px-3 py-2.5 text-sm transition-colors ${
                      checked[a.id]
                        ? "border-brand bg-brand/10 text-ink"
                        : "border-line text-muted hover:border-brand/50"
                    }`}
                  >
                    <span className="flex items-center gap-2.5">
                      <input
                        type="checkbox"
                        checked={!!checked[a.id]}
                        onChange={(e) =>
                          setChecked((c) => ({ ...c, [a.id]: e.target.checked }))
                        }
                        className="h-4 w-4 accent-orange-500"
                      />
                      {lang === "ar" ? a.ar : a.fr}
                    </span>
                    <span className="text-xs font-bold text-brand">+{a.kg} kg</span>
                  </label>
                ))}
              </div>
            </div>
          </Reveal>
        </div>

        {/* Result */}
        <div className="mx-auto mt-10 max-w-7xl px-4">
          <Reveal>
            <div className="overflow-hidden rounded-xl border border-line bg-onyx">
              <div className="grid md:grid-cols-[auto_1fr_auto] md:items-center">
                <div className="flex items-center gap-4 p-6">
                  <div className="flex h-14 w-14 items-center justify-center rounded bg-brand/15 text-brand">
                    <Weight size={28} />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-widest text-slate-400">
                      {t("calc.totalWeight")}
                    </p>
                    <p className="font-display text-3xl font-extrabold text-white">
                      {totalKg} <span className="text-lg text-brand">kg</span>
                    </p>
                  </div>
                </div>

                <div className="border-t border-white/10 p-6 md:border-t-0 md:border-s">
                  {brand && model && recommended ? (
                    <>
                      <div className="mb-2 inline-flex rounded border border-brand/50 bg-brand/10 px-2.5 py-1 font-display text-[11px] font-bold uppercase tracking-widest text-brand">
                        {isHeavy ? t("calc.classHeavy") : t("calc.classMedium")}
                      </div>
                      <p className="text-xs uppercase tracking-widest text-slate-400">
                        {t("calc.result")}
                      </p>
                      <p className="font-display mt-1 text-xl font-extrabold uppercase tracking-wide text-white">
                        {lang === "ar" && recommended.nameAr ? recommended.nameAr : recommended.name}
                      </p>
                      <p className="mt-1 text-xs text-slate-400">{t("calc.why")}</p>
                    </>
                  ) : (
                    <p className="text-sm text-slate-400">{t("calc.selectFirst")}</p>
                  )}
                </div>

                <div className="flex flex-col gap-2.5 border-t border-white/10 p-6 md:border-t-0 md:border-s">
                  {brand && model && recommended ? (
                    <>
                      <span className="font-display text-2xl font-extrabold text-brand">
                        {formatPrice(recommended.price, lang)}
                      </span>
                      <Link
                        to={`/product/${recommended.id}`}
                        className="flex items-center justify-center gap-2 rounded bg-brand px-5 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong"
                      >
                        {t("calc.viewKit")} <ArrowRight size={15} className="rtl:rotate-180" />
                      </Link>
                      <a
                        href={buildWhatsAppLink(state.settings.whatsapp, quoteMessage)}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center justify-center gap-2 rounded border border-white/25 px-5 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-white transition-all hover:border-brand hover:bg-brand hover:text-black"
                      >
                        <MessageCircle size={15} /> WhatsApp
                      </a>
                    </>
                  ) : (
                    <p className="max-w-[220px] text-xs text-slate-500">{t("calc.noKit")}</p>
                  )}
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
