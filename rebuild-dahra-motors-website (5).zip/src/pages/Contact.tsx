import { useState } from "react";
import { Phone, Mail, MapPin, Clock, MessageCircle, Send } from "lucide-react";
import { useCms, buildWhatsAppLink } from "../lib/store";
import { WHATSAPP_GREETING } from "../lib/data";
import { loc } from "../lib/i18n";
import { SectionHeading, Reveal } from "../components/bits";

const inputClass =
  "w-full rounded border border-line bg-surface px-3.5 py-2.5 text-sm text-ink placeholder:text-muted/60 focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30 transition-colors";

export default function Contact() {
  const { state, lang, t } = useCms();
  const { settings } = state;
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState(false);

  const send = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) {
      setError(true);
      return;
    }
    const text = `${WHATSAPP_GREETING}\n\n👤 ${name || "—"}\n📞 ${phone || "—"}\n\n💬 ${message.trim()}`;
    window.open(buildWhatsAppLink(settings.whatsapp, text), "_blank", "noopener");
  };

  const cards = [
    {
      icon: Phone,
      title: t("contact.phone"),
      body: (
        <a href={`tel:${settings.phone.replace(/\s/g, "")}`} className="hover:text-brand" dir="ltr">
          {settings.phone}
        </a>
      ),
    },
    {
      icon: Mail,
      title: t("contact.email"),
      body: (
        <a href={`mailto:${settings.email}`} className="break-all hover:text-brand">
          {settings.email}
        </a>
      ),
    },
    {
      icon: MapPin,
      title: t("contact.address"),
      body: (
        <a href={settings.mapLink} target="_blank" rel="noreferrer" className="hover:text-brand">
          {loc(settings.address, lang)}
        </a>
      ),
    },
    { icon: Clock, title: t("contact.hours"), body: <span>{loc(settings.hours, lang)}</span> },
  ];

  return (
    <div>
      <section className="border-b border-line bg-bg-alt py-12">
        <div className="mx-auto max-w-7xl px-4">
          <SectionHeading
            align="start"
            title={{ fr: t("contact.title"), ar: t("contact.title") }}
            subtitle={{ fr: t("contact.subtitle"), ar: t("contact.subtitle") }}
          />
        </div>
      </section>

      <section className="bg-bg py-12">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 lg:grid-cols-2">
          {/* Info cards */}
          <div className="grid gap-4 sm:grid-cols-2">
            {cards.map((c, i) => (
              <Reveal key={i} delay={i * 0.06}>
                <div className="h-full rounded-xl border border-line bg-surface p-5 transition-all hover:-translate-y-0.5 hover:border-brand/60">
                  <div className="mb-3 flex h-10 w-10 items-center justify-center rounded bg-brand/15 text-brand">
                    <c.icon size={20} />
                  </div>
                  <h3 className="font-display text-sm font-extrabold uppercase tracking-wider text-ink">
                    {c.title}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted">{c.body}</p>
                </div>
              </Reveal>
            ))}
            <Reveal delay={0.24} className="sm:col-span-2">
              <div className="rounded-xl border border-brand/40 bg-brand/10 p-5">
                <div className="flex items-center gap-2.5">
                  <MessageCircle size={18} className="text-brand" />
                  <h3 className="font-display text-sm font-extrabold uppercase tracking-wider text-ink">
                    WhatsApp
                  </h3>
                </div>
                <p className="mt-1.5 text-sm text-muted">
                  {lang === "ar"
                    ? "رد سريع 7j/7 — استشارة، طلب، متابعة."
                    : "Réponse rapide 7j/7 — conseil, commande, suivi."}{" "}
                  <a
                    href={buildWhatsAppLink(settings.whatsapp, WHATSAPP_GREETING)}
                    target="_blank"
                    rel="noreferrer"
                    className="font-bold text-brand hover:underline"
                    dir="ltr"
                  >
                    {settings.phone}
                  </a>
                </p>
              </div>
            </Reveal>
          </div>

          {/* Form */}
          <Reveal delay={0.1}>
            <form
              onSubmit={send}
              className="rounded-xl border border-line bg-surface p-6 sm:p-8"
            >
              <h3 className="font-display mb-5 text-xl font-extrabold uppercase tracking-wide text-ink">
                {t("contact.form.title")}
              </h3>
              <div className="grid gap-3 sm:grid-cols-2">
                <input
                  className={inputClass}
                  placeholder={t("cod.name")}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
                <input
                  className={inputClass}
                  placeholder={t("cod.phone")}
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  dir="ltr"
                />
              </div>
              <textarea
                className={`${inputClass} mt-3`}
                rows={5}
                placeholder={t("contact.form.message")}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />
              {error && (
                <div className="mt-3 rounded border border-red-400/40 bg-red-500/10 px-3 py-2 text-sm text-red-500">
                  {t("cod.required")}
                </div>
              )}
              <button
                type="submit"
                className="mt-5 flex w-full items-center justify-center gap-2 rounded bg-brand px-5 py-3.5 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong hover:shadow-lg hover:shadow-brand/30"
              >
                <Send size={16} /> {t("contact.form.send")}
              </button>
            </form>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
