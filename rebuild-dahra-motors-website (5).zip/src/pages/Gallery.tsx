import { Link } from "react-router-dom";
import { Star, MapPin, MessageCircle, ArrowRight } from "lucide-react";
import { useCms, greetingWhatsAppLink } from "../lib/store";
import { loc } from "../lib/i18n";
import { SectionHeading, Reveal } from "../components/bits";

export default function Gallery() {
  const { state, lang, t } = useCms();
  const items = state.gallery.filter((g) => g.active);

  return (
    <div>
      <section className="border-b border-line bg-bg-alt py-12">
        <div className="mx-auto max-w-7xl px-4">
          <SectionHeading
            align="start"
            title={{ fr: t("gal.title"), ar: t("gal.title") }}
            subtitle={{ fr: t("gal.subtitle"), ar: t("gal.subtitle") }}
          />
        </div>
      </section>

      <section className="bg-bg py-12">
        <div className="mx-auto max-w-7xl px-4">
          {items.length === 0 ? (
            <p className="py-16 text-center text-muted">{t("admin.noOrders")}</p>
          ) : (
            <div className="grid gap-8 lg:grid-cols-2">
              {items.map((g, i) => (
                <Reveal key={g.id} delay={(i % 2) * 0.1}>
                  <article className="overflow-hidden rounded-xl border border-line bg-surface">
                    {/* Before / after */}
                    <div className="grid grid-cols-2">
                      <div className="relative">
                        <div className="aspect-[16/10] overflow-hidden">
                          <img
                            src={g.beforeImage}
                            alt={t("gal.before")}
                            loading="lazy"
                            className="h-full w-full object-cover grayscale-[40%]"
                          />
                        </div>
                        <span className="absolute start-3 top-3 rounded bg-black/70 px-2.5 py-1 font-display text-[11px] font-bold uppercase tracking-widest text-white backdrop-blur-sm">
                          {t("gal.before")}
                        </span>
                      </div>
                      <div className="relative">
                        <div className="aspect-[16/10] overflow-hidden">
                          <img
                            src={g.afterImage}
                            alt={loc(g.title, lang)}
                            loading="lazy"
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <span className="absolute start-3 top-3 rounded bg-brand px-2.5 py-1 font-display text-[11px] font-bold uppercase tracking-widest text-black">
                          {t("gal.after")}
                        </span>
                      </div>
                    </div>

                    <div className="p-5">
                      <div className="mb-1.5 flex items-center gap-0.5 text-brand">
                        {Array.from({ length: 5 }).map((_, s) => (
                          <Star key={s} size={14} className={s < g.rating ? "fill-brand" : "opacity-40"} />
                        ))}
                        <span className="ms-2 flex items-center gap-1 text-xs text-muted">
                          <MapPin size={11} className="text-brand" />
                          {g.wilaya}
                        </span>
                      </div>
                      <h3 className="font-display text-xl font-extrabold uppercase tracking-wide text-ink">
                        {loc(g.title, lang)}
                      </h3>
                      <p className="mt-0.5 text-sm text-muted">
                        {g.customerName} — {g.vehicle}
                      </p>
                      <p className="mt-3 border-s-2 border-brand ps-3 text-sm italic leading-relaxed text-muted">
                        « {loc(g.testimonial, lang)} »
                      </p>
                    </div>
                  </article>
                </Reveal>
              ))}
            </div>
          )}

          <div className="mt-14 rounded-xl border border-line bg-onyx p-8 text-center sm:p-10">
            <h3 className="font-display text-2xl font-extrabold uppercase tracking-wide text-white">
              {loc(state.content.bannerTitle, lang)}
            </h3>
            <p className="mx-auto mt-2 max-w-xl text-sm text-slate-300">
              {loc(state.content.bannerText, lang)}
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 rounded bg-brand px-6 py-3 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong"
              >
                {loc(state.content.bannerCta, lang)} <ArrowRight size={16} className="rtl:rotate-180" />
              </Link>
              <a
                href={greetingWhatsAppLink(state.settings.whatsapp)}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded border border-white/30 px-6 py-3 font-display text-sm font-bold uppercase tracking-wider text-white transition-all hover:border-brand hover:bg-brand hover:text-black"
              >
                <MessageCircle size={16} /> WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
