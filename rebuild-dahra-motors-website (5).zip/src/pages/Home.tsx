import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, ArrowRight, ShieldCheck, Star, MapPin } from "lucide-react";
import { useCms } from "../lib/store";
import { loc } from "../lib/i18n";
import { Reveal, SectionHeading, TrustBadges, VideoBackground } from "../components/bits";
import VehicleSelector from "../components/VehicleSelector";
import ProductCard from "../components/ProductCard";
import VideoSection from "../components/VideoSection";
import { useCodModal } from "../components/CodOrderModal";

const SELECTOR_BG =
  "https://images.pexels.com/photos/38263042/pexels-photo-38263042.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200";

export default function Home() {
  const { state, lang, t } = useCms();
  const slides = state.hero.filter((s) => s.active);
  const [current, setCurrent] = useState(0);
  const { openCod, codModal } = useCodModal();

  useEffect(() => {
    if (slides.length < 2) return;
    const timer = setInterval(() => setCurrent((c) => (c + 1) % slides.length), 6500);
    return () => clearInterval(timer);
  }, [slides.length]);

  const featured = state.products.filter((p) => p.active && p.featured).slice(0, 8);
  const categories = state.categories.filter((c) => c.active);
  const gallery = state.gallery.filter((g) => g.active).slice(0, 3);

  const safeCurrent = slides.length ? current % slides.length : 0;

  const prev = () => setCurrent((c) => (c - 1 + slides.length) % slides.length);
  const next = () => setCurrent((c) => (c + 1) % slides.length);

  return (
    <div>
      {codModal}

      {/* ============ HERO SLIDER ============ */}
      <section className="group relative h-[78vh] min-h-[540px] overflow-hidden bg-onyx">
        <AnimatePresence mode="sync">
          {slides[safeCurrent] && (
            <motion.div
              key={slides[safeCurrent].id}
              initial={{ opacity: 0, scale: 1.08 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.9, ease: "easeOut" }}
              className="absolute inset-0"
            >
              {slides[safeCurrent].mediaType === "video" && slides[safeCurrent].videoUrl ? (
                <VideoBackground
                  url={slides[safeCurrent].videoUrl}
                  poster={slides[safeCurrent].videoPoster || slides[safeCurrent].image}
                  autoplay={slides[safeCurrent].autoplay !== false}
                  muted={slides[safeCurrent].muted !== false}
                  className="h-full w-full object-cover"
                />
              ) : (
                <img
                  src={slides[safeCurrent].image}
                  alt={loc(slides[safeCurrent].title, lang)}
                  className="h-full w-full object-cover"
                />
              )}
              <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/55 to-black/20" />
              <div className="absolute inset-0 bg-gradient-to-t from-onyx via-transparent to-transparent" />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Slide content */}
        <div className="relative z-10 mx-auto flex h-full max-w-7xl items-center px-4">
          <AnimatePresence mode="wait">
            {slides[safeCurrent] && (
              <motion.div
                key={slides[safeCurrent].id + "-content"}
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -25 }}
                transition={{ duration: 0.6 }}
                className="max-w-3xl"
              >
                <div className="mb-4 inline-flex items-center gap-2 rounded border border-brand/50 bg-brand/10 px-4 py-1.5 backdrop-blur-sm">
                  <ShieldCheck size={15} className="text-brand" />
                  <span className="font-display text-xs font-bold uppercase tracking-[0.25em] text-brand">
                    {loc(slides[safeCurrent].badge, lang)}
                  </span>
                </div>
                <h1 className="font-display text-5xl font-extrabold uppercase leading-[0.95] tracking-wide text-white sm:text-7xl lg:text-8xl">
                  {loc(slides[safeCurrent].title, lang).split(" ")[0]}
                  <br />
                  <span className="text-brand">
                    {loc(slides[safeCurrent].title, lang)
                      .split(" ")
                      .slice(1)
                      .join(" ")}
                  </span>
                </h1>
                <p className="mt-5 max-w-xl text-base font-medium leading-relaxed text-slate-50 drop-shadow-sm sm:text-lg">
                  {loc(slides[safeCurrent].subtitle, lang)}
                </p>
                <div className="mt-8 flex flex-wrap items-center gap-3">
                  <Link
                    to={slides[safeCurrent].ctaLink}
                    className="group flex items-center gap-2 rounded bg-brand px-7 py-3.5 font-display text-base font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong hover:shadow-xl hover:shadow-brand/40"
                  >
                    {loc(slides[safeCurrent].ctaLabel, lang)}
                    <ArrowRight size={18} className="transition-transform group-hover:translate-x-1 rtl:rotate-180" />
                  </Link>
                  <Link
                    to="/about"
                    className="rounded border-2 border-[#1E293B] bg-[#1E293B] px-7 py-3 font-display text-base font-bold uppercase tracking-wider text-white transition-all hover:border-brand hover:bg-brand hover:text-black"
                  >
                    {t("nav.about")}
                  </Link>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Slider controls */}
        {slides.length > 1 && (
          <>
            <button
              onClick={prev}
              className="absolute start-1 top-1/2 z-20 -translate-y-1/2 rounded-full border border-white/20 bg-black/20 p-2 text-white opacity-30 backdrop-blur-sm transition-all duration-300 hover:border-brand/70 hover:bg-black/50 hover:text-brand hover:opacity-100 md:start-3 md:opacity-0 md:group-hover:opacity-100"
              aria-label="Previous slide"
            >
              <ChevronLeft size={22} className="rtl:rotate-180" />
            </button>
            <button
              onClick={next}
              className="absolute end-1 top-1/2 z-20 -translate-y-1/2 rounded-full border border-white/20 bg-black/20 p-2 text-white opacity-30 backdrop-blur-sm transition-all duration-300 hover:border-brand/70 hover:bg-black/50 hover:text-brand hover:opacity-100 md:end-3 md:opacity-0 md:group-hover:opacity-100"
              aria-label="Next slide"
            >
              <ChevronRight size={22} className="rtl:rotate-180" />
            </button>
            <div className="absolute bottom-6 left-1/2 z-20 flex -translate-x-1/2 gap-2">
              {slides.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => setCurrent(i)}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    i === safeCurrent ? "w-10 bg-brand" : "w-4 bg-white/40 hover:bg-white/70"
                  }`}
                  aria-label={`Go to slide ${i + 1}`}
                />
              ))}
            </div>
          </>
        )}
      </section>

      {/* ============ TRUST BADGES ============ */}
      <section className="border-b border-line bg-bg-alt py-10">
        <div className="mx-auto max-w-7xl px-4">
          <TrustBadges />
        </div>
      </section>

      {/* ============ VEHICLE SELECTOR ============ */}
      <section className="relative overflow-hidden bg-onyx py-16">
        <div
          className="absolute inset-0 opacity-15"
          style={{
            backgroundImage: `url(${SELECTOR_BG})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-onyx/70 via-onyx/40 to-onyx/80" />
        <div className="relative z-10 mx-auto max-w-7xl px-4">
          <Reveal>
            <VehicleSelector />
          </Reveal>
        </div>
      </section>

      {/* ============ VIDEO BANNER (16:9, Unmute, YouTube) ============ */}
      <VideoSection />

      {/* ============ CATEGORIES ============ */}
      <section className="border-b border-line bg-bg py-16">
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <SectionHeading
              title={state.content.categoriesTitle}
              subtitle={state.content.categoriesSubtitle}
            />
          </Reveal>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {categories.map((cat, i) => (
              <Reveal key={cat.id} delay={i * 0.05}>
                <Link
                  to={`/shop?category=${cat.slug}`}
                  className="group relative block overflow-hidden rounded-lg border border-line bg-surface"
                >
                  <div className="aspect-[4/5] overflow-hidden">
                    <img
                      src={cat.image}
                      alt={loc(cat.name, lang)}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-4">
                    <h3 className="font-display text-base font-extrabold uppercase leading-tight tracking-wide text-white">
                      {loc(cat.name, lang)}
                    </h3>
                    <p className="mt-1 line-clamp-2 text-xs text-slate-300">
                      {loc(cat.description, lang)}
                    </p>
                    <span className="mt-2 inline-flex items-center gap-1 font-display text-[11px] font-bold uppercase tracking-widest text-brand opacity-0 transition-opacity group-hover:opacity-100">
                      {t("cta.explore")} <ArrowRight size={12} className="rtl:rotate-180" />
                    </span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ============ FEATURED PRODUCTS ============ */}
      <section className="bg-bg-alt py-16">
        <div className="mx-auto max-w-7xl px-4">
          <Reveal>
            <SectionHeading
              title={state.content.featuredTitle}
              subtitle={state.content.featuredSubtitle}
            />
          </Reveal>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {featured.map((p) => (
              <ProductCard key={p.id} product={p} onOrder={openCod} />
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 rounded border-2 border-ink px-7 py-3 font-display text-base font-bold uppercase tracking-wider text-ink transition-all hover:border-brand hover:bg-brand hover:text-black"
            >
              {t("cta.viewAll")} <ArrowRight size={18} className="rtl:rotate-180" />
            </Link>
          </div>
        </div>
      </section>

      {/* ============ GALLERY PREVIEW ============ */}
      {gallery.length > 0 && (
        <section className="border-b border-line bg-bg py-16">
          <div className="mx-auto max-w-7xl px-4">
            <Reveal>
              <SectionHeading
                title={{ fr: "Derniers Builds Réalisés", ar: "آخر التجهيزات" }}
                subtitle={{
                  fr: "Véhicules livrés et installés par nos équipes.",
                  ar: "سيارات تم توصيلها وتركيبها من قبل فريقنا.",
                }}
              />
            </Reveal>
            <div className="grid gap-5 md:grid-cols-3">
              {gallery.map((g) => (
                <Reveal key={g.id}>
                  <Link
                    to="/gallery"
                    className="group relative block overflow-hidden rounded-lg border border-line"
                  >
                    <div className="aspect-[16/10] overflow-hidden">
                      <img
                        src={g.afterImage}
                        alt={loc(g.title, lang)}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    </div>
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                    <div className="absolute inset-x-0 bottom-0 p-4">
                      <div className="mb-1 flex items-center gap-0.5 text-brand">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            size={13}
                            className={i < g.rating ? "fill-brand" : "opacity-40"}
                          />
                        ))}
                      </div>
                      <h3 className="font-display text-base font-bold uppercase tracking-wide text-white">
                        {loc(g.title, lang)}
                      </h3>
                      <p className="mt-0.5 flex items-center gap-1 text-xs text-slate-300">
                        <MapPin size={11} className="text-brand" />
                        {g.vehicle} — {g.wilaya}
                      </p>
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ============ CTA BANNER ============ */}
      <section className="relative overflow-hidden bg-onyx py-20">
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              "url(https://images.pexels.com/photos/10658203/pexels-photo-10658203.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200)",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-onyx/80 to-onyx" />
        <div className="relative z-10 mx-auto max-w-4xl px-4 text-center">
          <Reveal>
            <h2 className="font-display text-4xl font-extrabold uppercase tracking-wide text-white sm:text-5xl">
              {loc(state.content.bannerTitle, lang)}
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-base text-slate-300">
              {loc(state.content.bannerText, lang)}
            </p>
            <Link
              to="/contact"
              className="mt-8 inline-flex items-center gap-2 rounded bg-brand px-8 py-4 font-display text-base font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong hover:shadow-xl hover:shadow-brand/40"
            >
              {loc(state.content.bannerCta, lang)}
              <ArrowRight size={18} className="rtl:rotate-180" />
            </Link>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
