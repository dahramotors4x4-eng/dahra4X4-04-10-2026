import { Link } from "react-router-dom";
import { Compass } from "lucide-react";
import { useCms } from "../lib/store";

export default function NotFound() {
  const { t } = useCms();
  return (
    <div className="mx-auto max-w-2xl px-4 py-28 text-center">
      <Compass size={48} className="mx-auto text-brand" />
      <p className="font-display mt-6 text-6xl font-extrabold uppercase tracking-wide text-ink">
        404
      </p>
      <p className="mt-2 text-lg text-muted">{t("common.notFound")}</p>
      <Link
        to="/"
        className="mt-8 inline-block rounded bg-brand px-7 py-3 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong"
      >
        {t("common.backHome")}
      </Link>
    </div>
  );
}
