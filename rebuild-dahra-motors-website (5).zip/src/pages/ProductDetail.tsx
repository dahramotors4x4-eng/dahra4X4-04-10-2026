import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  ShoppingCart,
  MessageCircle,
  PackageCheck,
  AlertTriangle,
  ShieldCheck,
  Check,
  ChevronRight,
  Truck,
  Wrench,
} from "lucide-react";
import { useCms, buildWhatsAppLink, productWhatsAppMessage } from "../lib/store";
import { formatPrice, formatProductPrice, loc } from "../lib/i18n";
import ProductCard from "../components/ProductCard";
import { useCodModal } from "../components/CodOrderModal";
import { Reveal } from "../components/bits";
import { productImageSources } from "../lib/productImages";
import SafeImage from "../components/SafeImage";

export default function ProductDetail() {
  const { id } = useParams();
  const { state, siteConfig, lang, t } = useCms();
  const { openCod, codModal } = useCodModal();
  const [qty, setQty] = useState(1);
  const [activeImg, setActiveImg] = useState<string | null>(null);

  const product = state.products.find((p) => p.id === id);

  if (!product || !product.active) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="font-display text-2xl font-extrabold uppercase text-ink">
          {t("common.notFound")}
        </p>
        <Link
          to="/shop"
          className="mt-6 inline-block rounded bg-brand px-7 py-3 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
        >
          {t("common.backHome")}
        </Link>
      </div>
    );
  }

  const name = lang === "ar" && product.nameAr ? product.nameAr : product.name;
  const price = formatProductPrice(product, lang);
  const outOfStock = product.stock <= 0;
  const showLowStock = product.stock <= 5 && product.showLowStockBadge !== false;
  // Main image + secondary gallery (thumbnails switch the main view).
  const gallery = Array.from(
    new Set(productImageSources(product))
  );
  const currentImg = activeImg && gallery.includes(activeImg) ? activeImg : gallery[0];

  const category = state.categories.find((c) => c.slug === product.categorySlug);
  const related = state.products
    .filter((p) => p.active && p.id !== product.id && p.categorySlug === product.categorySlug)
    .slice(0, 4);

  return (
    <div>
      {codModal}
      <div className="mx-auto max-w-7xl px-4 py-8">
        {/* Breadcrumb */}
        <nav className="mb-6 flex flex-wrap items-center gap-1.5 text-xs text-muted">
          <Link to="/" className="transition-colors hover:text-brand">
            {t("common.breadcrumb.home")}
          </Link>
          <ChevronRight size={12} className="rtl:rotate-180" />
          <Link to="/shop" className="transition-colors hover:text-brand">
            {t("nav.shop")}
          </Link>
          {category && (
            <>
              <ChevronRight size={12} className="rtl:rotate-180" />
              <Link
                to={`/shop?category=${category.slug}`}
                className="transition-colors hover:text-brand"
              >
                {loc(category.name, lang)}
              </Link>
            </>
          )}
          <ChevronRight size={12} className="rtl:rotate-180" />
          <span className="font-semibold text-ink">{product.sku}</span>
        </nav>

        <div className="grid gap-8 lg:grid-cols-2">
          {/* Image */}
          <div>
            <div className="relative overflow-hidden rounded-xl border border-line bg-bg-alt">
              <div className="aspect-[4/3]">
                <SafeImage
                  sources={[currentImg, ...gallery]}
                  alt={name}
                  className="h-full w-full object-cover transition-opacity duration-300"
                />
              </div>
              {/* Animated official badge — fades in/out, sits clear of details */}
              <span className="ironman-badge absolute end-3 top-3 rounded-sm border border-brand/60 bg-black/70 px-2.5 py-1 font-display text-[10px] font-bold uppercase leading-tight tracking-[0.18em] text-brand backdrop-blur-sm">
                Ironman 4x4 Official
              </span>
              {product.badge && (
                <span className="absolute start-4 top-4 rounded bg-brand px-2.5 py-1 font-display text-xs font-bold uppercase tracking-wider text-black">
                  {product.badge}
                </span>
              )}
            </div>

            {/* Clickable thumbnails for the secondary gallery */}
            {gallery.length > 1 && (
              <div className="mt-3 flex flex-wrap gap-2">
                {gallery.map((src, i) => (
                  <button
                    key={`${src}-${i}`}
                    type="button"
                    onClick={() => setActiveImg(src)}
                    aria-label={`${name} — image ${i + 1}`}
                    className={`h-16 w-20 overflow-hidden rounded border-2 transition-all duration-200 ${
                      currentImg === src
                        ? "border-brand opacity-100 shadow-md shadow-brand/20"
                        : "border-line opacity-60 hover:border-brand/50 hover:opacity-100"
                    }`}
                  >
                    <SafeImage
                      sources={[src, ...gallery]}
                      alt=""
                      loading="lazy"
                      className="h-full w-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div>
            {category && (
              <Link
                to={`/shop?category=${category.slug}`}
                className="font-display text-xs font-bold uppercase tracking-[0.25em] text-brand"
              >
                {loc(category.name, lang)}
              </Link>
            )}
            <h1 className="font-display mt-2 text-3xl font-extrabold uppercase tracking-wide text-ink sm:text-4xl">
              {name}
            </h1>
            <p className="mt-1 text-sm text-muted">
              {t("product.sku")} <span className="font-semibold text-ink">{product.sku}</span>
            </p>

            <div className="mt-4 flex items-center gap-3">
              <span
                className={`flex items-center gap-1.5 rounded px-3 py-1 text-xs font-bold ${
                  outOfStock
                    ? "bg-red-500/10 text-red-500"
                    : showLowStock
                      ? "bg-amber-500/10 text-amber-600"
                      : "bg-brand/10 text-brand"
                }`}
              >
                <PackageCheck size={14} />
                {outOfStock
                  ? t("product.outOfStock")
                  : showLowStock
                    ? t("product.lowStock")
                    : t("product.inStock")}
              </span>
            </div>

            <p className="mt-4 text-base leading-relaxed text-muted">
              {product.shortDescription}
            </p>

            <div className="mt-6 flex items-baseline gap-3">
              <span className="font-display text-4xl font-extrabold text-brand">{price}</span>
              {product.oldPrice && product.oldPrice > product.price && (
                <span className="text-lg text-muted line-through">
                  {formatPrice(product.oldPrice, lang)}
                </span>
              )}
            </div>

            {/* Quantity + total */}
            <div className="mt-5 flex flex-wrap items-center gap-4">
              <div className="flex items-center rounded border border-line">
                <button
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="h-11 w-11 text-lg text-ink hover:text-brand"
                >
                  −
                </button>
                <span className="w-12 text-center font-display text-lg font-bold text-ink">
                  {qty}
                </span>
                <button
                  onClick={() => setQty((q) => Math.min(Math.max(product.stock, 1), q + 1))}
                  className="h-11 w-11 text-lg text-ink hover:text-brand"
                >
                  +
                </button>
              </div>
              <span className="text-sm text-muted">
                {t("cod.total")} :{" "}
                <span className="font-display text-lg font-extrabold text-ink">
                  {formatProductPrice(product, lang, qty)}
                </span>
              </span>
            </div>

            {/* CTAs */}
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <button
                onClick={() => openCod(product)}
                disabled={outOfStock}
                className="flex items-center justify-center gap-2 rounded bg-brand px-5 py-3.5 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong hover:shadow-lg hover:shadow-brand/30 disabled:cursor-not-allowed disabled:opacity-40"
              >
                <ShoppingCart size={17} /> {t("cta.shop")}
              </button>
              <a
                href={buildWhatsAppLink(
                  state.settings.whatsapp,
                  productWhatsAppMessage(name, product.sku, price)
                )}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 rounded bg-brand px-5 py-3.5 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong hover:shadow-lg hover:shadow-brand/30"
              >
                <MessageCircle size={17} /> {t("cta.whatsapp")}
              </a>
            </div>

            {/* Reassurance */}
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              {siteConfig.delivery && <div className="flex items-center gap-2.5 rounded-lg border border-line bg-surface p-3 text-xs text-muted">
                <Truck size={17} className="shrink-0 text-brand" />
                <span>{loc(siteConfig.delivery.title, lang)} : {loc(siteConfig.delivery.text, lang)}</span>
              </div>}
              <div className="flex items-center gap-2.5 rounded-lg border border-line bg-surface p-3 text-xs text-muted">
                <Wrench size={17} className="shrink-0 text-brand" />
                {lang === "ar" ? "تركيب محترف في ورشة برقي (الجزائر)" : "Installation experte à Baraki (Alger)"}
              </div>
            </div>
          </div>
        </div>

        {/* Problem / Solution / Features */}
        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          <Reveal className="rounded-xl border border-line bg-surface p-6">
            <div className="mb-3 flex h-10 w-10 items-center justify-center rounded bg-red-500/10 text-red-500">
              <AlertTriangle size={20} />
            </div>
            <h3 className="font-display text-lg font-extrabold uppercase tracking-wide text-ink">
              {t("problem")}
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">{product.problem}</p>
          </Reveal>
          <Reveal delay={0.1} className="rounded-xl border border-line bg-surface p-6">
            <div className="mb-3 flex h-10 w-10 items-center justify-center rounded bg-brand/10 text-brand">
              <Check size={20} />
            </div>
            <h3 className="font-display text-lg font-extrabold uppercase tracking-wide text-ink">
              {t("solution")}
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">{product.solution}</p>
          </Reveal>
          {product.warranty ? (
            <Reveal delay={0.2} className="rounded-xl border border-line bg-surface p-6">
              <div className="mb-3 flex h-10 w-10 items-center justify-center rounded bg-brand/10 text-brand">
                <ShieldCheck size={20} />
              </div>
              <h3 className="font-display text-lg font-extrabold uppercase tracking-wide text-ink">
                {t("warranty")}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{product.warranty}</p>
            </Reveal>
          ) : null}
        </div>

        {/* Features + specs + fitment */}
        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          <div className="rounded-xl border border-line bg-surface p-6">
            <h3 className="font-display mb-4 text-lg font-extrabold uppercase tracking-wide text-ink">
              {t("features")}
            </h3>
            <ul className="space-y-2.5">
              {product.features.map((f, i) => (
                <li key={i} className="flex items-start gap-2.5 text-sm text-muted">
                  <Check size={16} className="mt-0.5 shrink-0 text-brand" />
                  {f}
                </li>
              ))}
            </ul>
            {product.fitment.length > 0 && (
              <>
                <h3 className="font-display mb-3 mt-6 text-lg font-extrabold uppercase tracking-wide text-ink">
                  {t("fitment")}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {product.fitment.map((f, i) => (
                    <span
                      key={i}
                      className="rounded-full border border-line bg-bg-alt px-3 py-1 text-xs font-semibold text-ink"
                    >
                      {f}
                    </span>
                  ))}
                </div>
              </>
            )}
          </div>
          <div className="rounded-xl border border-line bg-surface p-6">
            <h3 className="font-display mb-4 text-lg font-extrabold uppercase tracking-wide text-ink">
              {t("specs")}
            </h3>
            {product.specs.length === 0 ? (
              <p className="text-sm text-muted">
                {lang === "ar" ? "المواصفات الكاملة متوفرة عبر واتساب." : "Spécifications détaillées disponibles sur WhatsApp."}
              </p>
            ) : (
              <table className="w-full text-sm">
                <tbody>
                  {product.specs.map((s, i) => (
                    <tr key={i} className="border-b border-line last:border-0">
                      <td className="py-2.5 text-muted">{s.label}</td>
                      <td className="py-2.5 text-end font-semibold text-ink" dir="ltr">
                        {s.value}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <div className="mt-14">
            <h2 className="font-display mb-6 text-2xl font-extrabold uppercase tracking-wide text-ink">
              {t("related")}
            </h2>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} onOrder={openCod} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
