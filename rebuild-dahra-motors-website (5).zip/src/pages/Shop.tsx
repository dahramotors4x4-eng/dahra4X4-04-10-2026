import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Search, Car, X } from "lucide-react";
import { useCms } from "../lib/store";
import { loc } from "../lib/i18n";
import { SectionHeading } from "../components/bits";
import ProductCard from "../components/ProductCard";
import { useCodModal } from "../components/CodOrderModal";
import { matchesVehicleFitment } from "../lib/vehicles";

type SortKey = "featured" | "priceAsc" | "priceDesc" | "name";

export default function Shop() {
  const { state, lang, t, trackSearch } = useCms();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const { openCod, codModal } = useCodModal();

  const category = params.get("category") ?? "";
  const brand = params.get("brand") ?? "";
  const model = params.get("model") ?? "";
  const year = params.get("year") ?? "";
  const [search, setSearch] = useState(params.get("q") ?? "");
  const [sort, setSort] = useState<SortKey>("featured");

  const activeCat = state.categories.find((c) => c.slug === category && c.active);

  const setParam = (key: string, value: string) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value);
    else next.delete(key);
    setParams(next, { replace: true });
  };

  // Track searches as a side effect (never during render)
  useEffect(() => {
    if (search.trim()) trackSearch(search);
  }, [search, trackSearch]);

  const filtered = useMemo(() => {
    let list = state.products.filter((p) => p.active);
    if (category) list = list.filter((p) => p.categorySlug === category);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.nameAr.toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q) ||
          p.shortDescription.toLowerCase().includes(q)
      );
    }
    if (brand || model || year) {
      list = list.filter((p) =>
        matchesVehicleFitment(p.fitment, { brand, model, year })
      );
    }
    const sorted = [...list];
    if (sort === "priceAsc") sorted.sort((a, b) => a.price - b.price);
    else if (sort === "priceDesc") sorted.sort((a, b) => b.price - a.price);
    else if (sort === "name") sorted.sort((a, b) => a.name.localeCompare(b.name));
    else sorted.sort((a, b) => Number(b.featured) - Number(a.featured));
    return sorted;
  }, [state.products, category, search, sort, brand, model, year]);

  const clearVehicle = () => {
    const next = new URLSearchParams(params);
    next.delete("brand");
    next.delete("model");
    next.delete("year");
    setParams(next, { replace: true });
  };

  return (
    <div>
      {codModal}
      {/* Page header */}
      <section className="border-b border-line bg-bg-alt py-12">
        <div className="mx-auto max-w-7xl px-4">
          <SectionHeading
            align="start"
            title={{ fr: activeCat?.name.fr ?? "Boutique", ar: activeCat?.name.ar ?? "المتجر" }}
            subtitle={{
              fr: activeCat?.description.fr ?? t("shop.subtitle"),
              ar: activeCat?.description.ar ?? t("shop.subtitle"),
            }}
          />
        </div>
      </section>

      <section className="bg-bg py-10">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 px-4 lg:flex-row">
          {/* Sidebar */}
          <aside className="w-full shrink-0 lg:w-60">
            <h3 className="font-display mb-3 text-sm font-extrabold uppercase tracking-widest text-ink">
              {t("shop.allCategories")}
            </h3>
            <ul className="space-y-1">
              <li>
                <button
                  onClick={() => setParam("category", "")}
                  className={`w-full rounded px-3 py-2 text-start text-sm transition-colors ${
                    !category
                      ? "bg-brand/15 font-bold text-brand"
                      : "text-muted hover:bg-bg-alt hover:text-ink"
                  }`}
                >
                  {t("shop.allCategories")}
                  <span className="float-end text-xs opacity-60">
                    {state.products.filter((p) => p.active).length}
                  </span>
                </button>
              </li>
              {state.categories
                .filter((c) => c.active)
                .map((c) => {
                  const count = state.products.filter((p) => p.active && p.categorySlug === c.slug)
                    .length;
                  return (
                    <li key={c.id}>
                      <button
                        onClick={() => setParam("category", c.slug)}
                        className={`w-full rounded px-3 py-2 text-start text-sm transition-colors ${
                          category === c.slug
                            ? "bg-brand/15 font-bold text-brand"
                            : "text-muted hover:bg-bg-alt hover:text-ink"
                        }`}
                      >
                        {loc(c.name, lang)}
                        <span className="float-end text-xs opacity-60">{count}</span>
                      </button>
                    </li>
                  );
                })}
            </ul>
          </aside>

          {/* Main */}
          <div className="min-w-0 flex-1">
            {/* Toolbar */}
            <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className="relative min-w-0 flex-1">
                <Search
                  size={16}
                  className="absolute start-3 top-1/2 -translate-y-1/2 text-muted"
                />
                <input
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value);
                    setParam("q", e.target.value);
                  }}
                  placeholder={t("shop.search")}
                  className="w-full rounded border border-line bg-surface py-2.5 ps-9 pe-4 text-sm text-ink placeholder:text-muted/70 focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30"
                />
              </div>
              <div className="flex items-center gap-3">
                <span className="whitespace-nowrap text-xs text-muted">
                  {filtered.length} {t("shop.results")}
                </span>
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value as SortKey)}
                  className="rounded border border-line bg-surface px-3 py-2.5 text-sm text-ink focus:border-brand focus:outline-none"
                  aria-label={t("shop.sort")}
                >
                  <option value="featured">{t("shop.sortFeatured")}</option>
                  <option value="priceAsc">{t("shop.sortPriceAsc")}</option>
                  <option value="priceDesc">{t("shop.sortPriceDesc")}</option>
                  <option value="name">{t("shop.sortName")}</option>
                </select>
              </div>
            </div>

            {/* Active vehicle filter chip */}
            {(brand || model) && (
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-brand/40 bg-brand/10 px-4 py-1.5 text-sm text-brand">
                <Car size={15} />
                <span>
                  {t("shop.vehicleFilter")} : {[brand, model, year].filter(Boolean).join(" · ")}
                </span>
                <button
                  onClick={clearVehicle}
                  className="rounded-full p-0.5 transition-colors hover:bg-brand hover:text-black"
                  aria-label="Clear"
                >
                  <X size={14} />
                </button>
              </div>
            )}

            {/* Grid */}
            {filtered.length === 0 ? (
              <div className="rounded-lg border border-dashed border-line bg-surface px-6 py-20 text-center">
                <p className="text-muted">{t("shop.noResults")}</p>
                <Link
                  to="/shop"
                  className="mt-4 inline-block rounded bg-brand px-6 py-2.5 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
                >
                  {t("shop.allCategories")}
                </Link>
              </div>
            ) : (
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {filtered.map((p) => (
                  <ProductCard key={p.id} product={p} onOrder={openCod} />
                ))}
              </div>
            )}

            <button
              onClick={() => navigate("/")}
              className="mt-8 hidden text-sm text-muted hover:text-brand lg:block"
            >
              ← {t("common.backHome")}
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
