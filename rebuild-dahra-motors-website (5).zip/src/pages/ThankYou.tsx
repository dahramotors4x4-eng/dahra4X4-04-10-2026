import { Link } from "react-router-dom";
import { Check, MessageCircle, ShoppingCart, MessageSquare } from "lucide-react";
import { useCms, buildWhatsAppLink, orderWhatsAppMessage } from "../lib/store";
import { formatPrice } from "../lib/i18n";
import { roundDzdPrice } from "../lib/pricing";

export default function ThankYou() {
  const { state, lang, t } = useCms();
  const order = state.orders[0];

  if (!order) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <p className="font-display text-3xl font-extrabold uppercase text-ink">{t("ty.noOrder")}</p>
        <Link
          to="/shop"
          className="mt-8 inline-block rounded bg-brand px-7 py-3 font-display text-sm font-bold uppercase tracking-wider text-black hover:bg-brand-strong"
        >
          {t("ty.backShop")}
        </Link>
      </div>
    );
  }

  const total = order.unitPrice * order.quantity;
  const smsText = `${t("ty.title")} ${t("ty.reference")} ${order.reference} — ${order.productName} ×${order.quantity} — ${roundDzdPrice(total).toLocaleString("fr-DZ")} DA — ${order.wilaya}`;

  return (
    <div className="bg-bg-alt py-16">
      <div className="mx-auto max-w-2xl px-4">
        <div className="overflow-hidden rounded-xl border border-line bg-surface">
          <div className="bg-onyx px-6 py-10 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-500/15 text-green-500">
              <Check size={32} />
            </div>
            <h1 className="font-display text-3xl font-extrabold uppercase tracking-wide text-white">
              {t("ty.title")}
            </h1>
            <p className="mt-2 text-sm text-slate-300">{t("ty.confirm")}</p>
          </div>

          <div className="p-6 sm:p-8">
            <div className="mb-5 flex items-center justify-between rounded-lg border border-brand/40 bg-brand/10 px-4 py-3">
              <span className="text-xs uppercase tracking-widest text-muted">
                {t("ty.reference")}
              </span>
              <span className="font-display text-xl font-extrabold text-brand" dir="ltr">
                {order.reference}
              </span>
            </div>

            <h2 className="font-display mb-3 text-lg font-extrabold uppercase tracking-wide text-ink">
              {t("ty.summary")}
            </h2>
            <div className="divide-y divide-line rounded-lg border border-line text-sm">
              <div className="flex justify-between px-4 py-2.5">
                <span className="text-muted">{t("ty.customer")}</span>
                <span className="font-semibold text-ink">{order.customerName}</span>
              </div>
              <div className="flex justify-between px-4 py-2.5">
                <span className="text-muted">{t("contact.phone")}</span>
                <span className="font-semibold text-ink" dir="ltr">
                  {order.phone}
                </span>
              </div>
              <div className="flex justify-between px-4 py-2.5">
                <span className="text-muted">{t("ty.delivery")}</span>
                <span className="font-semibold text-ink">{order.wilaya}</span>
              </div>
              <div className="flex justify-between px-4 py-2.5">
                <span className="text-muted">Produit</span>
                <span className="font-semibold text-ink">
                  {order.productName} × {order.quantity}
                </span>
              </div>
              <div className="flex justify-between px-4 py-2.5">
                <span className="text-muted">{t("cod.total")}</span>
                <span className="font-display font-extrabold text-brand">
                  {formatPrice(total, lang)}
                </span>
              </div>
              {order.installation && (
                <div className="flex justify-between px-4 py-2.5">
                  <span className="text-muted">{t("cod.installBooked")}</span>
                  <span className="font-semibold text-ink">
                    {order.installation.date} · {order.installation.slot}
                  </span>
                </div>
              )}
            </div>

            <p className="mt-4 text-xs leading-relaxed text-muted">
              {t("ty.callNote")}{" "}
              <span className="font-bold text-ink" dir="ltr">
                {order.phone}
              </span>
              .
            </p>

            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <a
                href={buildWhatsAppLink(state.settings.whatsapp, orderWhatsAppMessage(order, total))}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 rounded bg-brand px-4 py-3 font-display text-sm font-bold uppercase tracking-wider text-black transition-all hover:bg-brand-strong hover:shadow-lg hover:shadow-brand/30"
              >
                <MessageCircle size={16} /> {t("ty.whatsappHelp")}
              </a>
              <a
                href={`sms:${order.phone}?body=${encodeURIComponent(smsText)}`}
                className="flex items-center justify-center gap-2 rounded border border-line px-4 py-3 font-display text-sm font-bold uppercase tracking-wider text-ink transition-colors hover:border-brand hover:text-brand"
              >
                <MessageSquare size={16} /> {t("ty.smsAlert")}
              </a>
            </div>

            <Link
              to="/shop"
              className="mt-4 flex items-center justify-center gap-2 rounded bg-onyx px-4 py-3 font-display text-sm font-bold uppercase tracking-wider text-white transition-colors hover:bg-black"
            >
              <ShoppingCart size={16} /> {t("ty.backShop")}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
