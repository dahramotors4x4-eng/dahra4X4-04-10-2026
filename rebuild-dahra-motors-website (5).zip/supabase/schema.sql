-- Dahra Motors 4x4 — central CMS document store
-- Run this once in the Supabase SQL editor, then set the two env vars:
--   VITE_SUPABASE_URL=https://xxxx.supabase.co
--   VITE_SUPABASE_ANON_KEY=eyJhbGciOi...

create table if not exists public.dahra_cms (
  id         text primary key,
  data       jsonb not null,
  updated_at timestamptz not null default now()
);

-- Single row holding the whole CMS state (settings, products, categories…).
insert into public.dahra_cms (id, data)
values ('dahra-motors', '{}'::jsonb)
on conflict (id) do nothing;

-- Realtime: broadcast every change to connected clients.
alter publication supabase_realtime add table public.dahra_cms;

-- Read (storefront) + write (dashboard) policies for anon access.
create policy "dahra cms read"
  on public.dahra_cms for select
  using (true);

create policy "dahra cms write"
  on public.dahra_cms for all
  using (true)
  with check (true);
