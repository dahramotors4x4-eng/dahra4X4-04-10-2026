import assert from "node:assert/strict";
import test from "node:test";
import {
  CMS_UPDATED_EVENT,
  CMS_SYNC_CHANNEL,
  ADMIN_PASSWORD,
  ADMIN_USERNAME,
  DEFAULT_STATE,
  IRONMAN_VIDEO_EMBED_URL,
  IRONMAN_VIDEO_WATCH_URL,
  STORAGE_KEY,
  loadState,
  parseCmsState,
  readSavedState,
  saveState,
  subscribeCmsUpdates,
} from "../src/lib/data.ts";
import {
  VEHICLE_DATABASE,
  matchesVehicleFitment,
} from "../src/lib/vehicles.ts";
import {
  OFFICIAL_PRODUCT_MEDIA,
  PRODUCT_IMAGE_VERSION,
  isWinchImage,
  isWinchProduct,
  officialMediaSetFor,
  officialImageFor,
  productImageSources,
} from "../src/lib/productImages.ts";
import {
  AMORTISSEUR_PRODUCTS,
  SUSPENSION_CATEGORY,
  SUSPENSION_CATEGORY_SLUG,
  SUSPENSION_CATALOG_VERSION,
  mergeSuspensionCatalog,
} from "../src/lib/suspensionCatalog.ts";
import { formatProductPrice } from "../src/lib/i18n.ts";
import {
  PRICE_ROUNDING_VERSION,
  normalizeCmsPrices,
  roundDzdPrice,
} from "../src/lib/pricing.ts";

class MemoryStorage {
  constructor(entries = {}) {
    this.items = new Map(Object.entries(entries));
    this.writes = [];
    this.reads = [];
    this.failWrites = false;
  }
  get length() { return this.items.size; }
  key(index) { return [...this.items.keys()][index] ?? null; }
  getItem(key) {
    this.reads.push(key);
    return this.items.get(key) ?? null;
  }
  setItem(key, value) {
    if (this.failWrites) throw new Error("QuotaExceededError");
    this.writes.push(key);
    this.items.set(key, String(value));
  }
  removeItem(key) { this.items.delete(key); }
  clear() { this.items.clear(); }
}

function withBrowser(storage, callback) {
  const target = new EventTarget();
  const previous = ["window", "localStorage"].map((key) => [
    key, Object.getOwnPropertyDescriptor(globalThis, key),
  ]);
  Object.defineProperty(globalThis, "window", { configurable: true, value: target });
  Object.defineProperty(globalThis, "localStorage", { configurable: true, value: storage });
  try {
    callback(target);
  } finally {
    for (const [key, descriptor] of previous) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else delete globalThis[key];
    }
  }
}

test("uses the exact global storage key and event name", () => {
  assert.equal(STORAGE_KEY, "dahra_cms_v2");
  assert.equal(CMS_UPDATED_EVENT, "dahra_cms_updated");
  assert.equal(CMS_SYNC_CHANNEL, "dahra_cms_sync_v2");
});

test("seeds and migrates the requested admin credentials", () => {
  assert.equal(ADMIN_USERNAME, "dahramotors");
  assert.equal(ADMIN_PASSWORD, "Motors24");
  assert.deepEqual(DEFAULT_STATE.credentials, {
    username: "dahramotors",
    password: "Motors24",
  });

  const legacy = structuredClone(DEFAULT_STATE);
  legacy.credentials = { username: "dahramotors4x4", password: "dahra4x4" };
  assert.deepEqual(parseCmsState(JSON.stringify(legacy)).credentials, {
    username: "dahramotors",
    password: "Motors24",
  });

  legacy.credentials = { username: "owner-custom", password: "custom-password" };
  assert.deepEqual(parseCmsState(JSON.stringify(legacy)).credentials, legacy.credentials);
});

test("vehicle database exposes the full Fit My 4x4 roster and Toyota generations", () => {
  const brands = VEHICLE_DATABASE.map((entry) => entry.brand);
  for (const brand of [
    "Toyota", "Jeep", "Nissan", "Isuzu", "Mitsubishi", "Ford", "Suzuki",
    "Land Rover", "Mercedes-Benz", "Volkswagen", "SsangYong", "Mazda",
    "Great Wall", "Haval", "Hyundai", "JMC", "LDV", "Mahindra",
  ]) {
    assert.equal(brands.includes(brand), true, brand);
  }
  const toyota = VEHICLE_DATABASE.find((entry) => entry.brand === "Toyota");
  const names = toyota.models.map((entry) => entry.name);
  for (const name of [
    "Hilux Vigo", "Hilux Vigo Champ", "Hilux Revo", "Hilux Revo Rocco",
    "Land Cruiser Series 70", "Land Cruiser Series 80", "Land Cruiser Series 100",
    "Land Cruiser Series 200", "Land Cruiser Series 300",
    "Land Cruiser Prado 120", "Land Cruiser Prado 150", "FJ Cruiser", "Fortuner",
  ]) {
    assert.equal(names.includes(name), true, name);
  }
  assert.deepEqual(
    toyota.models.find((entry) => entry.name === "Hilux Vigo").years.slice(-1),
    [2005],
  );
  assert.equal(
    toyota.models.find((entry) => entry.name === "Hilux Revo").years[0],
    2026,
  );
});

test("Fit My 4x4 resolves generation aliases, ranges and universal equipment", () => {
  assert.equal(
    matchesVehicleFitment(["TOYOTA HILUX VIGO"], {
      brand: "Toyota", model: "", year: "",
    }),
    true,
  );
  assert.equal(
    matchesVehicleFitment(["Universel 4x4"], {
      brand: "Mahindra", model: "", year: "",
    }),
    true,
  );
  assert.equal(
    matchesVehicleFitment(["TOYOTA HILUX VIGO"], {
      brand: "Toyota", model: "Hilux Vigo", year: 2012,
    }),
    true,
  );
  assert.equal(
    matchesVehicleFitment(["TOYOTA HILUX VIGO"], {
      brand: "Toyota", model: "Hilux Revo", year: 2020,
    }),
    false,
  );
  assert.equal(
    matchesVehicleFitment(["LC 75/78/79 1984/2007"], {
      brand: "Toyota", model: "Land Cruiser Series 70", year: 1998,
    }),
    true,
  );
  assert.equal(
    matchesVehicleFitment(["NISSAN NAVARA D23 2015+ / ALASKAN"], {
      brand: "Nissan", model: "Navara NP300 / D23", year: 2024,
    }),
    true,
  );
  assert.equal(
    matchesVehicleFitment(["NISSAN NAVARA D23 2015+ / ALASKAN"], {
      brand: "Renault", model: "Alaskan", year: 2021,
    }),
    true,
  );
  assert.equal(
    matchesVehicleFitment(["Universel treuils"], {
      brand: "Jeep", model: "Wrangler JL", year: 2020,
    }),
    true,
  );
  assert.equal(
    matchesVehicleFitment(["FORD RANGER T7 2018+"], {
      brand: "Ford", model: "Ranger T6 / T7", year: 2021,
    }),
    true,
  );
  assert.equal(
    matchesVehicleFitment(["FORD RANGER T7 2018+"], {
      brand: "Ford", model: "Ranger T6 / T7", year: 2016,
    }),
    false,
  );
});

test("seeds the current address, email and business hours", () => {
  assert.equal(DEFAULT_STATE.settings.email, "dahramotors4x4@gmail.com");
  assert.equal(
    DEFAULT_STATE.settings.address.fr,
    "Zone d'activité 2004, Baraki, Alger",
  );
  assert.equal(
    DEFAULT_STATE.settings.hours.fr,
    "08:30 – 17:00 (Du Samedi au Jeudi, Fermé le Vendredi)",
  );
  assert.equal(
    DEFAULT_STATE.settings.mapLink,
    "https://maps.app.goo.gl/qVRWKaqDF8zrk3xw5",
  );
});

test("upgrades unchanged factory contact details but preserves admin custom values", () => {
  const legacy = structuredClone(DEFAULT_STATE);
  legacy.settings.email = "contact@dahramotors4x4.dz";
  legacy.settings.address = {
    fr: "Baraki, Alger 16110, Algérie",
    ar: "براقي، الجزائر 16110، الجزائر",
  };
  legacy.settings.hours = {
    fr: "Lun – Sam : 09:00 – 18:00",
    ar: "الإثنين – السبت: 09:00 – 18:00",
  };
  legacy.settings.mapLink =
    "https://www.google.com/maps/search/?api=1&query=Baraki+Alger+16110+Algeria";
  const upgraded = parseCmsState(JSON.stringify(legacy));
  assert.equal(upgraded.settings.email, "dahramotors4x4@gmail.com");
  assert.equal(upgraded.settings.address.fr, "Zone d'activité 2004, Baraki, Alger");
  assert.equal(
    upgraded.settings.hours.fr,
    "08:30 – 17:00 (Du Samedi au Jeudi, Fermé le Vendredi)",
  );
  assert.equal(
    upgraded.settings.mapLink,
    "https://maps.app.goo.gl/qVRWKaqDF8zrk3xw5",
  );

  legacy.settings.email = "owner@example.dz";
  legacy.settings.address.fr = "Custom address";
  legacy.settings.hours.fr = "Custom hours";
  legacy.settings.mapLink = "https://example.com/map";
  const custom = parseCmsState(JSON.stringify(legacy));
  assert.equal(custom.settings.email, "owner@example.dz");
  assert.equal(custom.settings.address.fr, "Custom address");
  assert.equal(custom.settings.hours.fr, "Custom hours");
  assert.equal(custom.settings.mapLink, "https://example.com/map");
});

test("seeds the exact Ironman IM2.5 YouTube showcase", () => {
  assert.equal(
    DEFAULT_STATE.videoSection.videoUrl,
    "https://www.youtube.com/embed/X_MdJuPfg_0?autoplay=1&mute=1&loop=1&playlist=X_MdJuPfg_0",
  );
  assert.equal(DEFAULT_STATE.videoSection.videoUrl, IRONMAN_VIDEO_EMBED_URL);
  assert.equal(DEFAULT_STATE.videoSection.ctaLink, IRONMAN_VIDEO_WATCH_URL);
  assert.equal(
    DEFAULT_STATE.videoSection.title.fr,
    "INTRODUCING IM2.5 MONOTUBE SUSPENSION — IRONMAN 4X4",
  );
});

test("all seeded products have curated high-resolution media and fallback chains", () => {
  assert.equal(DEFAULT_STATE.productImageVersion, PRODUCT_IMAGE_VERSION);
  for (const product of DEFAULT_STATE.products) {
    assert.equal(Boolean(product.image), true, product.sku);
    assert.equal(
      /ironman4x4\.com(?:\.au)?\/cdn\/shop\/files\/|cdn11\.bigcommerce\.com/.test(product.image),
      true,
      `${product.sku}: ${product.image}`,
    );
    const sources = productImageSources(product);
    assert.equal(sources.length >= 2 && sources.length <= 4, true, `${product.sku}: ${sources.length}`);
    assert.equal(sources.includes(product.image), true, product.sku);
    assert.equal(product.images.length >= 1 && product.images.length <= 3, true, product.sku);
    assert.equal(new Set(sources).size, sources.length, product.sku);
    assert.equal(
      sources.some((source) => /images\.pexels\.com|No_Image_Available|\/images\//i.test(source)),
      false,
      product.sku,
    );
  }
  assert.equal(
    DEFAULT_STATE.products.find((p) => p.sku === "IMW12000_MSR").image,
    OFFICIAL_PRODUCT_MEDIA.winch12000,
  );
  assert.equal(
    DEFAULT_STATE.products.find((p) => p.sku === "UBP019").image,
    OFFICIAL_PRODUCT_MEDIA.underbodyLc70,
  );
  assert.equal(
    DEFAULT_STATE.products.find((p) => p.sku === "BBCD048 + IRP005").image,
    OFFICIAL_PRODUCT_MEDIA.bullbarNavara,
  );
});

test("seeds the complete supplied Amortisseurs batch with final DZD retail prices", () => {
  assert.equal(AMORTISSEUR_PRODUCTS.length, 28);
  assert.equal(DEFAULT_STATE.suspensionCatalogVersion, SUSPENSION_CATALOG_VERSION);
  assert.equal(
    DEFAULT_STATE.categories.some((category) => category.slug === SUSPENSION_CATEGORY_SLUG),
    true,
  );
  assert.equal(
    DEFAULT_STATE.categories.some((category) => category.slug === "amortisseurs"),
    false,
  );
  const expected = {
    "12648GR": [20400, null],
    "12650GR": [20400, null],
    "12650GRC": [20400, null],
    "12658GR": [20400, null],
    "12661GR": [20400, null],
    "12665GR": [20400, null],
    "12669GR": [17500, null],
    "12670GR": [20400, null],
    "12682GR": [17500, null],
    "12682GRC": [22900, null],
    "12683GR": [21700, null],
    "12691GR": [22900, null],
    "12696GR": [33300, null],
    "12697GR": [20400, null],
    "12698GRC": [20400, null],
    "12710GR - 12715GR": [20400, 33300],
    "12759GR": [24500, null],
    "12760GR": [24500, null],
    "12764GR_LH": [31200, null],
    "12764GR_RH": [31200, null],
    "12851GR / 12851GRC / 12851LGR": [24500, 25800],
    "24080FE / 24081FE / 24087FE": [29500, 34400],
    "24713FE - 24796FE": [34400, 48100],
    "45094FE - 45796FE": [47200, 76900],
    "71-057-730 / 72-057-682 / 73-057-081": [77300, 154700],
    "3501 - 3544": [29500, 38100],
    "HILFR05 / HILFR10 / HILFR15": [5000, 5200],
    "ISST001 - ISST090": [12900, 25200],
  };
  for (const [sku, [price, priceMax]] of Object.entries(expected)) {
    const product = AMORTISSEUR_PRODUCTS.find((entry) => entry.sku === sku);
    assert.ok(product, sku);
    assert.equal(product.price, price, sku);
    assert.equal(product.priceMax ?? null, priceMax, sku);
    assert.equal(product.oldPrice, null, sku);
    assert.equal(product.categorySlug, "suspension", sku);
    assert.equal(/ironman4x4\.com(?:\.au)?\/cdn\/shop\/files\//.test(product.image), true, sku);
    assert.equal(/\bHT\b|\bTTC\b|hors taxe/i.test(JSON.stringify(product)), false, sku);
  }
  assert.equal(formatProductPrice({ price: 20437.71 }, "fr"), "20 400 DA");
  assert.equal(formatProductPrice({ price: 17466 }, "fr"), "17 500 DA");
  assert.equal(
    formatProductPrice({ price: 77328.75, priceMax: 154657.48 }, "fr"),
    "77 300 – 154 700 DA",
  );
});

test("rounds every persisted product price field to a whole hundred DA", () => {
  assert.equal(roundDzdPrice(20437.71), 20400);
  assert.equal(roundDzdPrice(17466), 17500);
  assert.equal(roundDzdPrice(154657.48), 154700);

  const saved = structuredClone(DEFAULT_STATE);
  saved.priceRoundingVersion = 0;
  saved.products[0].price = 627324.13;
  saved.products[0].priceMax = 743495.26;
  saved.products[0].oldPrice = 83127.68;
  const rounded = normalizeCmsPrices(saved);
  assert.equal(rounded.priceRoundingVersion, PRICE_ROUNDING_VERSION);
  assert.equal(rounded.products[0].price, 627300);
  assert.equal(rounded.products[0].priceMax, 743500);
  assert.equal(rounded.products[0].oldPrice, 83100);
  for (const product of rounded.products) {
    assert.equal(Number.isInteger(product.price), true, product.sku);
    assert.equal(product.price % 100, 0, product.sku);
    if (product.priceMax != null) assert.equal(product.priceMax % 100, 0, product.sku);
    if (product.oldPrice != null) assert.equal(product.oldPrice % 100, 0, product.sku);
  }
});

test("Amortisseurs price revision updates supplied SKUs but preserves admin images", () => {
  const saved = structuredClone(DEFAULT_STATE);
  const existing = {
    ...AMORTISSEUR_PRODUCTS.find((product) => product.sku === "12648GR"),
    categorySlug: "amortisseurs",
    price: 999,
    image: "data:image/png;base64,ADMIN_IMAGE",
  };
  saved.products = [saved.products[0], existing];
  saved.categories.push({
    id: "cat-amortisseurs",
    slug: "amortisseurs",
    name: { fr: "AMORTISSEURS", ar: "ممتصات الصدمات" },
    image: existing.image,
    description: { fr: "Legacy", ar: "قديم" },
    active: true,
  });
  saved.suspensionCatalogVersion = 0;

  const migrated = mergeSuspensionCatalog(saved);
  assert.equal(migrated.suspensionCatalogVersion, SUSPENSION_CATALOG_VERSION);
  assert.equal(migrated.categories.filter((category) => category.slug === "amortisseurs").length, 0);
  assert.equal(migrated.categories.filter((category) => category.slug === "suspension").length, 1);
  assert.equal(migrated.products.find((product) => product.sku === "12648GR").price, 20400);
  assert.equal(migrated.products.find((product) => product.sku === "12648GR").categorySlug, "suspension");
  assert.equal(
    migrated.products.find((product) => product.sku === "12648GR").image,
    "data:image/png;base64,ADMIN_IMAGE",
  );
  assert.equal(
    migrated.products.filter((product) => product.sku === "12648GR").length,
    1,
  );
  const twice = mergeSuspensionCatalog(migrated);
  assert.deepEqual(twice, migrated);
});

test("explicitly empty products still receive the requested Amortisseurs batch", () => {
  const saved = structuredClone(DEFAULT_STATE);
  saved.products = [];
  saved.categories = [];
  saved.suspensionCatalogVersion = 0;
  const migrated = mergeSuspensionCatalog(saved);
  assert.equal(migrated.products.length, AMORTISSEUR_PRODUCTS.length);
  assert.equal(migrated.categories.some((category) => category.slug === "suspension"), true);
  assert.equal(migrated.categories.some((category) => category.slug === "amortisseurs"), false);
  assert.deepEqual(migrated.categories[0], SUSPENSION_CATEGORY);
});

test("loadState writes the Amortisseurs migration into dahra_cms_v2 once", () => {
  const saved = structuredClone(DEFAULT_STATE);
  const shockSkus = new Set(AMORTISSEUR_PRODUCTS.map((product) => product.sku));
  saved.products = saved.products.filter((product) => !shockSkus.has(product.sku));
  saved.categories.push({
    id: "cat-amortisseurs",
    slug: "amortisseurs",
    name: { fr: "AMORTISSEURS", ar: "ممتصات الصدمات" },
    image: "legacy.jpg",
    description: { fr: "Legacy", ar: "قديم" },
    active: true,
  });
  saved.suspensionCatalogVersion = 0;
  const storage = new MemoryStorage({ [STORAGE_KEY]: JSON.stringify(saved) });
  const first = loadState(storage);
  assert.equal(first.products.some((product) => product.sku === "12648GR"), true);
  assert.equal(first.categories.some((category) => category.slug === "amortisseurs"), false);
  assert.equal(first.categories.filter((category) => category.slug === "suspension").length, 1);
  assert.equal(
    first.products.filter((product) => shockSkus.has(product.sku)).every(
      (product) => product.categorySlug === "suspension"
    ),
    true,
  );
  assert.deepEqual(storage.writes, [STORAGE_KEY]);
  storage.writes.length = 0;
  const second = loadState(storage);
  assert.equal(second.products.filter((product) => product.sku === "12648GR").length, 1);
  assert.deepEqual(storage.writes, []);
});

test("global media revision replaces every legacy or uploaded catalog image once", () => {
  const saved = structuredClone(DEFAULT_STATE);
  saved.productImageVersion = 0;
  const winch = saved.products.find((p) => p.sku === "IMW12000_MSR");
  winch.image = "/images/winch-kit.jpg";
  let loaded = parseCmsState(JSON.stringify(saved));
  assert.equal(
    loaded.products.find((p) => p.sku === "IMW12000_MSR").image,
    OFFICIAL_PRODUCT_MEDIA.winch12000,
  );
  assert.equal(loaded.productImageVersion, PRODUCT_IMAGE_VERSION);

  saved.productImageVersion = 0;
  winch.image = "data:image/png;base64,OWNER_UPLOAD";
  loaded = parseCmsState(JSON.stringify(saved));
  assert.equal(
    loaded.products.find((p) => p.sku === "IMW12000_MSR").image,
    OFFICIAL_PRODUCT_MEDIA.winch12000,
  );
  assert.equal(
    loaded.products.find((p) => p.sku === "IMW12000_MSR").images.length,
    3,
  );

  // After the revision marker is stored, a later intentional admin edit wins.
  loaded.productImageVersion = PRODUCT_IMAGE_VERSION;
  loaded.products.find((p) => p.sku === "IMW12000_MSR").image =
    "data:image/png;base64,NEW_OWNER_UPLOAD";
  const afterMigration = parseCmsState(JSON.stringify(loaded));
  assert.equal(
    afterMigration.products.find((p) => p.sku === "IMW12000_MSR").image,
    "data:image/png;base64,NEW_OWNER_UPLOAD",
  );
});

test("non-winch galleries never contain the historical winch fallback", () => {
  const winchSources = [
    OFFICIAL_PRODUCT_MEDIA.winch12000,
    OFFICIAL_PRODUCT_MEDIA.winch9500,
    OFFICIAL_PRODUCT_MEDIA.wirelessPlug,
    OFFICIAL_PRODUCT_MEDIA.plugExtension,
    OFFICIAL_PRODUCT_MEDIA.winchRope,
    "/images/winch-kit.jpg",
  ];
  for (const product of DEFAULT_STATE.products) {
    if (isWinchProduct(product)) continue;
    const sources = productImageSources(product);
    assert.equal(sources.some(isWinchImage), false, product.sku);
    assert.equal(isWinchImage(product.image), false, product.sku);
    assert.equal(product.images.some(isWinchImage), false, product.sku);
  }

  const canopy = structuredClone(
    DEFAULT_STATE.products.find((product) => product.sku === "CANOPY010-P")
  );
  canopy.image = OFFICIAL_PRODUCT_MEDIA.winch12000;
  canopy.images = [
    "/images/winch-kit.jpg",
    OFFICIAL_PRODUCT_MEDIA.winch9500,
    OFFICIAL_PRODUCT_MEDIA.canopyFord,
  ];
  const saved = structuredClone(DEFAULT_STATE);
  saved.productImageVersion = 1;
  saved.products = [canopy];
  const cleaned = parseCmsState(JSON.stringify(saved)).products[0];
  assert.equal(cleaned.image, OFFICIAL_PRODUCT_MEDIA.canopyFord);
  assert.equal(cleaned.images.some(isWinchImage), false);
  assert.equal(productImageSources(cleaned).some(isWinchImage), false);
});

test("every seeded product resolves to a strict official or verified family media set", () => {
  for (const product of DEFAULT_STATE.products) {
    const set = officialMediaSetFor(product);
    assert.equal(set.length >= 2 && set.length <= 4, true, `${product.sku}: ${set.length}`);
    assert.equal(set[0], product.image, product.sku);
    assert.deepEqual(product.images, set.slice(1), product.sku);
  }
});

test("Amortisseurs official media stays within the correct shock family", () => {
  assert.equal(
    officialImageFor({ sku: "12648GR", categorySlug: "suspension" }),
    OFFICIAL_PRODUCT_MEDIA.nitroGas,
  );
  assert.equal(
    officialImageFor({ sku: "24080FE / 24081FE / 24087FE", categorySlug: "suspension" }),
    OFFICIAL_PRODUCT_MEDIA.foamCell,
  );
  assert.equal(
    officialImageFor({ sku: "45094FE - 45796FE", categorySlug: "suspension" }),
    OFFICIAL_PRODUCT_MEDIA.foamCellProShock,
  );
  assert.equal(
    officialImageFor({ sku: "71-057-730 / 72-057-682 / 73-057-081", categorySlug: "suspension" }),
    OFFICIAL_PRODUCT_MEDIA.im25Monotube,
  );
  assert.equal(
    officialImageFor({ sku: "3501 - 3544", categorySlug: "suspension" }),
    OFFICIAL_PRODUCT_MEDIA.steeringDamper,
  );
  assert.equal(
    officialImageFor({ sku: "HILFR05 / HILFR10 / HILFR15", categorySlug: "suspension" }),
    OFFICIAL_PRODUCT_MEDIA.trimPacker,
  );
  assert.equal(
    officialImageFor({ sku: "ISST001 - ISST090", categorySlug: "suspension" }),
    OFFICIAL_PRODUCT_MEDIA.strutTop,
  );
});

test("upgrades only the unchanged legacy factory video", () => {
  const saved = structuredClone(DEFAULT_STATE);
  saved.videoSection.videoUrl =
    "https://videos.pexels.com/video-files/17798063/17798063-uhd_3840_2160_30fps.mp4";
  saved.videoSection.title.fr = "DAHRA MOTORS EN PISTE";
  const loaded = parseCmsState(JSON.stringify(saved));
  assert.equal(loaded.videoSection.videoUrl, IRONMAN_VIDEO_EMBED_URL);
  assert.equal(
    loaded.videoSection.title.fr,
    "INTRODUCING IM2.5 MONOTUBE SUSPENSION — IRONMAN 4X4",
  );

  saved.videoSection.videoUrl = "https://youtu.be/custom123";
  saved.videoSection.title.fr = "Admin custom video";
  const custom = parseCmsState(JSON.stringify(saved));
  assert.equal(custom.videoSection.videoUrl, "https://youtu.be/custom123");
  assert.equal(custom.videoSection.title.fr, "Admin custom video");
});

test("seeds only an absent document, once", () => {
  const storage = new MemoryStorage();
  assert.deepEqual(loadState(storage), DEFAULT_STATE);
  const original = storage.getItem(STORAGE_KEY);
  loadState(storage);
  loadState(storage);
  assert.equal(storage.getItem(STORAGE_KEY), original);
  assert.deepEqual(storage.writes, [STORAGE_KEY]);
});

test("an empty string may be seeded", () => {
  const storage = new MemoryStorage({ [STORAGE_KEY]: "" });
  assert.deepEqual(loadState(storage), DEFAULT_STATE);
  assert.deepEqual(storage.writes, [STORAGE_KEY]);
});

test("saved prices, stock, branding, credentials and empty arrays win over defaults", () => {
  const saved = structuredClone(DEFAULT_STATE);
  saved.products = [{ ...saved.products[0], price: 100, stock: 0, featured: false }];
  delete saved.productPriceVersion;
  saved.categories = [];
  saved.hero = [];
  saved.gallery = [];
  saved.content.trustBadges = [];
  saved.settings.phone = "+213 555 11 22 33";
  saved.settings.headerLogo = "/custom-logo.svg";
  saved.credentials = { username: "owner-custom", password: "owner-password" };
  const raw = JSON.stringify(saved);
  const storage = new MemoryStorage({ [STORAGE_KEY]: raw });
  assert.deepEqual(loadState(storage), saved);
  assert.equal(storage.getItem(STORAGE_KEY), raw);
  assert.deepEqual(storage.writes, []);
});

test("saved zero prices are not treated as missing", () => {
  const saved = structuredClone(DEFAULT_STATE);
  saved.products[0].price = 0;
  const storage = new MemoryStorage({ [STORAGE_KEY]: JSON.stringify(saved) });
  assert.equal(loadState(storage).products[0].price, 0);
  assert.deepEqual(storage.writes, []);
});

test("deleted products stay deleted after repeated loads", () => {
  const saved = structuredClone(DEFAULT_STATE);
  const removed = saved.products.shift().id;
  const storage = new MemoryStorage({ [STORAGE_KEY]: JSON.stringify(saved) });
  for (let i = 0; i < 3; i++) {
    assert.equal(loadState(storage).products.some((p) => p.id === removed), false);
  }
  assert.deepEqual(storage.writes, []);
});

test("missing collections in an old saved document are empty, not reseeded", () => {
  const saved = parseCmsState(JSON.stringify({ settings: { phone: "0123456789" } }));
  for (const key of ["products", "categories", "hero", "gallery", "orders"]) {
    assert.deepEqual(saved[key], []);
  }
  assert.equal(saved.settings.phone, "0123456789");
});

test("an older version envelope never triggers a reset or write-back", () => {
  const saved = structuredClone(DEFAULT_STATE);
  saved.products = [];
  const raw = JSON.stringify({ seedVersion: -100, state: saved });
  const storage = new MemoryStorage({ [STORAGE_KEY]: raw });
  assert.deepEqual(loadState(storage), saved);
  assert.equal(storage.getItem(STORAGE_KEY), raw);
  assert.deepEqual(storage.writes, []);
});

test("v2 is checked first and takes precedence over every legacy key", () => {
  const saved = { ...structuredClone(DEFAULT_STATE), products: [] };
  const storage = new MemoryStorage({
    [STORAGE_KEY]: JSON.stringify(saved),
    dahra_cms_v1: JSON.stringify(DEFAULT_STATE),
    dahra_cms_v3: JSON.stringify(DEFAULT_STATE),
  });
  assert.deepEqual(loadState(storage).products, []);
  assert.deepEqual(storage.reads, [STORAGE_KEY]);
  assert.deepEqual(storage.writes, []);
});

test("legacy data is adopted only when v2 is absent, keeping the backup", () => {
  const saved = { ...structuredClone(DEFAULT_STATE), products: [] };
  const legacy = JSON.stringify({ seedVersion: 1, state: saved });
  const storage = new MemoryStorage({ dahra_cms_v3: legacy });
  assert.deepEqual(loadState(storage), saved);
  assert.deepEqual(JSON.parse(storage.getItem(STORAGE_KEY)), saved);
  assert.equal(storage.getItem("dahra_cms_v3"), legacy);
  assert.deepEqual(storage.writes, [STORAGE_KEY]);
});

test("the previous v1 store is migrated before older v3 data", () => {
  const saved = structuredClone(DEFAULT_STATE);
  saved.settings.headerLogo = "/saved-logo.png";
  saved.settings.phone = "0555000011";
  saved.products = [{ ...saved.products[0], price: 4321.98, stock: 2 }];
  saved.hero = [];
  const raw = JSON.stringify(saved);
  const storage = new MemoryStorage({
    dahra_cms_v1: raw,
    dahra_cms_v3: JSON.stringify(DEFAULT_STATE),
  });
  const migrated = structuredClone(saved);
  migrated.products[0].price = 4300;
  assert.deepEqual(loadState(storage), migrated);
  assert.equal(storage.getItem("dahra_cms_v1"), raw);
  assert.deepEqual(JSON.parse(storage.getItem(STORAGE_KEY)), migrated);
  assert.deepEqual(storage.writes, [STORAGE_KEY]);
  storage.writes.length = 0;
  loadState(storage);
  assert.deepEqual(storage.writes, []);
});

test("corrupt data is not erased or replaced by default data", () => {
  for (const raw of ["{broken", "null", "[]", '{"products":42}']) {
    const storage = new MemoryStorage({ [STORAGE_KEY]: raw });
    assert.throws(() => loadState(storage));
    assert.equal(storage.getItem(STORAGE_KEY), raw);
    assert.deepEqual(storage.writes, []);
  }
});

test("event synchronization reads never seed or write", () => {
  const storage = new MemoryStorage();
  assert.equal(readSavedState(storage), null);
  assert.deepEqual(storage.writes, []);
});

test("save synchronously writes before emitting the exact event, without an echo", () => {
  const saved = structuredClone(DEFAULT_STATE);
  saved.products[0].price = 12345.67;
  saved.settings.phone = "0555443322";
  const expected = structuredClone(saved);
  expected.products[0].price = 12300;
  const storage = new MemoryStorage();
  withBrowser(storage, (target) => {
    let events = 0;
    target.addEventListener(CMS_UPDATED_EVENT, () => {
      events++;
      assert.deepEqual(JSON.parse(storage.getItem(STORAGE_KEY)), expected);
      assert.deepEqual(readSavedState(storage), expected);
    });
    assert.equal(saveState(saved), true);
    assert.equal(events, 1);
    assert.deepEqual(storage.writes, [STORAGE_KEY]);
  });
});

test("a failed save retains the last good document and does not announce success", () => {
  const raw = JSON.stringify(DEFAULT_STATE);
  const storage = new MemoryStorage({ [STORAGE_KEY]: raw });
  storage.failWrites = true;
  withBrowser(storage, (target) => {
    let events = 0;
    target.addEventListener(CMS_UPDATED_EVENT, () => events++);
    assert.equal(saveState({ ...DEFAULT_STATE, products: [] }), false);
    assert.equal(events, 0);
    assert.equal(storage.getItem(STORAGE_KEY), raw);
  });
});

test("a saved edit survives navigation reads, remounts and a fresh session", () => {
  const storage = new MemoryStorage();
  loadState(storage);
  const saved = structuredClone(DEFAULT_STATE);
  saved.products[0].price = 777.25;
  saved.products[0].stock = 0;
  saved.products.splice(1, 1);
  saved.settings.phone = "0555111100";
  saved.content.aboutTitle.fr = "Saved CMS heading";
  withBrowser(storage, () => assert.equal(saveState(saved), true));
  const expected = structuredClone(saved);
  expected.products[0].price = 800;
  const raw = storage.getItem(STORAGE_KEY);
  storage.writes.length = 0;
  for (const route of ["/admin", "/", "/boutique", "/shop", "/admin"]) {
    assert.deepEqual(readSavedState(storage), expected, route);
    assert.deepEqual(loadState(storage), expected, route);
  }
  assert.equal(storage.getItem(STORAGE_KEY), raw);
  assert.deepEqual(storage.writes, []);
  const nextSession = new MemoryStorage(Object.fromEntries(storage.items));
  assert.deepEqual(loadState(nextSession), expected);
  assert.deepEqual(nextSession.writes, []);
});

test("invalid legacy data is preserved rather than silently seeded over", () => {
  const storage = new MemoryStorage({ dahra_cms_v1: "{invalid" });
  assert.throws(() => loadState(storage));
  assert.equal(storage.getItem("dahra_cms_v1"), "{invalid");
  assert.equal(storage.getItem(STORAGE_KEY), null);
  assert.deepEqual(storage.writes, []);
});

test("custom and storage event listeners are read-only and clean up", () => {
  const storage = new MemoryStorage({ [STORAGE_KEY]: JSON.stringify(DEFAULT_STATE) });
  withBrowser(storage, (target) => {
    let updates = 0;
    let current = null;
    const unsubscribe = subscribeCmsUpdates(() => {
      updates++;
      current = readSavedState(storage);
    });
    const saved = { ...structuredClone(DEFAULT_STATE), products: [] };
    assert.equal(saveState(saved), true);
    assert.equal(updates, 1);
    assert.deepEqual(current, saved);

    const nativeEvent = new Event("storage");
    Object.defineProperty(nativeEvent, "key", { value: STORAGE_KEY });
    target.dispatchEvent(nativeEvent);
    assert.equal(updates, 2);
    assert.deepEqual(storage.writes, [STORAGE_KEY]);

    const unrelated = new Event("storage");
    Object.defineProperty(unrelated, "key", { value: "dahra_theme" });
    target.dispatchEvent(unrelated);
    assert.equal(updates, 2);

    unsubscribe();
    target.dispatchEvent(new Event(CMS_UPDATED_EVENT));
    target.dispatchEvent(nativeEvent);
    assert.equal(updates, 2);
  });
});

test("broadcasts carry only invalidation notices; delayed snapshots cannot revert data", () => {
  const channels = new Set();
  const messages = [];
  class TestChannel {
    constructor(name) {
      this.name = name;
      this.onmessage = null;
      channels.add(this);
    }
    postMessage(data) {
      messages.push(data);
      for (const channel of channels) {
        if (channel !== this && channel.name === this.name) channel.onmessage?.({ data });
      }
    }
    close() { channels.delete(this); }
  }

  const storage = new MemoryStorage({ [STORAGE_KEY]: JSON.stringify(DEFAULT_STATE) });
  withBrowser(storage, (target) => {
    target.BroadcastChannel = TestChannel;
    let current = null;
    const unsubscribe = subscribeCmsUpdates(() => { current = readSavedState(storage); });
    const saved = structuredClone(DEFAULT_STATE);
    saved.products[0].price = 3210.45;
    const expected = structuredClone(saved);
    expected.products[0].price = 3200;
    assert.equal(saveState(saved), true);
    assert.deepEqual(messages, [{ type: CMS_UPDATED_EVENT, key: STORAGE_KEY }]);
    assert.deepEqual(current, expected);
    assert.equal(channels.size, 1);

    const oldTab = new TestChannel(CMS_SYNC_CHANNEL);
    oldTab.postMessage({ type: CMS_UPDATED_EVENT, key: STORAGE_KEY, state: DEFAULT_STATE });
    assert.deepEqual(current, expected);
    assert.deepEqual(storage.writes, [STORAGE_KEY]);
    oldTab.close();
    unsubscribe();
    assert.equal(channels.size, 0);
  });
});

test("blocked BroadcastChannel does not prevent durable saves or custom-event sync", () => {
  const storage = new MemoryStorage();
  withBrowser(storage, (target) => {
    target.BroadcastChannel = class { constructor() { throw new Error("Blocked"); } };
    let updated = false;
    const unsubscribe = subscribeCmsUpdates(() => { updated = true; });
    assert.equal(saveState(DEFAULT_STATE), true);
    assert.equal(updated, true);
    assert.deepEqual(readSavedState(storage), DEFAULT_STATE);
    unsubscribe();
  });
});